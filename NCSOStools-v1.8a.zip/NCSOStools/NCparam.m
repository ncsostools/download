%%*************************************************************************
%% NCparam.m: set parameters for NCsostools
%%
%% Last modified: 6. 6. 2010 (KC)
%%*************************************************************************
    
% when converting numbers to strings by num2str - appears in factor2NCpoly
NC_OPTIONS.precision = 8;

% using exponents or not (values 1 or 0)
NC_using_exponents = 1;
 

global NC_numeric_precision
if isempty(NC_numeric_precision)
    % precision in numeric calculations (NCsos, NCmin, NCdiff, NCisConvex0,
    % NCcycSos, NCcycMin, NCisCycConvex ...)
    NC_numeric_precision = 1e-8;
end
 
% SDP solver used in NCsos, NCmin, NCdiff, NCisConvex0, NCcycSos, NCcycMin,
% NCisCycConvex ...
global NC_active_solver
if isempty(NC_active_solver)
    NC_active_solver = 'SeDuMi';

    % NC_active_solver = 'SDPA';
    %% version with sedumiwrap in path is needed

    % NC_active_solver = 'SDPT3';  % version 4
    %% Warning: SDPT3 version 4.0 (beta) up to and including the update on 6
    %% Feb 2009 has a minor bug in SDPT3-4.0-beta\Solver\validate.m that
    %% affects our software in some examples. In case you are using such a
    %% version, please edit validate.m and change line 142 (in versions older
    %% than 6 Feb this could be some other line number)
    %% if (sum(ntotal) <= m)
    %% to
    %% if (sum(ntotal) < m)

    % NC_active_solver = 'SDPT3-v3';  % version 3
end
 
%%=============================================================





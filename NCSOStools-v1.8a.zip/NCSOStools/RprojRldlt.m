function [XRat,L,D,P,err]=RprojRldlt(XX,SDP_data,ldlt_test,start)

% RprojRldlt
%
% description: [XRat,L,D,P,err]=RprojRldlt(XX,SDP_data,ldlt_test,start)
% tries to find an exact rational positive semidefinite solution of the
% problem A*X=b from the floating point solution XX. The algorithm tries to
% find an appropiate rational approximation of the matrix XX which is after
% the projection on the hyperplane A*X=b a positive semidefinite matrix.
% 
% arguments:
% XX is a floating point solution of the SDP: XX PsD, A*XX=b.
% SDP_data is a structure holding .A and .b which represent A*XX=b.
% if ldlt_test=true the programme tries to compute an exact rational LDU
%    decomposition of a rational positive semidefinite solution of the
%    problem A*XX=b. Otherwise positive semidefiniteness relies on numerical
%    computation of eigenvalues. Default value is false.
% start tells the programme from what tolerance the rounding part starts. 
%    The tolerance equals 1/(2^start). Default value is 0. 
%
% output:
% XRat - a cell of two matrices which represent numerators and denominators
%    of the exact rational positive semidefinite solution
% L - a cell of two matrices which represent numerators and denominators of
%    the matrix L in the (P*L)*D*(P*L)^T decomposition of the matrix XRat
% D - a cell of two matrices which represent numerators and denominators of
%    the diagonal matrix D in the (P*L)*D*(P*L)^T decomposition of the
%    matrix XRat 
% P - a permutation pivot matrix in the (P*L)*D*(P*L)^T decomposition of
%    the matrix XRat
% err - if it equals 0 means that program ended with success, if it equals
%    -1 rational LDLT decomposition failed because of too large numbers
%    otherwise the whole procedure failed
%
% possible usage: RprojRldlt(XX,SDP_data), RprojRldlt(XX,SDP_data,ldlt_test),
%    RprojRldlt(XX,SDP_data,ldlt_test,start)
%
% see also: fac_reduct
%
%% Call: [XRat,L,D,P,err]=RprojRldlt(XX,SDP_data,ldlt_test,start)

% last : 14.3.2018 KC, nargchk -> narginchk

%error(nargchk(2,4,nargin));
narginchk(2,4);


if nargin==2
    ldlt_test=false;
    start=0;
elseif (ldlt_test~=true && ldlt_test~=false)
    error('third argument must be logical true or false.');
elseif nargin==3
    start=0;
end

if ~isfield(SDP_data,'A')
    error('missing .A in second argument.');
end
if ~isfield(SDP_data,'b')
    error('missing .b in second argument.');
end
% TODO
if ~isfield(SDP_data,'K')
    Ks=sqrt(size(XX(:),1));
elseif ~isfield(SDP_data.K,'s')
    Ks=sqrt(size(XX(:),1));
else
    Ks=SDP_data.K.s;
end


A=SDP_data.A;
b=SDP_data.b;
XX=XX(:);
L=[];
D=[];
P=[];
err=0;
err_warn=-1;
XRat={[],[]};

fprintf('\n***** NCSOStools: module RProjRldlt started *****\n\n');

len=sqrt(size(XX,1));

% TODO
% decomp_s(1)=0;
% for i=1:length(Ks)
%     decomp_s(i+1)=Ks(1:i)*Ks(1:i)';
%     XXfloat{i}=reshape(XX(decomp_s(i)+1:decomp_s(i+1)),Ks(i),Ks(i));
% end
XXfloat=reshape(XX,len,len);

% TODO
% if length(Ks)>1
%     fprintf('Using %d blocks\n',length(Ks));
% end    
% for i=1:length(Ks)
%     fprintf('delta (min eig X%d): %d\n',i,min(eig(XXfloat{i})));
% end
fprintf('delta (min eig X): %d\n',min(eig(XXfloat)));

fprintf('epsilon (residual norm): %d\n\n',norm(A*XX-b));

fprintf(' i :    1/2^i      tau_i      min_eig\n');
for i=start:52
    % rationalize
    [m,n]=rat(XX,1/(2^i));
    % [m,n]=rat(XX,(10-i)/10000);
    
    [Am,An]=rat(A);
    [bm,bn]=rat(b);
    [Xcand,errP]=Rproj({m,n},{Am,An},{bm,bn});
    if errP
        fprintf('\n***** ERROR: *****\n');
        fprintf('Rational projection failed because of too large numbers!\n');
        err_warn=2;
        err=-2;
        break;
    else
        %checking PSD
        mR=reshape(Xcand{1},len,len);
        nR=reshape(Xcand{2},len,len);
        XRP_f=mR./nR;
        XcandR = {mR,nR};

        mineigXRPf=min(eig(XRP_f));
        if mineigXRPf < 0
            err=1;
        else
            % zgolj test - ce je vse ok, to mora priti 0!
            % dum=Rminus(Rtimes({Am,An},Xcand),{bm,bn});
            % norm(dum{1}./dum{2})

            XRat=XcandR;
            if ldlt_test
                [L,D,P,err]=Rldlt(XcandR);
            else
                err=0;
            end 
        end

        XR_f=reshape(m,len,len)./reshape(n,len,len);
        
        % min(eig(Xpribl_f))

        fprintf('%2d :  %8.2E  %8.2E  %8.2E\n',i,1/(2^i),norm(XR_f-XXfloat),mineigXRPf);

        if err==-1
            fprintf('\nWARNING!\n');
            fprintf('Rational projection found but rational LDLT\n');
            fprintf('decomposition failed because of too large numbers.\n');
            err_warn=1;
            break;
        elseif err>0
            continue;
        else
            if ldlt_test
                fprintf('\nRational projection and LDLT decomposition found.\n');
                err_warn=0;
            else
                fprintf('\nRational projection found.\n');
                err_warn=0;
            end
            break;
        end
    end
end

if err_warn==2
    fprintf('\n***** NCSOStools: module RProjRldlt ended with error *****\n\n');
elseif err_warn==1
    fprintf('\n***** NCSOStools: module RProjRldlt ended with warning *****\n\n');
elseif err_warn==0
    fprintf('\n***** NCSOStools: module RProjRldlt completed successfully *****\n\n');
else
    fprintf('\n***** NCSOStools: module RProjRldlt ended *****\n\n');
end

    
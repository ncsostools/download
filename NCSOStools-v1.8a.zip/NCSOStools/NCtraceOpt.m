function [opt,decom_sohs,decom_S,base,SDP_data,Z,Zg,H,Hg,decom_err] = NCtraceOpt(f,S,d,params,rand)

% NCtraceOpt
%
% description: NCtraceOpt is the the shortcut for NCtraceMin. See NCtraceMin!

% samo zaradi oddanega �lanka

if nargin==3
    [opt,decom_sohs,decom_S,base,SDP_data,Z,Zg,H,Hg,decom_err] = NCtraceMin(f,S,d);
elseif nargin==4
    [opt,decom_sohs,decom_S,base,SDP_data,Z,Zg,H,Hg,decom_err] = NCtraceMin(f,S,d,params);
else
    [opt,decom_sohs,decom_S,base,SDP_data,Z,Zg,H,Hg,decom_err] = NCtraceMin(f,S,d,params,rand);
end
    

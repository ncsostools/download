function [Q_hat,bs,A_new]=AWbd(Ainput)

% AWbd
%
% description: [Q_hat,bs,A_new]=AWbd(Ainput) is the
% Murota-Kanno-Kojima-Kojima-Maehara numerical algorithm for the 
% Artin-Wedderburn block-diagonal decomposition of matrix *-algebras
%
% argument:
% Ainput is a matrix where each row represents a symmetric square
% matrix A_i
%
% output:
% Q_hat is a matrix so all the matrices Q_hat'*A_i*Q_hat are simultaneously
%    block diagonalized
% bs is a row of block sizes
% A_new is a matrix where each row represents simultaneously block
%    diagonalized (A_new_i=Q_hat'*A_i*Q_hat)
%
% see also: NCFlatExt, GNS, NCcycOpt
%
%% Call: [Q_hat,bs,A_new]=AWbd(Ainput)

% created K.C.

tol = 10e-5; % koliko se lahko l. vrednost razlikuje, da jo vseeno jemljem za enako
tol2 = 10e-5; % koliko se lahko norma matrike razlikuje od 0, da jo vseeno jemljeno za 0



fprintf('\n***** NCSOStools: module AWbd started *****\n\n');



[N,m]=size(Ainput);

Norig=N;

% mogoce preverjaj, da je m sploh popolen kvadrat
n=sqrt(m);
% mogoce preverjaj, da so A_i res simetricne matrike

% %temp
% for i=1:N
%     tmp1=reshape(Ainput(i,:),n,n);
%     for j=i:N
%         tmp2=reshape(Ainput(j,:),n,n);
%         tmp=(tmp1*tmp2+tmp2*tmp1);
%         Ainput=[Ainput;tmp(:)'];
%     end
% end
% 
% N=size(Ainput,1);
% 
% for i=1:N
%     tmp1=reshape(Ainput(i,:),n,n);
%     for j=i:N
%         tmp2=reshape(Ainput(j,:),n,n);
%         tmp=(tmp1*tmp2+tmp2*tmp1);
%         Ainput=[Ainput;tmp(:)'];
%     end
% end
% 
% N=size(Ainput,1);
% tmp=eye(n);
% A_plus_ind=[Ainput;tmp(:)'];

% test
% tmp1=reshape(Ainput(1,:),n,n);
% tmp2=reshape(Ainput(2,:),n,n);
% tmp=(tmp1*tmp2+tmp2*tmp1)/2;
% Ainput=[Ainput;tmp(:)'];
% N=size(Ainput,1);


% step 1
fprintf('step 1 ... ');

r=rand(1,N);
r=r/norm(r);

for i=1:N
    tmp=reshape(Ainput(i,:),n,n);
    tmp=(tmp+tmp')/2;
    Ainput(i,:)=tmp(:)';
end

A=r(1)*Ainput(1,:);
for i=2:N
    A=A+r(i)*Ainput(i,:);
end
fprintf('done.\n');


% step 2
fprintf('step 2 ... ');
A = reshape(A,n,n);
[Q,D] = eig(A);

% razmisli o sortiranju - izgleda, da eig ze vrze od min do max - za ziher
% narejeno
[dum1,dum2]=sort(diag(D));
D=diag(dum1);
Q=Q(:,dum2);

last_eig_val=D(1,1); % zadnja lastna vrednost
last_eig_start=1; % od katerega indeksa dalje je ta l.v.
eig_changes=1; % indeksi, kje se l.v. spremeni
Q(:,1)=Q(:,1)/norm(Q(:,1));
for i=2:n
    % nova lastna vrednost
    if abs(last_eig_val-D(i,i))>tol
        Q(:,i) = Q(:,i)/norm(Q(:,i));
        last_eig_start = i;
        eig_changes = [eig_changes, i];
        last_eig_val = D(i,i);
    % se vedno ista l vrednost
    else
        % gs
        for j=last_eig_start:i-1
            prod = Q(:,i)'*Q(:,j);
            if prod~=0
                norm2 = Q(:,j)'*Q(:,j);
                Q(:,i) = Q(:,i)-(prod/norm2)*Q(:,j);
                Q(:,i) = Q(:,i)/norm(Q(:,i));
           end
        end
    end
end
eig_changes=[eig_changes, n+1];
fprintf('done.\n');


% step 3
fprintf('step 3 ... ');

k=length(eig_changes)-1;
finished=zeros(1,k);
Q_hat=[];
bs=[];
bs_tmp=0;
for j=1:k
    if finished(j)==0
        Q_test = Q(:,eig_changes(j):eig_changes(j+1)-1);
        Q_hat = [Q_hat,Q_test];
        if bs_tmp ~= 0
            bs=[bs,bs_tmp];
        end
        bs_tmp=size(Q_test,2);
        finished(j)=1;
        for i=j+1:k
            if finished(i)==0
                for p=1:N
                    Q_i=Q(:,eig_changes(i):eig_changes(i+1)-1);
                    if norm(Q_test'*reshape(Ainput(p,:),n,n)*Q_i)>tol2
                        Q_hat=[Q_hat,Q_i];
                        bs_tmp=bs_tmp+size(Q_i,2);
                        finished(i)=1;
                        break;
                    end
                end
            end    
        end
    end
end

if bs_tmp ~= 0
    bs=[bs,bs_tmp];
end

fprintf('done.\n');

A_new=[];
% samo toliko A-jev, kot jih na zacetku dobis (kar dodajam, ne vracam)
for i=1:Norig
    tmp=Q_hat'*reshape(Ainput(i,:),n,n)*Q_hat;
    A_new=[A_new;tmp(:)'];
end


fprintf('\n***** NCSOStools: module AWbd completed *****\n\n');



function [X,fX,trace_min,flat,error_flat,norm_H,range]=NCtraceOptRand(f,S,d)

% NCtraceOptRand
%
% description: [X,fX,trace_min,flat,error_flat,norm_H,range]=NCtraceOptRand(f,S,d)
% computes lower bounds for trace of f over all symmetric matrices from
% D_S: ie bounds L_{\Theta^2}^{s} for s=d/2 and s=d/2+delta, delta=deg(S)/2 
% Function also tries to extend the optimal solution underlying 
% L_{\Theta^2}^{d/2+delta} to a flat solution using randomization idea from
% Nie, Klep and Povh
%
% arguments:
% f is an NCpoly representing a polynomial
% S is a set of nc polynomails defining D_S
% d is a starting degree for the hierarchy (even number)
%
% output:
% X: from GNS - a matrix where each of its rows represents a square matrix
% fX: f(X) where X is from GNS
% trace_min:  L_{\Theta^2}^{s}
% flat = 1 if program finds flat extension
% flat = 0, if program does not find flat ext.
% flat = -1 if the primal problem is infeasible (f is not in the module
% error_flat ... norm of the difference between the flat extension returned
%   by randomization idea of Nie, Klep and Povh and the brute force flat
%   extension (which is no more feasible for constraints)
% norm_H ... Frobenious norm of flat extension returned by randomization idea
% range ... diference between ranks of original matrix and flat extension
%   used 3 methods for rank computation
%
% possible usage: NCtraceOptRand(f,S,d)
%
% see also: GNS, AWbd, NCminBall, NCoptCube, NCopt, NCeigMinRand,
% NCtraceMin
%
%% Call: [X,fX,trace_min]=NCtraceOptRand(f,S,d)

% created         19.7.2014 by J. Povh
% last modified:  3.6.2015 by J. Povh
% last modified:  28.7.2015 by KC (cleaning)
% last : 14.3.2018 KC, nargchk -> narginchk

%error(nargchk(3,3,nargin));
narginchk(3,3);


% if nargin==1
%     AW=false;
% end

f=NCpoly(f);
var=NCvarsactive();
deg = compute_deg(f);
deg_S=zeros(1,size(deg,2));
for i=1:length(S)
    deg_S=deg_S+sum(compute_deg(S{i}),1);
end
vars_active_ind=find(sum(deg,1)+deg_S);
var_active=var(1,vars_active_ind);
deg_active=deg(:,vars_active_ind);
d=ceil(d);

X=[];
fX=[];
trace_min=[];
flat = 0;
error_flat=[];
norm_H=[];
range=[];
A=[];
fA=[];


var=NCvarsactive();
vars_active_ind=find(sum(deg,1));
var_active=var(1,vars_active_ind);
deg_active=deg(:,vars_active_ind);

n=length(var_active);

error_warn=0;


params.messages=0;
params.decomposition=1;
params.module_up=1;
d_f=max(sum(compute_deg(f),2));
for i=1:length(S)
    d_S(i) = max(sum(compute_deg(S{i}),2)); %sizes of Hg
end
N=5;
[opt1,decom_sohs1,decom_S1,base1,SDP_data1,Z1,Zg1,H1,Hg1,decom_err1] = NCtraceMin(f,S,d,params);
if (~isempty(opt1)) && (decom_err1 < 1e-4)
    fprintf('\n***** NCSOStools: module NCtraceMin returned bound f_theta^(%d): %f *****\n',ceil(d/2),full(opt1));
else
    fprintf('\n***** NCSOStools: given polynomail is not in the module M_{S,%d} (primal problem infeasible)*****\n',ceil(d/2));
end
    
[opt2,decom_sohs2,decom_S2,base2,SDP_data2,Z2,Zg2,H2,Hg2,decom_err2] = NCtraceMin(f,S,d+max(max(d_S)*1,1),params);
if ~isempty(opt2)
    fprintf('\n***** NCSOStools: module NCtraceMin returned bound f_theta^(%d): %f *****\n\n',ceil((d+max(max(d_S)*1,1))/2),full(opt2));
else
    fprintf('\n***** NCSOStools: given polynomail is not in the module M_{S,%d} (primal problem infeasible)*****\n',ceil((d+max(max(d_S)*1,1))/2));
    flat = -1;
    return;
end
if min(decom_err1,decom_err2) < (max(decom_err1,decom_err2)*0.01)
    fprintf('\n***** decom_err1 = %2.3f,  decom_err2 = %2.3f',decom_err1,decom_err2);
end
if decom_err2 > 1e-4
    flat = -1;
    fprintf('\nPrimal problem is very likley to be infeasible: f-f_Theta^(%d) differs from module decomposition by %f\n',ceil((d+max(max(d_S)*1,1))/2),decom_err2);
    return;
end
if isempty(H2)
    flat = -1;
    return;
end

if ~isempty(SDP_data1)
    sz= SDP_data1.K.s(1);
else
    dd=ceil(d/2);  
    if n==1
        sz=dd+1;
    else
        sz= (n^(dd+1)-1)/(n-1);     
        fprintf('\nERROR\n'); 
    end
    %  return;
end  


%compute the left upper corner of H, correspondin do words in R<x>_{le d/2}
H_small=H2(1:sz,1:sz);
H_d=1/2*(H_small+H_small');
 % computes flat extension of H

%%%start J. Nie random idea
%params.solver='sdpt3';
rand.H0=H_d;
T=zeros(5,4);
i=1;
error_flat=[];
while i< 5 && ~flat
    [opt,decom_sohs,decom_S,base,SDP_data,Z,Zg,H,Hg,decom_err] = NCtraceMin(f,S,d+max(max(d_S)*1,1),params,rand);
    if isempty(H)
        fprintf('***** NO solution from NCtraceMin was FOUND. Try increasing d. *****\n');
        return;
    end
    B=H(1:size(H_d,1),size(H_d,1)+1:size(H,1));
    W=H_d\B;
    Delta=W'*H_d*W-H(size(H_d,1)+1:size(H,1),size(H_d,1)+1:size(H,1));
    Delta_fr = norm(Delta,'fro');
    % Delta_oper se ne uporabi
    Delta_oper = max(abs(eig(Delta)));
    error_flat=Delta_fr/(1+norm(W'*H_d*W,'fro')+norm(H(size(H_d,1)+1:size(H,1),size(H_d,1)+1:size(H,1)),'fro'));    
    tol=min(30*error_flat,1e-3);
    rd1a=rank_c(H_d,tol,1);
    rd1b=rank_c(H,tol,1);
    rd2a=rank_c(H_d,tol,2);
    rd2b=rank_c(H,tol,2);
    rd3a=rank_c(H_d,tol,3);
    rd3b=rank_c(H,tol,3);
    range=[rd1a rd1b;rd2a rd2b;rd3a rd3b];
    dif = range(:,2)-range(:,1);
    T(i,:)=[i rd1a rd1b Delta_fr]
    %error_flat=2*Delta_fr/(norm(W'*H_d*W,'fro')+norm(H(size(H_d,1)+1:size(H,1),size(H_d,1)+1:size(H,1)),'fro'));
    norm_H=norm(H,'fro');
    if (min(abs(dif))==0)&& (error_flat<tol)
        fprintf('***** %d-FLAT optimal solution over module M_{S,%d} FOUND. *****\n',ceil(max(max(d_S))/2), ceil((d+max(max(d_S)*1,1))/2));
        flat = 1;
    end
    i=i+1;
end

if ~flat
    fprintf('***** NO flat optimal solution over module M_{S,%d} was FOUND. *****\n',ceil((d+max(max(d_S)*1,1))/2));
    return;
end
    
[X,err]=GNS(base,H,var_active,[],size(H_d,1));

if err>0
    fprintf('\n***** Caution:                          *****\n');
    fprintf('***** GNS module did not end normally.  *****\n');
    fprintf('***** Module NCtraceOptRand is quiting. *****\n');
    return;
end

% da se izpise, odkomentiraj naslednjo vrstico ...
% X

[N,m]=size(X);
n=sqrt(m);
fprintf('Evaluating X');
subst={};
just_for_test=0;
for j=1:N
    tmp=reshape(X(j,:),n,n);
    % XGNS(:,:,j)=tmp;
    just_for_test=just_for_test+tmp^2;
    subst=[subst,{{NCvariable(var_active{j}),tmp}}];
end
fprintf(' ..... ');
fsubst=NCeval(f,subst);
fX=NCpoly2double(fsubst);
[eig_vec,eig_val]=eig(fX);
% sort
[dum1,dum2]=sort(diag(eig_val));
eig_val=diag(dum1);
eig_vec=eig_vec(:,dum2);

fprintf('completed.\n');

trace_min = sum(sum(eig_val))/size(eig_val,1);
% sort je ze prej narejen, zato je (1,1) res min
fprintf('\n*** Minimum trace of f is %f. ***\n',trace_min);

if abs(opt2-trace_min)>1e-5
    error_warn=1;
    fprintf('\n WARNING: Minimum trace from GNS and from the dual SDP are different: %f, %f!\n',full(opt2),full(trace_min));
   
else
    fprintf('\n NOTICE: Minimum trace from GNS and from the dual SDP are equal: %f, %f!\n',full(opt2),full(trace_min));
end


fprintf('\n***** NCSOStools: module NCtraceOptRand completed');
if error_warn
    fprintf(' with warnings!');
end
fprintf(' *****\n\n');


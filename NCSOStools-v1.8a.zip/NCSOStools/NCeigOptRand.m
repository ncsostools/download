function [X,fX,eig_min,flat,error_flat,norm_H,range]=NCeigOptRand(f,S,d)

% NCeigOptRand
%
% description: [X,fX,eig_min,flat,error_flat,norm_H,range]=NCeigOptRand(f,S,d)
%     computes minimizers and the minimum of the polynomial f on D_s and
%     tries to extend dual solution to a flat solution using randomization
%
% arguments:
% f is an NCpoly representing a polynomial
% S is a set of nc polynomails defining D_S
% d is a starting degree for the hierarchy (even number)
% 
% output:
% X: from GNS - a matrix where each of its rows represents a square matrix
% fX: f(X) where X is from GNS
% eig_min: eigenvalues of fX
% flat = 1 if program finds flat extension
% flat = 0, if program does not find flat extension
% flat = -1 if the primal problem is infeasible (f is not in the module M_S,d)
% error_flat ... norm of the difference between the flat extension returned
%     by randomization idea of Nie, Klep and Povh and the brute force flat
%     extension (which is no more feasible for constraints)
% norm_H ... Frobenious norm of flat extension returned by randomization idea
% range ... diference between ranks of original matrix and flat extension
%    used 3 methods for rank computation
%
% possible usage: NCeigOptRand(f,S,d)
%
% see also: GNS, AWbd, NCminBall, NCoptCube, NCopt
%
%% Call: [X,fX,eig_min,flat,error_flat,norm_H,range]=NCeigOptRand(f,S,d)

% created         28.7.2013 by J. Povh
% last modified:  13.12.2014 by J. Povh
% last modified:  28.7.2015 by KC (cleaning, delete params)
% last : 14.3.2018 KC, nargchk -> narginchk

%error(nargchk(2,3,nargin));
narginchk(2,3);


if nargin==2
    d=0;
end

% if nargin==1
%     AW=false;
% end

f=NCpoly(f);
%glej dol - katero rabis? verjetno spodnje
var=NCvarsactive();
deg = compute_deg(f);
deg_S=zeros(1,size(deg,2));
for i=1:length(S)
    deg_S=deg_S+sum(compute_deg(S{i}),1);
end
vars_active_ind=find(sum(deg,1)+deg_S);
var_active=var(1,vars_active_ind);
deg_active=deg(:,vars_active_ind);
d=ceil(d);

X=[];
fX=[];
eig_min=[];
flat = 0;
error_flat=[];
norm_H=[];
range=[];
%odstranil
%A=[];
%fA=[];


%glej gor - katero rabis? verjetno to ... kaj pa, ce ima vez neko
%spremenljivko, ki je v polyju ni? kaj pa, ce je vez taka, da ima same
%spremenljivke, ki jih v polyju ni? v dolocenih primerih vseeno gornje?
var=NCvarsactive();
vars_active_ind=find(sum(deg,1));
var_active=var(1,vars_active_ind);
deg_active=deg(:,vars_active_ind);

n=length(var_active);

if n==0  % poly is a constant
    structpoly=struct(f);
    X=1;
    fX=structpoly.koef;
    eig_min=structpoly.koef;
    flat = 1;
    error_flat=0;
    norm_H=1;
    range=zeros(3,2);
    %odstranil
    %A=[];
    %fA=[];
    return;
end

error_warn=0;


params.messages=0;
params.decomposition=1;
%po moje nima pomena
%params.module_up=1;

%kje rabis?
d_f=max(sum(compute_deg(f),2));

for i=1:length(S)
    d_S(i) = max(sum(compute_deg(S{i}),2)); %sizes of Hg
end
%premaknil dol
%N=5;

[opt1,decom_sohs1,decom_S1,base1,SDP_data1,Z1,Zg1,H1,Hg1,decom_err1] = NCeigMin(f,S,d,params);
if (~isempty(opt1)) && (decom_err1 < 1e-4)
    fprintf('\n***** NCSOStools: module NCeigMin returned bound f_theta^(%d): %f *****\n',ceil(d/2),full(opt1));
else
    fprintf('\n***** NCSOStools: given polynomail is not in the module M_{S,%d} (primal problem infeasible)*****\n',ceil(d/2));
end
    
[opt2,decom_sohs2,decom_S2,base2,SDP_data2,Z2,Zg2,H2,Hg2,decom_err2] = NCeigMin(f,S,d+max(max(d_S)*1,1),params);

if ~isempty(opt2)
    fprintf('\n***** NCSOStools: module NCeigMin returned bound f_theta^(%d): %f *****\n\n',ceil((d+max(max(d_S)*1,1))/2),full(opt2));
else
    fprintf('\n***** NCSOStools: given polynomail is not in the module M_{S,%d} (primal problem infeasible)*****\n',ceil((d+max(max(d_S)*1,1))/2));
    flat = -1;
    return;
end
if min(decom_err1,decom_err2) < (max(decom_err1,decom_err2)*0.01)
    fprintf('\n***** decom_err1 = %2.4f,  decom_err2 = %2.4f',decom_err1,decom_err2);
end
if decom_err2 > 1e-4
    flat = -1;
    fprintf('\nPrimal problem is very likley to be infeasible: f-f_Theta^(%d) differs from module decomposition by %f\n',ceil((d+max(max(d_S)*1,1))/2),decom_err2);
    return;
end
if isempty(H2)
    flat = -1;
    return;
end

if ~isempty(SDP_data1)
    sz= SDP_data1.K.s(1);
else
    dd=ceil(d/2);  
    if n==1
        sz=dd+1;
    else
        sz= (n^(dd+1)-1)/(n-1);     
        fprintf('\nERROR\n'); 
    end
%  return;
end  


%compute the left upper corner of H, correspondin do words in R<x>_{le d/2}
H_small=H2(1:sz,1:sz);
H_d=1/2*(H_small+H_small');
% computes flat extension of H

%%%start J. Nie random idea
%params.solver='sdpt3';
rand.H0=H_d;
T=zeros(5,4);
i=1;
error_flat=[];
%naredil spremenljivko
N=5;
while i<N && ~flat
    %Hg in decom_err ne rabis
    [opt,decom_sohs,decom_S,base,SDP_data,Z,Zg,H,Hg,decom_err] = NCeigMinRand(f,rand.H0,S,d+max(max(d_S)*1,1),params);
    if isempty(H)
        fprintf('***** NO solution from NCeigMinRand was FOUND. Try increasing d. *****\n');
        return;
    end
    B=H(1:size(H_d,1),size(H_d,1)+1:size(H,1));
    W=H_d\B;
    Delta=W'*H_d*W-H(size(H_d,1)+1:size(H,1),size(H_d,1)+1:size(H,1));
    Delta_fr = norm(Delta,'fro');
    %Delta_oper ne rabis?!
    Delta_oper = max(abs(eig(Delta)));
    error_flat=Delta_fr/(1+norm(W'*H_d*W,'fro')+norm(H(size(H_d,1)+1:size(H,1),size(H_d,1)+1:size(H,1)),'fro'));    
    tol=min(30*error_flat,1e-3);
    rd1a=rank_c(H_d,tol,1);
    rd1b=rank_c(H,tol,1);
    rd2a=rank_c(H_d,tol,2);
    rd2b=rank_c(H,tol,2);
    rd3a=rank_c(H_d,tol,3);
    rd3b=rank_c(H,tol,3);
    range=[rd1a rd1b;rd2a rd2b;rd3a rd3b];
    dif = range(:,2)-range(:,1);
    T(i,:)=[i rd1a rd1b Delta_fr]
    % error_flat=2*Delta_fr/(1+norm(W'*H_d*W,'fro')+norm(H(size(H_d,1)+1:size(H,1),size(H_d,1)+1:size(H,1)),'fro'));
    norm_H=norm(H,'fro');
    if (min(abs(dif))==0)&& (error_flat<tol)
        fprintf('***** %d-FLAT optimal solution over module M_{S,%d} FOUND. *****\n',ceil(max(max(d_S))/2), ceil((d+max(max(d_S)*1,1))/2));
        flat = 1;
    end
    i=i+1;
end
if ~flat
    fprintf('***** NO flat optimal solution over module M_{S,%d} was FOUND. *****\n',ceil((d+max(max(d_S)*1,1))/2));
    fprintf('***** Module NCeigOptRand is quiting.                          *****\n');
    return;
end
    
[X,err]=GNS(base,H,var_active,[],size(H_d,1));

if err>0
    fprintf('\n***** Caution:                         *****\n');
    fprintf('***** GNS module did not end normally. *****\n');
    %fprintf('***** Module NCoptBall is quiting.         *****\n');
    fprintf('***** Module NCeigOptRand is quiting.  *****\n');
    return;
end

% da se izpise, odkomentiraj naslednjo vrstico ...
% X

[N,m]=size(X);
n=sqrt(m);
fprintf('Evaluating X');
subst={};
just_for_test=0;
for j=1:N
    tmp=reshape(X(j,:),n,n);
    % XGNS(:,:,j)=tmp;
    just_for_test=just_for_test+tmp^2;
    subst=[subst,{{NCvariable(var_active{j}),tmp}}];
end
fprintf(' ..... ');
fsubst=NCeval(f,subst);
fX=NCpoly2double(fsubst);
[eig_vec,eig_val]=eig(fX);
% sort
[dum1,dum2]=sort(diag(eig_val));
eig_val=diag(dum1);
eig_vec=eig_vec(:,dum2);

fprintf('completed.\n');

eig_min = eig_val(1,1);
% sort je ze prej narejen, zato je (1,1) res min
fprintf('\n*** Minimum eigenvalue of f is %f. ***\n',eig_min);

if abs(opt2-eig_min)>1e-5
    error_warn=1;
    fprintf('\n WARNING: Minimum eigenvalue from GNS and from the dual SDP are different: %f, %f!\n',full(opt2),full(eig_min));
   
else
    fprintf('\n NOTICE:  Minimum eigenvalue from GNS and from the dual SDP are equal: %f, %f!\n',full(opt2),full(eig_min));
end


fprintf('\n***** NCSOStools: module NCeigOptRand completed');
if error_warn
    fprintf(' with warnings!');
end
fprintf(' *****\n\n');



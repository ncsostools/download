function g=NCclean(f,eps)

% NCclean
%
% description: g=NCclean(f,eps) eliminates from the polynomial f every
% monomial whose coefficient is smaller than eps.
% 
% arguments:
% f is NCpoly representing input polynomial
% eps is a real number for which we take coefficients of f to be zero if
%    they are smaller than eps.
% 
% output: simplified NCpoly whose coefficients are only those that are
% greater or equal than eps
%
% possible usage: NCclean(f,eps)

% last modified: 19. 11. 2010 KC
% last : 14.3.2018 KC, nargchk -> narginchk

%error(nargchk(1,2,nargin));
narginchk(1,2);


if nargin==1
    eps=1e-4;
end

g=NCpoly(zeros(size(f)));
[m,n]=size(f);
for i=1:m
    for j=1:n
        fs=struct(f(i,j));
        where=abs(fs.koef)<eps;
        fs.koef(where)=[];
        fs.monom(where)=[];
        g(i,j)=factor2NCpoly(fs.koef,fs.monom);
    end
end

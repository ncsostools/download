function h = plus(f,g,string_out)

% plus
%
% description: h=plus(f, g) is called for the syntax 'f + g' and means
% symbolic addition.
%
% arguments: f and g are NCpolys representing polynomials or matrix of
% NCpolys with matching dimensions
%
% output: NCpoly representing the polynomial f + g
%
% possible usage: f + g, plus(f, g)

% last modified: 3. 2. 2009 KC
% last modified: 6. 6. 2010 KC (string_out)

if nargin<3 || isempty(string_out) || string_out~=0
    string_out=1;
end

tmp1=NCpoly(f);
tmp2=NCpoly(g);

if tmp1==NCpoly(0)
    h=tmp2;
    return;
elseif tmp2==NCpoly(0)
    h=tmp1;
    return;
end

if ~isequal(size(tmp1),size(tmp2))
	% VAZNO! Odlociti se je treba, ali to 1x1 velja le za stevila (sedaj ni omejeno na stevila!)
    if all(size(tmp1)==1)
        tmp1 = tmp1*eye(size(tmp2));
    elseif all(size(tmp2)==1)
        tmp2 = tmp2*eye(size(tmp1));
    else
        error('ERROR: dimensions do not match!');
    end
end

temp=tmp1;
for i=1:size(tmp1,1)
    for j=1:size(tmp1,2)
        koef=[tmp1(i,j).koef,tmp2(i,j).koef];
        monom=[tmp1(i,j).monom;tmp2(i,j).monom];

        temp(i,j)=factor2NCpoly(koef,monom,[],[],string_out);
    end
end
h=temp;

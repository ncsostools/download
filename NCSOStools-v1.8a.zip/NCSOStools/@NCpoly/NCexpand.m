function g=NCexpand(f)

% NCexpand
%
% description: g=NCexpand(f) simplifies the polynomial f and writes its
% monomials in expanded form without using exponents regardless of the
% parameter NC_using_exponents set in NCparam.m.
% 
% arguments: NCpoly representing the polynomial f or matrix of NCpolys
% 
% output: simplified NCpoly whose monomials are written without exponents
%
% possible usage: NCexpand(f)
%
% see also: NCsimplify

% last modified: 8. 2. 2008 KC

g=f;
for i=1:size(f,1)
    for j=1:size(f,2)
        koef=f(i,j).koef;
        monom=f(i,j).monom;
        g(i,j)=factor2NCpoly(koef,monom,0);
    end
end
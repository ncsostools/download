function g = power(f,n)

% power
%
% description: g=power(f, n) is called for the syntax 'f.^n' and computes
% the n-th power of the each element in a matrix of NC polynomials.
% 
% arguments:
% f is a matrix of NCpolys
% n is a nonnegative integer
% 
% output: matrix of NCpolys
% 
% possible usage: f.^n, power(f, n)

% last modified: 16. 2. 2009 KC

if check_type(n,'natural')==0
    error('ERROR: Power must be a non-negative integer.')
elseif ndims(f) > 2
    %to bi lahko razsirili na vec dimenzij, ce bi zeleli
    error('ERROR: Matrix must be 2-D.')
end

if n==0
    g=NCpoly(ones(size(f)));
    return;
elseif n==1
    g=f;
    return;
else
	g=f;
	for i=1:size(f,1)
		for j=1:size(f,2)
			g(i,j)=f(i,j)^n;
		end
	end
end

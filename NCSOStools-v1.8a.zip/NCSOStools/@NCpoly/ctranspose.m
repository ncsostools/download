function g=ctranspose(f)

% ctranspose
%
% description: g=ctranspose(f) is called for the syntax f' and computes the
% involution of the polynomial f. If f is a matrix of NCpolys, this
% command also applies complex conjugate transpose at the same time.
% 
% arguments: NCpoly representing the polynomial f or matrix of NCpolys
% 
% output: NCpoly representing the involution of the polynomial f
% 
% possible usage: f', ctranspose(f)

% last modified: 9. 1. 2009 KC

temp=[];
for m=1:size(f,1)
	for n=1:size(f,2)
		koef=f(m,n).koef;
		monom=f(m,n).monom;

		monom_r=monom;
		for i=1:length(monom)
			monom_r{i} = monom_ast(monom{i});
		end

		tmp(n,1)=factor2NCpoly(conj(koef),monom_r);
	end
	if isempty(temp)
		temp=tmp;
	else
		temp=[temp tmp];
	end
end
g=temp;
function A = horzcat(varargin)

% horzcat
%
% description: A = horzcat(varargin) performs horizontal concatenation.
% horzcat(A,B) or [A B] or [A,B] is the horizontal concatenation of
% matrices A and B.  A and B must have the same number of rows. Any
% number of matrices can be concatenated within one pair of brackets.
% 
% arguments: matrices of NCpolys with the same number of rows
% 
% output: matrix of NCpolys
% 
% possible usage: [A1 A2 ... An], [A1, A2, ..., An], horzcat(A1, A2, ..., An)

% last modified: 5. 3. 2009 KC
% last modified: 12. 6. 2010 KC

args = varargin;
nmb = length(args);
m=zeros(1,nmb);
for k=1:nmb
    m(k)=size(args{k},1);
    args{k} = NCpoly(args{k});
end
tmp=(m==0);
m(tmp)=[];
args(tmp)=[];
if any(m~=m(1))
    error('ERROR: All matrices must have the same number of rows.');
else
	A = builtin('horzcat',args{:});
end

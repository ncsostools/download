function s=NCpoly(poly,koef,monom)

% NCpoly

% last modified: 9. 1. 2009 KC

superiorto('double');
superiorto('NCvariable');

if nargin < 1
   w = evalin('caller','whos');
   k = strmatch('NCpoly',char({w.class,''}));
   disp(' ')
   disp({w(k).name})
   disp(' ')
   return
end

if nargin==1
	if isa(poly,'NCpoly')
		s=poly;
	elseif isa(poly,'NCvariable')
		s=class(struct('name',char(poly),'koef',1,'monom',{{char(poly)}}),'NCpoly');
    elseif isempty(poly)
        s=class(struct('name',{},'koef',{},'monom',{}),'NCpoly');
	elseif isnumeric(poly)
		if ndims(poly) > 2
			error('ERROR: numerics must be (maximal) 2-D.')
		else
			temp=[];
			for i=1:size(poly,1)
				for j=1:size(poly,2)
					if imag(poly(i,j))==0
						ime=num2str(poly(i,j));
					else
						NCparam;
						dig = NC_OPTIONS.precision;
						ime=zapiskomp(poly(i,j),dig);
					end
					tmp(j)=class(struct('name',ime,'koef',poly(i,j),'monom',{{''}}),'NCpoly');
				end
				if isempty(temp)
					temp=tmp;
				else
					temp=[temp;tmp];
				end
			end
			s=temp;
		end
	%elseif ischar(poly)
	%    s=class(struct('name',poly),'NCpoly');
	else
	%    error('ERROR: conversion to ''NCpoly'' from ''%s'' is not possible. Only strings, numerics and NCvariables are accepted.', class(x))
		error('ERROR: conversion to ''NCpoly'' from ''%s'' is not possible. Only numerics and NCvariables are accepted.', class(poly))
	end
elseif nargin==3
    if (ischar(poly) && isnumeric(koef) && isa(monom,'cell'))
        [m1,n1]=size(koef);
        [m2,n2]=size(monom);
        if (m1==n2 && m2==n1)
            s=class(struct('name',poly,'koef',koef,'monom',{monom}),'NCpoly');
        else
    		error('ERROR: dimensions of coefficients and monomials do not match.')
        end
    else
		error('ERROR: wrong input type.')
    end
else
	error('ERROR: wrong number of parameters.')
end





%enaka funkcija tudi v factor2NCpoly
function novo=zapiskomp(stev,dig)
if real(stev)~=0
    if imag(stev)==1
        novo=[num2str(real(stev),dig),'+i'];
    elseif imag(stev)==-1
        novo=[num2str(real(stev),dig),'-i'];
    else
        novo=num2str(stev,dig);
    end
else
    if imag(stev)==1
        novo='i';
    elseif imag(stev)==-1
        novo='-i';
    else
        novo=[num2str(imag(stev),dig),'i'];
    end
end



function h = NCcom(f,g)

% NCcom
%
% description: h = NCcom(f,g) computes comutator f*g-g*f
%
% arguments: f and g are NCpolys representing polynomials
%
% output: NCpoly representing the polynomial f*g-g*f
%
% possible usage: NCcom(f,g)
%
% see also: 

% created: 8.3.2014
% last modified: 
% last : 14.3.2018 KC, nargchk -> narginchk

%error(nargchk(2,2,nargin));
narginchk(2,2);

fp=NCpoly(f);
gp=NCpoly(g);

h=fp*gp-gp*fp;

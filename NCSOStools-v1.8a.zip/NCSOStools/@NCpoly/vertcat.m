function A = vertcat(varargin)

% vertcat
%
% description: A = vertcat(varargin) performs vertical concatenation.
% vertcat(A,B) or [A;B] is the vertical concatenation of matrices A and B.
% A and B must have the same number of columns. Any number of matrices can
% be concatenated within one pair of brackets.
% 
% arguments: matrices of NCpolys with the same number of columns
% 
% output: matrix of NCpolys
% 
% possible usage: [A1;A2;...;An], vertcat(A1,A2,...,An)

% last modified: 5. 3. 2009 KC
% last modified: 12. 6. 2010 KC

args = varargin;
nmb = length(args);
n=zeros(1,nmb);
for k=1:nmb
    n(k)=size(args{k},2);
    args{k} = NCpoly(args{k});
end
tmp=(n==0);
n(tmp)=[];
args(tmp)=[];
if any(n~=n(1))
    error('ERROR: All matrices must have the same number of columns.');
else
	A = builtin('vertcat',args{:});
end

function B = tril(A,k)

% tril
%
% description: B = tril(A,k) extracts lower triangular part of A.
% tril(A) is the lower triangular part of A.
% tril(A,k) is the elements on and below the k-th diagonal of A. k = 0 is
% the main diagonal, k > 0 is above the main diagonal and k < 0 is below
% the main diagonal.
%
% arguments:
% A is a matrix of NCpolys
% k is an integer
% 
% output: matrix of NCpolys
% 
% possible usage: tril(A), tril(A,k)

% last modified: 3. 3. 2009 KC

if nargin == 1
    k = 0;
end

[m,n] = size(A);
B=NCpoly(zeros(m,n));
if k>=n-1
    B=A;
elseif (k<0 && -k>=m)
    return;
else
    d = min(m+k,n);
    for j = 1:d
        zac=max(j-k,1);
        B(zac:m,j) = A(zac:m,j);
    end
end

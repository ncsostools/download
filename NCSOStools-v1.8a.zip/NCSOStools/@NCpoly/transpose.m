function B = transpose(A)

% transpose
%
% description: B = transpose(A) is called for the syntax A.' and means
% symbolic matrix transpose.
%
% arguments: A is a matrix of NCpolys
% 
% output: matrix of NCpolys
% 
% possible usage: A.', transpose(A)

% last modified: 3. 3. 2009 KC

if ndims(A) > 2
   error('ERROR: Matrix must be at most 2D!')
else
   [m,n]=size(A);
   B=NCpoly(zeros(n,m));
   for i=1:n
       B(i,:)=A(:,i);
   end
end

function p = prod(A,dim)

% prod
%
% description: p = prod(A,dim) is product of the elements. For vectors,
% prod(A) is the product of the elements of A. For matrices, prod(A) or
% prod(A,1) is a row vector of column products and prod(A,2) is a column
% vector of row products.
%
% arguments:
% A is a matrix of NCpolys
% dim tells if it is a column (1) or row (2) product; for matrices is
% default 1
% 
% output: row/column of NCpolys
% 
% possible usage: prod(A), prod(A,dim)

% last modified: 3. 3. 2009 KC


if nargin == 2 && dim~=1 && dim~=2
    error('ERROR: dim must be 1 or 2!');
end

if nargin == 1 && any(size(A) == 1)
   p = 1;
   for i = 1:length(A)
      p = p * A(i);
   end
elseif nargin == 1 || dim == 1
   p = NCpoly(ones(1,size(A,2)));
   for i = 1:size(A,1)
      p = p .* A(i,:);
   end
else
   p = NCpoly(ones(size(A,1),1));
   for j = 1:size(A,2);
      p = p .* A(:,j);
   end
end
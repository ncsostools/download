function g=NCsimplify(f)

% NCsimplify
%
% description: g=NCsimplify(f) simplifies the polynomial f and writes its
% monomials shortly using exponents regardless of the parameter
% NC_using_exponents set in the global option file NCparam.m.
% 
% arguments: NCpoly representing the polynomial f or matrix of NCpolys
% 
% output: simplified NCpoly whose monomials are written with exponents
%
% possible usage: NCsimplify(f)
%
% see also: NCexpand

% last modified: 8. 2. 2008 KC

g=f;
for i=1:size(f,1)
    for j=1:size(f,2)
        koef=f(i,j).koef;
        monom=f(i,j).monom;
        g(i,j)=factor2NCpoly(koef,monom,1);
    end
end


function g=NCeval(f,subst)

% NCeval
%
% description: g=NCeval(f,subst) evaluates a polynomial f with
% substitutions defined in a row cell subst.
% 
% arguments:
% f is an NCpoly representing a polynomial
% subst is a row cell of substitutions
% 
% output: g is NCpoly where given substitutions are done in f
% 
% possible usage: NCeval(f,subst)
%
% example: NCeval(x^2+x*y,{{x,x+y},{y,x-y}})

% created: 3. 2. 2009 KC
% last modified: 8. 2. 2009 KC
% last : 14.3.2018 KC, nargchk -> narginchk

%error(nargchk(1,2,nargin));
narginchk(1,2);


if nargin==1
    g=NCpoly(f);
    return;
end

if length(subst)==2 && isa(subst{1,1},'NCvariable')
    subst={subst};
end

% preverim, ce so same numericne zamenjave - nekoliko lahko v tem primeru pohitrimo
num_zamen=true;
if ~isa(subst,'cell')
    error('ERROR: second argument must be a row cell of substitutions.');
else
    [m,n]=size(subst);
    if m~=1
        error('ERROR: second argument must be a ROW cell of substitutions.');
    end
    velikost=size(subst{1,1}{1,2});
    if ~isequal(velikost(1,1),velikost(1,2))
        error('ERROR: all substitutions must be square matrix.');
    end
    for i=1:n
        if ~isa(subst{1,i}{1,1},'NCvariable')
            error('ERROR: only NCvariables can be substituted.');
        elseif ~isa(subst{1,i}{1,2},'NCvariable') && ~isa(subst{1,i}{1,2},'NCpoly') && ~isa(subst{1,i}{1,2},'numeric')
            error('ERROR: substitution can be made only with NCpolys, NCvariables and numerics.');
        elseif ~isequal(velikost,size(subst{1,i}{1,2}))
            error('ERROR: all substitutions must be the same size.');
        elseif ~isa(subst{1,i}{1,2},'numeric')
            num_zamen=false;
        end
    end
end
    
    
[m,n]=size(f);
% dodelati se treba, ce v matriko polinomov vstavljas matriko polinomov -
% primer, ko ne pridejo vsi bloki enakih dimenzij
tmpv=[];
for j=1:m
    tmps=[];
    for k=1:n
        poly=NCpoly(f(j,k));
        koefs=poly.koef;
        monoms=poly.monom;

        tmp=NCpoly(0);
        for i=1:size(monoms,1)
            tmp=tmp+koefs(1,i)*substMonom(monoms{i,1},subst,num_zamen);
        end
        if isempty(tmps)
            tmps=tmp;
        else
            tmps=[tmps,tmp];
        end
    end
    if isempty(tmpv)
        tmpv=tmps;
    else
        tmpv=[tmpv;tmps];
    end
end
g=tmpv;




function h=substMonom(monom,subst,num_zamen)

tmp_ost=monom;
if num_zamen
    h=1;
else
    h=NCpoly(1);
end
while ~isempty(tmp_ost)
    [var,tmp_ost]=strtok(tmp_ost,'*');
    replaced=false;
    for i=1:length(subst)
        if strcmp(var,char(subst{1,i}{1,1}))
            h=h*subst{1,i}{1,2};
            replaced=true;
            break;
        end
    end
    if ~replaced
        h=h*NCvariable(var);
    end
end

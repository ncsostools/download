function h=minus(f,g,string_out)

% minus
%
% description: h=minus(f, g) is called for the syntax 'f - g' and means
% symbolic subtraction.
% 
% arguments: f and g are NCpolys representing polynomials or matrix of
% NCpolys with matching dimensions
% 
% output: NCpoly representing the polynomial f - g
% 
% possible usage: f - g, minus(f, g)

% last modified: 11. 12. 2008 KC
% last modified: 11. 6. 2010 KC (string_out)

if nargin<3 || isempty(string_out) || string_out~=0
    string_out=1;
end

h=plus(f,mtimes(NCpoly(-1),g,0),string_out);
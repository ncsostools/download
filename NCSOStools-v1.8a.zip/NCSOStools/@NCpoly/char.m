function g=char(f)

% char
%
% description: g=char(f) simplifies polynomial f and converts it to its
% string representation.
% 
% arguments: NCpoly representing the polynomial f
% 
% output: string representing the polynomial f
% 
% possible usage: char(f)

% last modified: 11. 12. 2008 KC

g=f.name;
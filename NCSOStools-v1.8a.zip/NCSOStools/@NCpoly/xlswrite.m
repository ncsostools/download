function [success,message]=xlswrite(file,A,sheet,range)

% xlswrite
%
% description: xlswrite stores matrix of NC polys in Excel workbook.
%
% arguments:
%	file is a string representing filename for Excel workbook (mandatory)
%	A is a matrix of NCpolys (mandatory)
%	sheet specifies the Excel worksheet (optional)
%	range specifies the area in the worksheet (optional)
% 
% output:
%	success is logical scalar
%	message is structure containing message field and message_id field
% 
% possible usage: xlswrite(file,A), xlswrite(file,A,sheet), xlswrite(file,A,range), xlswrite(file,A,sheet,range)

% last modified: 8. 3. 2014 KC

A=NCpoly(A);

% Set default values.
Sheet1 = 1;

if nargin < 3
    sheet = Sheet1;
    range = '';
elseif nargin < 4
    range = '';
end

if ndims(A) > 2
   error('ERROR: Matrix must be at most 2D!')
else
   [m,n]=size(A);
   for i=1:m
   	for j=1:n
   		B{i,j}=char(A(i,j));
   	end
   end
   [success,message]=xlswrite(file,B,sheet,range);
end

function g = mpower(f,n)

% mpower
%
% description: g=mpower(f, n) is called for the syntax 'f^n' and means
% symbolic matrix power. So, it computes the n-th power of the (matrix of
% NCpolys) f, i.e., f^n.
% 
% arguments:
% f is an NCpoly representing a polynomial or matrix of NCpolys with equal
% dimensions
% n is a nonnegative integer
% 
% output: NCpoly representing the polynomial f^n
% 
% possible usage: f^n, mpower(f, n)

% last modified: 10. 1. 2009 KC

if check_type(n,'natural')==0
    error('ERROR: Power must be a non-negative integer.')
elseif ndims(f) > 2
    error('ERROR: Matrix must be 2-D.')
elseif size(f,1)~=size(f,2)
	error('ERROR: Matrix must be square.')
end

if n==0
    g=NCpoly(eye(size(f,1)));
    return;
elseif n==1
    g=f;
    return;
elseif mod(n,2)==0
    tmp=mpower(f,n/2);
    g=tmp*tmp;
    return;
else 
    tmp=mpower(f,(n-1)/2);
    g=tmp*tmp*f;
    return;
end

function iseq = isequal(f,g)

% isequal
%
% description: iseq = isequal(f,g) is a symbolic isequal test; it returns
% true if and only if f and g represent equal (matrices of) NCpolys. 
% 
% arguments: f and g are NCpolys representing polynomials or matrices of
% NCpolys
% 
% output: logical true (1) if matrices f and g are the same size and
% contain equal NCpolys, and logical false (0) otherwise 
% 
% possible usage: isequal(f,g)

% last modified: 4. 2. 2009 KC

iseq = false;
if isequal(size(f),size(g))
    if all(f==g)
        iseq = true;
    end
end

function tf=is_constant(f)

monom=f.monom;

if length(monom)==1 && isempty(monom{1})
    tf=true;
else
    tf=false;
end

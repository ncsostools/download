function iseq=eq(f,g)

% eq
%
% description: iseq=eq(f, g) is called for the syntax 'f == g' and compares
% matrices of NCpolys f and g elementwise. It returns a matrix of the same
% size with entries set to logical 1 where the polynomials are equal and
% entries set to 0 where they are not. Matrices f and g must have the same
% dimensions unless one is a 1x1 matrix. A scalar can be compared with any
% size array. 
% 
% arguments: f and g are NCpolys representing polynomials or matrices of
% NCpolys with matching dimensions.
% 
% output: matrix with elements equal to logical true (1) or false (0)
% 
% possible usage: f == g, eq(f, g)

% last modified: 10. 1. 2009 KC

poly1=NCpoly(f);
poly2=NCpoly(g);

if ~isequal(size(poly1),size(poly2))
    if all(size(poly1)==1)
        poly1 = poly1*ones(size(poly2));
    elseif all(size(poly2)==1)
        poly2 = poly2*ones(size(poly1));
    else
        error('ERROR: Array dimensions must agree.');
    end
end

[m,n]=size(poly1);
iseq=true(m,n);
for i=1:m
    for j=1:n
        koef1=poly1(i,j).koef;
        monom1=poly1(i,j).monom;
        koef2=poly2(i,j).koef;
        monom2=poly2(i,j).monom;

        if length(koef1)~=length(koef2)
            iseq(i,j)=false;
            break;
        end

        if ~all(koef1==koef2)
            iseq(i,j)=false;
            break;
        end

        if ~all(strcmp(monom1,monom2))
            iseq(i,j)=false;
            break;
        end
    end
end
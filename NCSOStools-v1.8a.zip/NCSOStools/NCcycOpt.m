function [A_new,f_min]=NCcycOpt(f)

% NCcycOpt
%
% description: [A_new,f_min]=NCcycOpt(f) computes trace minimizers and
% the trace minimum of the polynomial f whenever the tracial moment matrix
% corresponding to the polynomial f is flat.
%
% arguments:
% f is an NCpoly representing a polynomial.
%
% output:
% A_new is a matrix each of whose rows represent a square matrix A_i that
%    is a trace minimizer for f. The matrices A_i are simultaneously block
%    diagonal.
% f_min represents the trace minimum of f. Each element in this vector
%    equals the trace of the evaluation of f in equally positioned diagonal
%    blocks consisting of matrices A_i.
%
% possible usage: NCcycOpt(f)
%
% see also: NCFlatExt, GNS, AWbd, NCopt, NCcycMin
%
%% Call: [A_new,f_min]=NCcycOpt(f)

% last: 5. 6. 2010 KC
% last modified: 14.3.2018 KC, nargchk -> narginchk

%error(nargchk(1,1,nargin));
narginchk(1,1);

f=NCpoly(f);

A_new=[];
f_min=[];


fprintf('\n***** NCSOStools: module NCcycOpt started *****\n\n');


[IsFlatExt,SDP_data,rank_d,V_new,M_1_out,vars,sizeM_small,tol] = NCFlatExt(f);

if (IsFlatExt==0)
    fprintf('\n***** Caution:                                          *****\n');
    fprintf('***** The dual matrix is not flat. We can not guarantee *****\n');
    fprintf('***** that NCcycMin returns the exact lower bound.      *****\n');
    fprintf('***** Module NCcycOpt is quiting.                       *****\n');
    return;
elseif (IsFlatExt==-1)
    fprintf('\n***** Caution:                                           *****\n');
    fprintf('***** Searching for flat extension did not end normally. *****\n');
    fprintf('***** Module NCcycOpt is quiting.                        *****\n');
    return;
end

[X,err]=GNS(V_new,M_1_out,vars,tol,sizeM_small);

if err>0
    fprintf('\n***** Caution:                         *****\n');
    fprintf('***** GNS module did not end normally. *****\n');
    fprintf('***** Module NCcycOpt is quiting.      *****\n');
    return;
end

[Q_hat,bs,A_new]=AWbd(X);

[N,m]=size(A_new);
n=sqrt(m);

block_number=length(bs);

fprintf('Number of simultaneously diagonalized blocks: %d\n', block_number);

start=1;
f_min=[];
for i=1:block_number
    fprintf('Evaluating block number: %d', i);

    bsi=bs(i);
    subst={};
    for j=1:N
        tmp=reshape(A_new(j,:),n,n);
        tmp=tmp(start:start+bsi-1,start:start+bsi-1);
        subst=[subst,{{NCvariable(vars{j}),tmp}}];
    end
    
    fprintf(' ..... ');
    
    fsubst=NCeval(f,subst);

    if isempty(f_min)
        f_min=1/bsi*trace(fsubst);
    else
        f_min=[f_min, 1/bsi*trace(fsubst)];
    end
    
    start=start+bsi;
    fprintf('completed.\n');
end


fprintf('\n***** NCSOStools: module NCcycOpt completed *****\n\n');


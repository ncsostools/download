function [opt,decom_sohs,decom_S,base,SDP_data,Z,Zg,H,Hg,decom_err] = NCtraceMin(f,S,d,params,rand)

% NCtraceMin
%
% description: [opt,decom_sohs,decom_S,base,SDP_data,Z,Zg,H,Hg,decom_err] = NCtraceMin(f,S,d,params,rand)
% computes the lower bound for the minimum trace of f
% on all matrices A = D_S, where S contains polynomials, i.e. lower bound
% for
%   inf trace (f(A))
% s.t. g(A)\succeq 0 for all g in S
%   This is dual to:
%     sup eps
%     s.t. f-eps ~ SOHS + \sum_{g\in S}\sum_i h_j^*gh_j where degree of
%     each summand <=d
% It solves the dual:
%     min <L_f,H>
%     H ... hankel (moment) matrix (i.e. H(u,v)=H(p,q) iff u^*v cyc. eq. p^*q
%     H(1) = 1
%     H >= 0
%     H^g >= 0
%     (H^g)_p,q = L(p^*gq), for all g in S
% where H is of order |W_{d/2}| and H_g is of order |W_{d/2-deg(g)/2}| and d is
% input
%
% If rand is not empty then we solve
%     min <R,H>
%     H ... hankel (moment) matrix (i.e. H(u,v)=H(p,q) iff u^*v cyc. eq.  p^*q
%     H(1) = 1
%     H >= 0
%     H^g >= 0
%     (H^g)_p,q = L(p^*gq), for all g in S
%     H_{leftupper} = rand.H0 ... rand.H0 is optimal solution of problem for smaller d (usually d-1)
% where H is of order |W_{d/2}| and H_g is of order |W_{d/2-deg(g)/2}| and d is
%  R...random Gram matrix
%
% arguments:
% f is an NCpoly representing a polynomial
% S is a set of nc polynomails defining D_S
% d is a starting degree for the hierarchy (even number)
% With params.precision we can set the smallest value that is considered to
%    be nonzero in numerical calculations; if the command is called without
%    it, we assume the precision set with the command NCsetPrecision or the
%    value set in NCparam.m.
% params.messages is used to optionally turn on (1) and off (0) verbose
%    output; default value is 1 (on).
% params.solver sets the solver to be used for SDP and overrides the value
%    set in the global option file NCparam.m. (currently SeDuMi, SDPA-M or
%    SDPT3 are supported)  
% params.eps sets the desired accuracy iy you are using SeDuMi as SDP
%    solver. Setting params.eps=0 lets SeDuMi run as long as it can make
%    progress.
% params.justSDP_data == 1 means that the program ends when the SDP_data is
%    prepared and nothing else is computed. It is optional; the default
%    value is 0.
% params.decomposition == 0 means that no SOHS decomposition over an nc
%    ball will actually be computed. It is optional; the default value is 1.
% rand  ... data for Nie randomization procedure
%     rand.H0  - left upper corner (solution of NCtraceMin for smaller d
%
% output:
% opt ... optimal value of the SDP
% decom_sohs ... sohs part of the sohs decomposition over nc ball
% decom_S ... weights of polynomials g\in S
% base ... is a list of monomials which appear in the SOHS decomposition
%    over S
% SDP_data ... is a structure holding all the data used in SDP solver
% Z ... dual solution, that represent cycsohs
% Zg.... dual solution that contains weights
% H ... Hankel matrix
% Hg ... shifted Hankel matrices for g in S
% decom_err ... norm(nccycrep(f-opt- SOHS - \sum_{g\in S}\sum_i h_j^*gh_j))
%
% possible usage: NCtraceMin(f,S,d), NCtraceMin(f,S,d,params),
% NCtraceMin(f,S,d,params,rand)
%
% see also: NCoptBall, NCminCube, NCsos, NCmin, NCopt, NCdiff, NCcycSos,
% NCcycMin, NCsetPrecision, NCsetSolver, NCisConvex, NCisConvex0,
% NCisCycConvex, RProjRldlt
%
%% Call: [opt,decom_sohs,decom_S,base,SDP_data,Z,Zg,H,Hg,decom_err]  = NCtraceMin(f,S,d,params,rand)

% created:        1. 3. 2013 by J. Povh
% last modified: 19. 7. 2014 by JP
% last modified: 28.7.2015 by KC (cleaning)
% last : 14.3.2018 KC, nargchk -> narginchk

%error(nargchk(3,5,nargin));
narginchk(3,5);

% POZOR: ce bos spreminjal inpute in/ali outpute, spremeni tudi v NCtraceOpt, ki je samo zaradi �e oddanega clanka


poly=NCpoly(f);
decom_err=[];
base=[];
SDP_data=[];
H=[];
Hg=[];
decom_sohs=[];
decom_S=[];
opt = [];
Z=[];
Zg=[];
H0=[];

pars_sdp='';
justSDP_data=0;
decomposition=1;
module_up=0;
error_warn=0;
is_rand=0;

d=ceil(d/2);
if nargin <= 3  
    NCparam;
    precision = NC_numeric_precision;
    messages=true;
    rat=0;
elseif nargin >= 4
   
    if isfield(params,'messages') && ~isempty(params.messages)
        if params.messages~=true && params.messages~=false
            error('ERROR: .messages must be logical true/false.');
        end
        messages=params.messages;
    else
        messages=true;
    end

    if isfield(params,'precision') && ~isempty(params.precision)
        if ~isnumeric(params.precision)
            error('ERROR: .precision must be a numerical value.');
        end
        precision = params.precision;
    else
        NCparam;
        precision = NC_numeric_precision;
    end
    
    if isfield(params,'solver') && ~isempty(params.solver)
        pars_sdp.solver = params.solver;
    end
    
    if isfield(params,'eps') && ~isempty(params.eps)
        if ~isnumeric(params.eps)
            error('ERROR: .eps must be a numerical value.');
        end
        pars_sdp.eps = params.eps;
    end

    if isfield(params,'justSDP_data') && ~isempty(params.justSDP_data)
        if (params.justSDP_data==1 || params.justSDP_data==true)
            justSDP_data=1;
        end
    end

    if isfield(params,'decomposition') && ~isempty(params.decomposition)
        if (params.decomposition==0 || params.decomposition==false)
            decomposition=0;
        end
    end
    
     if isfield(params,'rat') && ~isempty(params.rat)
        if (params.rat==0 || params.rat==false)
            rat=0;
        end
     else
         rat=0;
     end

    if isfield(params,'module_up') && (params.module_up==1 || params.module_up==0)
        module_up=params.module_up;
    end
end    

if nargin == 5
    if isfield(rand,'H0') && ~isempty(rand.H0)
        H0=rand.H0;
        is_rand=1;
    else
        fprintf('***** Incorrect rand input************');
        return;
    end
end


%trace!
% if nargin == 1 % we do trace optimization over all possible matrices
%     [opt,Z_dual,base,decomp_sohs,g,SDP_data,H] = NCmin(poly,params);
% elseif nargin == 2  % default call - we take d=degree(f)/2
%     d = ceil(degree(poly)/2);
% end

if messages
    fprintf('\n***** NCSOStools: module NCtraceMin started *****\n\n');
end

if (poly~=poly')
    fprintf('Polynomial is not symmetric: it will be symmetrised.\n');
    poly =1/2*(poly + poly');
end

structpoly=struct(poly);
monom=structpoly.monom;
if length(monom) == 1 && isempty(monom{1})
    fprintf('Polynomial is a constant so there is nothing to do.\n');
    fprintf('***** Program is quiting. *****\n');
    return;
end


structpoly=struct(poly);
monoms_f=structpoly.monom;
koefs_f=structpoly.koef;
if length(monoms_f) == 1 && isempty(monoms_f{1})
    opt=poly;
    X=1;
    base={''};
    SDP_data=[];
    Z=1;
    return;
end

var=NCvarsactive();
deg = compute_deg(poly);
deg_S=zeros(1,size(deg,2));
for i=1:length(S)
    deg_S=deg_S+sum(compute_deg(S{i}),1);
end
vars_active_ind=find(sum(deg,1)+deg_S);
var_active=var(1,vars_active_ind);
deg_active=deg(:,vars_active_ind);


d_f=max(sum(deg_active,2));
if d_f > 2*d
    fprintf('\n***** NCSOStools: given polynomail is not in the module M_{S,%d} (primal problem infeasible): deg(poly)= %d\n',d,d_f);
    return;
end

[V,V_deg] = generateFullV(d,var_active);
base = V;
%

d_S=[];
m=length(S); %numer of polinomaisl in S
n_S=[];
n_H=size(V,1);  % size of matrix H

for i=1:m
    d_S(i) = max(sum(compute_deg(S{i}),2)); %size of H
    n_S(i)=sum(V_deg<=floor(d-d_S(i)/2));   % size of H_{g_i}
end

G=find_gram(poly,V,'cycsos'); %we compute gram matrix of symmetrised f
if isempty(G)  % there is no Gram matrix - problem with too short V
    return;
end

% construct SDP
% 

b=[];
A=cell(m+1,1);

A{1,1}=sparse(n_H^2,1); % 
for i=1:m
    A{i+1,1}=sparse(n_S(i)^2,1);
end


% constraint H(1)=1
count =1;
A{1,count} = [1;zeros(n_H^2-1,1)];
for i=1:m
    A{i+1,count} = zeros(n_S(i)^2,1);
end
b(count)=1;

ekv_mon = cycEqProd(V);
ekv_mon_temp = ekv_mon;
% constraints on H
while ~isempty(ekv_mon_temp)
    mon_temp=ekv_mon_temp{1,1}{1,1};
    ind = vertcat(ekv_mon_temp{1,1}{:,2});
    ekv_mon_temp(1,:)=[];
    j=1; terminate = 0;
    while j <= size(ekv_mon_temp,1) && ~terminate
        if strcmp(mon_temp,monom_ast(ekv_mon_temp{j,1}{1,1}))
            ekv_mon_temp(j,:)=[]; 
            terminate = 1;
        end
        j=j+1;
    end
    if is_rand && length(strfind(mon_temp,'*'))< d
        continue;
    end

    for j=2:size(ind,1);
        M = sparse([ind(1,1);ind(j,1)],[ind(1,2);ind(j,2)],[-1;1],n_H,n_H); 
        M=M+M';
        if norm(M,'fro')  && ind(j,2)>=ind(j,1)
            count = count +1;
            b(count)=0;
            A{1}(:,count) = M(:);
            for i=1:m
                A{i+1}(:,count)=sparse(n_S(i)^2,1);
            end
        end
    end
end

for i=1:m  % constraints H_gi(u,v)=\sum_w gi_w L(u^* w v)
    structpoly=struct(NCpoly(S{i}));
    monom=structpoly.monom;
    koef=structpoly.koef;
    for j=1:n_S(i)
        u=V{j};
        for k=j:n_S(i)
            v=V{k};
            M1=sparse([k j],[j k],[1 1],n_S(i),n_S(i)); 
            M2=sparse(n_H,n_H);
            for el = 1:length(monom)
                word = concate(concate(monom_ast(u),monom{el}),v);
                found=0;
                p=1;
                while p<=length(ekv_mon) && ~found
                    if isCycEqMonom(word,ekv_mon{p,1}{1,1})
                        p_index=ekv_mon{p,1}{1,2};
                        M2=M2-koef(el)*sparse([p_index(1) p_index(2)],[p_index(2) p_index(1)],[1 1],n_H,n_H);
                        found=1;
                    else
                        p=p+1;
                    end
                end
            end
            count = count +1;
            if norm(M2-M2','fro')+norm(M1-M1','fro')
                fprintf('Problem');
            end
            A{1}(:,count) = M2(:);
            b(count)=0;
            for q=1:m
                if q==i
                    A{q+1}(:,count)=M1(:);
                else
                    A{q+1}(:,count)=zeros(n_S(q)^2,1);
                end
            end
        end
    end
end
  
if H0
    for i=1:size(H0,1)
        for j=i:size(H0,1)
            count = count +1;
            M1=sparse([i j],[j i],[1 1],n_H,n_H); 
            b(count)=2*H0(i,j);
            A{1}(:,count)=M1(:);
            for q=1:m
                A{q+1}(:,count)=zeros(n_S(q)^2,1);
            end
        end
    end
end
          
if messages
    pars_sdp.messages=1;
else
    pars_sdp.messages=0;
end

K.s=[n_H n_S];

if is_rand   %we run Nie methon with random objective
    R0 = randn(n_H,n_H); 
    R=R0'*R0;
    Vp=cell2NCpolys(V);
    [G1,VV,VV_deg]=find_gram(Vp'*R*Vp,V,'sos');
    SDP_data.C=G1(:);
else
    SDP_data.C=G(:);
end
SDP_data.A=A{1};
for i=1:m
    SDP_data.C=[SDP_data.C;zeros(n_S(i)^2,1)];
    SDP_data.A=[SDP_data.A;A{i+1}];  
end
SDP_data.b=b';
SDP_data.K=K;
SDP_data.pars=pars_sdp;

if justSDP_data
    if messages
        fprintf('\n***** Program is quiting because of the .justSDP_data == 1 switch! *****\n');
        fprintf('***** Just the data for the SDP was returned.                      *****\n');
    end
    return;
end


%[XX,Y,INFO]=solveSDP(SDP_data.A,SDP_data.b,SDP_data.C,SDP_data.K,SDP_data.pars);
[XX,Y,INFO]=solveSDP(SDP_data.A,SDP_data.b,SDP_data.C,SDP_data.K,SDP_data.pars);
SDP_data.INFO=INFO;


if messages
    disp([' ']);
    disp(['Residual norm: ' num2str(norm(SDP_data.A'*XX-SDP_data.b))]);
    disp([' ']);
    disp(INFO);
end

if INFO.pinf==1 
    if messages
        fprintf('\n***** Infeasible problem: there is no epsilon such that *****\n');
        fprintf('***** f-epsilon is cyclically equivalent to a SOHS.     *****\n');
    end
    opt=[];
    return;
end


if INFO.dinf == 1
    if messages
        fprintf('\n***** Problem is unbounded - check again. *****\n');
    end
    opt=[];
    return;
end


if INFO.numerr<0
    fprintf('***** ALERT: SDP solver ran into numerical problems.        *****\n');
%     fprintf('***** Press any key to continue with the last data ... *****\n');
%     if messages
        fprintf('***** Trace of polynomial COULD be unbounded from below.        *****\n');
%     end
    error_warn=1;
%     pause;
elseif INFO.numerr==1
    if abs(INFO.feasratio-1)>1e-1
        fprintf('***** ALERT: SDP solver ran into minor numerical problems.                 *****\n');
%         fprintf('***** Press any key to continue with the last data ...                 *****\n');
%         if messages
            if INFO.feasratio < 0.2
                fprintf('***** According to feasratio the trace of polynomial COULD be unbounded from below. *****\n');
            elseif INFO.feasratio > 0.8
                fprintf('***** Nevertheless, according to feasratio given solution might be ok. *****\n');
            else
                fprintf('***** Given solution might be wrong.                                   *****\n');
            end
%         end
        error_warn=1;
%         pause;
    end
elseif INFO.numerr==2
    fprintf('***** ALERT: SDP solver ran into serious numerical problems. *****\n');
    fprintf('***** Press any key to continue with the last data ...   *****\n');
%     if messages
        fprintf('***** Given solution is therefore presumably wrong.      *****\n');
%     end
    pause;
end


    
opt = SDP_data.C'*XX;

if nargout>1
    %prestavil noter
    %ne rabis, ker povozis
    %H=sparse(n_H,n_H);
    Hg=cell(m,1);

    H=reshape(XX(1:n_H^2),n_H,n_H);
    for i=1:m
        Hg{i}=reshape(XX(n_H^2+1+norm(n_S(1:i-1))^2:n_H^2+norm(n_S(1:i))^2),n_S(i),n_S(i));
    end
    ZZ=SDP_data.C-SDP_data.A*Y;
    Z=reshape(ZZ(1:n_H^2),n_H,n_H);
    for i=1:m
        Zg{i}=reshape(ZZ(n_H^2+1+norm(n_S(1:i-1))^2:n_H^2+norm(n_S(1:i))^2),n_S(i),n_S(i));
    end    
%     var_active_ncp=cell2ncpolys(var_active);
%     g=1-var_active_ncp.'*var_active_ncp;
    if decomposition
        decom_sum=0;
        W=cell2NCpolys(base);
        Gw=round(cholPSD(Z)/precision)*precision;
        decom_sohs=Gw*W;
        decom_sum=decom_sohs'*decom_sohs;
        for i=1:m
            Wi=W(1:n_S(i));
            Gwi=round(cholPSD(Zg{i})/precision)*precision;
            decom_S{i}=Gwi*Wi;
            if isempty(decom_S{i})
                decom_S{i}=0;
            end
            decom_sum=decom_sum+decom_S{i}'*S{i}*decom_S{i};
        end
    end
    %prestavil noter
    dif=NCcycEqRep(f-opt-decom_sum);
    decom_err=norm(struct(dif).koef);
end % if nargout>1

if error_warn
    fprintf('\nWARNING! SDP solver returned some numerical problems. Check messages!\n');
end

if rat %we try to find rational solution
    SDP_data1.A=SDP_data.A;
    SDP_data1.b=SDP_data.b;
    [XRat,L,D,P,err]=RprojRldlt(XX,SDP_data1);
end

function precision=NCresetPrecision()

% NCresetPrecision
%
% description: NCresetPrecision resets the precision - the smallest value
% that is considered to be nonzero in numerical calculations (NCsos, NCmin,
% NCdiff, NCisConvex0, NCcycSos, NCcycMin, NCisCycConvex, ...) - to the
% value set in NCparam.m.
% 
% arguments: no arguments
% 
% output: default precision
% 
% see also: NCsetPrecision

% last modified: 11. 12. 2008 KC
% last : 14.3.2018 KC, nargchk -> narginchk

%error(nargchk(0,0,nargin));
narginchk(0,0);


global NC_numeric_precision

NC_numeric_precision=[];

NCparam;

precision=NC_numeric_precision;

clc
echo on

%**************************************************************************
% Cyclic equivalence and sum of hermitian squares                         *
%**************************************************************************
%
% -------------------------------------------------------------------------
% First we construct some symbolic noncommuting variables
% -------------------------------------------------------------------------
NCvars x y
pause % Strike any key to continue. 

% -------------------------------------------------------------------------
% We can check whether two polynomials f and g are cyclically equivalent,
% i.e., whether f - g is a sum of commutators.
% -------------------------------------------------------------------------
NCisCycEq(x^2*y*x + y*x^3, 2*x*y*x^2)
pause % Strike any key to continue. 

% -------------------------------------------------------------------------
% We can construct a canonical cyclically equivalent representative of the
% polynomial
% -------------------------------------------------------------------------
NCcycEqRep(x^2*y*x + y*x^3 + x*y*x + x^2*y - 2*y*x^2)
pause % Strike any key to continue. 

clc
% -------------------------------------------------------------------------
% We can check whether the polynomial is cyclically equivalent to a sum of
% hermitian squares.
% -------------------------------------------------------------------------
pause % Strike any key to continue. 

f = x^4 - 2*x^2*y + y^2 + x*y - y*x;
[IsCycEq,X,base,sohs,g] = NCcycSos(f)
pause % Strike any key to continue. 

% -------------------------------------------------------------------------
% NCcycSos has many optional parameters. For example we can set the
% smallest value that is considered to be nonzero in numerical
% calculations.
% -------------------------------------------------------------------------
pause % Strike any key to continue. 

params.precision = 1e-5;
[IsCycEq,X,base,sohs,g] = NCcycSos(f,params)
pause % Strike any key to continue. 

clc
% -------------------------------------------------------------------------
% We can compute the maximal epsilon such that f-epsilon is cyclically
% equivalent to a sum of hermitian squares. 
% -------------------------------------------------------------------------
pause % Strike any key to continue. 

f = x^4 - 4*x^2*y + 8*y + 4*y^2 - 4*x^2;
[opt,X,base,sohs,g] = NCcycMin(f)
pause % Strike any key to continue. 

% -------------------------------------------------------------------------
% NCcycMin has many optional parameters. For example we can set the
% smallest value that is considered to be nonzero in numerical
% calculations.
% -------------------------------------------------------------------------
pause % Strike any key to continue. 

params.precision = 1e-4;
[opt,X,base,sohs,g] = NCcycMin(f,params)
pause % Strike any key to continue. 

clc
% -------------------------------------------------------------------------
% We can check if the second directional derivative of a polynomial is
% cyclically equivalent to a sum of hermitian squares.
% -------------------------------------------------------------------------
f = 1 + 2*x^2 + x*y + 2*y^2;
[iscConvex,g,sohs,h] = NCisCycConvex(f,10e-5)

pause % Strike any key to end this demonstration. 
echo off
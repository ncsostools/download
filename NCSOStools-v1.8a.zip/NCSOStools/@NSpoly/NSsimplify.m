function g=NSsimplify(f)

% NSsimplify
%
% description: g=NSsimplify(f) simplifies the polynomial f and writes its
% monomials shortly using exponents regardless of the parameter
% NC_using_exponents set in the global option file NCparam.m.
% 
% arguments: NSpoly representing the polynomial f or matrix of NSpolys
% 
% output: simplified NSpoly whose monomials are written with exponents
%
% possible usage: NSsimplify(f)
%
% see also: NSexpand

% last modified: 9. 12. 2014 KC

g=f;
for i=1:size(f,1)
    for j=1:size(f,2)
        koef=f(i,j).koef;
        monom=f(i,j).monom;
        g(i,j)=factor2NSpoly(koef,monom,1);
    end
end

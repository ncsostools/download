function g=NSexpand(f)

% NSexpand
%
% description: g=NSexpand(f) simplifies the polynomial f and writes its
% monomials in expanded form without using exponents regardless of the
% parameter NC_using_exponents set in NCparam.m.
% 
% arguments: NSpoly representing the polynomial f or matrix of NSpolys
% 
% output: simplified NSpoly whose monomials are written without exponents
%
% possible usage: NSexpand(f)
%
% see also: NCsimplify

% last modified: 9. 12. 2014 KC

g=f;
for i=1:size(f,1)
    for j=1:size(f,2)
        koef=f(i,j).koef;
        monom=f(i,j).monom;
        g(i,j)=factor2NSpoly(koef,monom,0);
    end
end

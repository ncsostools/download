function iseq = isequal(f,g)

% isequal
%
% description: iseq = isequal(f,g) is a symbolic isequal test; it returns
% true if and only if f and g represent equal (matrices of) NSpolys. 
% 
% arguments: f and g are NSpolys representing polynomials or matrices of
% NSpolys
% 
% output: logical true (1) if matrices f and g are the same size and
% contain equal NSpolys, and logical false (0) otherwise 
% 
% possible usage: isequal(f,g)

% last modified: 9. 12. 2014 KC

iseq = false;
if isequal(size(f),size(g))
    if all(f==g)
        iseq = true;
    end
end

function D = diag(A,k)

% diag
%
% description: D = diag(A,k) produces diagonal matrices or extracts
% diagonals of a matrix A.
% diag(V,K) when V is a vector with n components is a square matrix of
% order n+ABS(k) with the elements of V on the k-th diagonal.
% k = 0 is the main diagonal, k > 0 is above the main diagonal and k < 0 is
% below the main diagonal.
% diag(V) is the same as diag(V,0) and puts V on the main diagonal.
% diag(X,k) when X is a matrix is a column vector formed from the elements
% of the k-th diagonal of X.
% diag(X) is the main diagonal of X.
%
% arguments:
% A is a vector or matrix of NSpolys
% k is an integer
% 
% output: vector or matrix of NSpolys
% 
% possible usage: diag(A), diag(A,k)

% last modified: 9. 12. 2014 KC

if nargin == 1
    k = 0;
end

if any(size(A)==1)
    m = length(A);
    d = m+abs(k);
    D = NSpoly(zeros(d));
    if k>=0
        for i=1:m
            D(i,i+k) = A(i);
        end
    else
        for i=1:m
            D(i-k,i) = A(i);
        end
    end
else
    [m,n] = size(A);
    if k>=n || (k<0 && -k>=m)
        D=[];
    elseif k>=0
        d = min(m,n-k);
        D=NSpoly(zeros(d,1));
        for i = 1:d
            D(i,1) = A(i,i+k);
        end
    %k<0    
    else
        d = min(m+k,n);
        D=NSpoly(zeros(d,1));
        for i=1:d
            D(i,1) = A(i-k,i);
        end
    end
end

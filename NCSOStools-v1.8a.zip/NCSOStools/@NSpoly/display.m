function display(X)

% display

% last modified: 5. 12. 2014 KC

loose = isequal(get(0,'FormatSpacing'),'loose');
if loose, disp(' '), end
disp([inputname(1) ' =']);
if loose, disp(' '), end
disp(X)
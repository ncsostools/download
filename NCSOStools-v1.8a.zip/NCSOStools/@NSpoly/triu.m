function B = triu(A,k)

% triu
%
% description: B = triu(A,k) extracts upper triangular part of A.
% triu(A) is the upper triangular part of A.
% triu(A,k) is the elements on and above the k-th diagonal of A. k = 0 is
% the main diagonal, k > 0 is above the main diagonal and k < 0 is below
% the main diagonal.
%
% arguments:
% A is a matrix of NSpolys
% k is an integer
% 
% output: matrix of NSpolys
% 
% possible usage: triu(A), triu(A,k)

% last modified: 9. 12. 2014 KC

if nargin == 1
    k = 0;
end

[m,n] = size(A);
B=NSpoly(zeros(m,n));
if k>=n
    return;
elseif (k<0 && -k>=m-1)
    B=A;
else
    d = min(m,n-k);
    for i = 1:d
        zac=max(i+k,1);
        B(i,zac:n) = A(i,zac:n);
    end
end

function g=mrdivide(f,a,string_out)

% mrdivide
%
% description: g=mrdivide(f, a) is called for the syntax 'f / a' and means
% division of coefficients of f by numeric value a.
% 
% arguments: f is NSpoly representing polynomial or matrix of
% NSpolys, a is a numeric
% 
% output: NSpoly representing the polynomial f / a
% 
% possible usage: f / a, mrdivide(f, a)

% created: 8. 3. 2014 KC

if nargin<3 || isempty(string_out) || string_out~=0
    string_out=1;
end

if ~isnumeric(a)
    error('ERROR: second argument must be a numerical value.');
end

poly1=NSpoly(f);

if ndims(poly1) > 2
    error('Input argument must be maximal 2-D.')
else
    g=poly1;
    for i=1:size(poly1,1)
        for j=1:size(poly1,2)
            koef=poly1(i,j).koef / a;
            monom=poly1(i,j).monom;

            g(i,j)=factor2NSpoly(koef,monom,[],[],string_out);
        end
    end
end

function g=char(f)

% char
%
% description: g=char(f) simplifies polynomial f and converts it to its
% string representation.
% 
% arguments: NSpoly representing the polynomial f
% 
% output: string representing the polynomial f
% 
% possible usage: char(f)

% last modified: 6. 12. 2014 KC

g=f.name;
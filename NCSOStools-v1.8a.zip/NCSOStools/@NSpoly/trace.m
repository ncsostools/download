function f = trace(A)

% trace
% description: f = trace(A) is the sum of the diagonal elements of A.
%
% arguments:
% A is a matrix of NSpolys
% 
% output: NSpoly
% 
% possible usage: trace(A)

% last modified: 9. 12. 2014 KC

if size(A,1)~=size(A,2)
	error('ERROR: Matrix must be square.');
end
f = sum(diag(A));

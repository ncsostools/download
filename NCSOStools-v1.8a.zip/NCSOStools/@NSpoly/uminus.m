function g=uminus(f)

% uminus
%
% description: g=uminus(f) is called for the syntax '-f' and means
% symbolic negation.
%
% arguments: NSpoly representing the polynomial f or matrix of NSpolys
%
% output: NSpoly representing the polynomial -f
%
% possible usage: -f, uminus(f)

% last modified: 6. 12. 2014 KC

g=mtimes(-1,f);
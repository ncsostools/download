function h=mtimes(f,g,string_out)

% mtimes
%
% description: h=mtimes(f, g) is called for the syntax 'f * g' and means
% symbolic matrix multiplication.
% 
% arguments: f and g are NSpolys representing polynomials or matrix of
% NSpolys with matching inner dimensions
% 
% output: NSpoly representing the polynomial f * g
% 
% possible usage: f * g, mtimes(f, g)

% last modified: 6. 12. 2014 KC

if nargin<3 || isempty(string_out) || string_out~=0
    string_out=1;
end

poly1=NSpoly(f);
poly2=NSpoly(g);

if ndims(poly1) > 2 || ndims(poly2) > 2
    error('Input arguments must be 2-D.')
elseif all(size(poly1) == 1) &&  all(size(poly2) == 1)
    h = mtimes_simple(poly1,poly2,string_out);
elseif all(size(poly1) == 1)
    if isempty(poly2)
        h = poly2;
    else
        h=poly2;
        for km=1:size(poly2,1)
            for kn=1:size(poly2,2)
                h(km,kn) = mtimes_simple(poly1,poly2(km,kn),string_out);
            end
        end
    end
elseif all(size(poly2) == 1)
    if isempty(poly1)
        h = poly1;
    else
        h=poly1;
        for km=1:size(poly1,1)
            for kn=1:size(poly1,2)
                h(km,kn) = mtimes_simple(poly1(km,kn),poly2,string_out);
            end
        end
    end
elseif size(poly1,2) == size(poly2,1)

    [m1,n1]=size(poly1);
    [m2,n2]=size(poly2);

    h=NSpoly(zeros(m1,n2));
    for km=1:m1
        for kn=1:n2
            temp=0;
            for l=1:n1
                temp=plus(temp,mtimes_simple(poly1(km,l),poly2(l,kn),0),0);
            end
            temp_s=struct(temp);
            kp=temp_s.koef;
            mp=temp_s.monom;
            h(km,kn)=factor2NSpoly(kp,mp,[],[],string_out);
        end
    end
else
    error('Inner matrix dimensions must agree.')
end





function prod=mtimes_simple(f,g,string_out2)

if nargin<3
    string_out2=1;
end

if f==NSpoly(0) || g==NSpoly(0)
    prod=NSpoly(0);
else
    koef1=f.koef;
    monom1=f.monom;
    koef2=g.koef;
    monom2=g.monom;

    st=0;
    len1=length(monom1);
    len2=length(monom2);
    sz=len1*len2;
    kp=zeros(1,sz);
    mp=cell(sz,1);
    for i=1:len1
        for j=1:len2
            st=st+1;
            kp(st)=koef1(i)*koef2(j);
            isne1=~isempty(monom1{i});
            isne2=~isempty(monom2{j});
            if isne1 && isne2
                mp{st,1}=[monom1{i},'*',monom2{j}];
            elseif isne1
            	mp{st,1}=monom1{i};
            elseif isne2
            	mp{st,1}=monom2{j};
            else
                mp{st,1}='';
            end
        end
    end
    prod=factor2NSpoly(kp,mp,[],[],string_out2);
end

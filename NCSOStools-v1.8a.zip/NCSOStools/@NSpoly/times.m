function h=times(f,g)

% times
%
% description: h=times(f, g) is called for the syntax 'f .* g' and means
% symbolic element-by-element multiplication.
% 
% arguments: f and g are NSpolys representing polynomials or matrix of
% NSpolys with matching dimensions
% 
% output: matrix of NSpolys
% 
% possible usage: f .* g, times(f, g)

% last modified: 6. 12. 2014 KC

poly1=NSpoly(f);
poly2=NSpoly(g);

if ndims(poly1) > 2 || ndims(poly2) > 2
    error('Input arguments must be 2-D.')
elseif all(size(poly1) == 1) ||  all(size(poly2) == 1)
    h = poly1*poly2;
elseif size(poly1) == size(poly2)

    [m,n]=size(poly1);

    h=NSpoly(zeros(m,n));
    for i=1:m
        for j=1:n
            h(i,j)=poly1(i,j)*poly2(i,j);
        end
    end
else
    error('ERROR: Matrix dimensions must agree.')
end

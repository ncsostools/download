function h = NCcom(f,g)

% NCcom
%
% description: h = NCcom(f,g) computes comutator f*g-g*f
%
% arguments: f and g are NSpolys representing polynomials
%
% output: NSpoly representing the polynomial f*g-g*f
%
% possible usage: NCcom(f,g)
%
% see also: 

% last modified: 9. 12. 2014 KC
% last : 14.3.2018 KC, nargchk -> narginchk

%error(nargchk(2,2,nargin));
narginchk(2,2);

fp=NSpoly(f);
gp=NSpoly(g);

h=fp*gp-gp*fp;

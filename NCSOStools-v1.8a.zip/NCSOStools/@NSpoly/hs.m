function g = hs(f)

% hs
%
% description: g = hs(f) computes hermitian square f'*f.
%
% arguments: NSpoly representing the nc polynomial f
%
% output: NSpoly representing the polynomial f'*f
%
% possible usage: hs(f)
%
% see also: 

% created: 9.12.2014 KC
% last : 14.3.2018 KC, nargchk -> narginchk

%error(nargchk(1,1,nargin));
narginchk(1,1);

poly=NSpoly(f);

g=poly'*poly;

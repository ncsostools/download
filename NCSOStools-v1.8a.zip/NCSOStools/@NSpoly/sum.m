function s = sum(A,dim)

% sum
%
% description: s = sum(A,dim) is sum of the elements. For vectors, sum(A)
% is the sum of the elements of A. For matrices, sum(A) or sum(A,1) is a
% row vector of column sums and sum(A,2) is a column vector of row sums.
%
% arguments:
% A is a matrix of NSpolys
% dim tells if it is a column (1) or row (2) sum; for matrices is default 1
% 
% output: row/column of NSpolys
% 
% possible usage: sum(A), sum(A,dim)

% last modified: 9. 12. 2014 KC


if nargin == 2 && dim~=1 && dim~=2
    error('ERROR: dim must be 1 or 2!');
end

if nargin == 1 && any(size(A) == 1)
    s = 0;
    n = length(A);
    for i = 1:n-1
        s = plus(s,A(i),0);
    end
    s = s + A(n);
elseif nargin == 1 || dim == 1
    s = NSpoly(zeros(1,size(A,2)));
    n = size(A,1);
    for i = 1:n-1
        s = plus(s,A(i,:),0);
    end
    s = s + A(n,:);
else
    s = NSpoly(zeros(size(A,1),1));
    n = size(A,2);
    for j = 1:n-1;
        s = plus(s,A(:,j),0);
    end
    s = s + A(:,n);
end
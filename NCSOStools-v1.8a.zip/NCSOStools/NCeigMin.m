function [opt,decom_sohs,decom_S,base,SDP_data,Z,Zg,H,Hg,decom_err,Y] = NCeigMin(f,S,d,params)

% NCeigMin
%
% description: [opt,decom_sohs,decom_S,base,SDP_data,Z,Zg,H,Hg,decom_err,Y] = NCeigMin(f,S,d,params)
%     computes the lower bound for the minimum eigenvalue of f on all
%     matrices A = D_S, where S contains polynomials, i.e. lower bound for 
%       inf lambda_min (f(A))
%       s.t. g(A)\succeq 0 for all g in S
% 
% It solves:
%     min <L_f,H>
%     H ... hankel (moment) matrix
%     H(1) = 1
%     H >= 0
%     H^g >= 0
%     (H_g)_p,q = L(p^*gq), for all g in S
% where H is of order |W_{d/2}| and H_g is of order |W_{d/2-deg(g)/2}| and
% d is input
%   This is dual to:
%     sup eps
%     s.t. f-eps = SOHS + \sum_{g\in S}\sum_i h_j^*gh_j
%
% arguments:
% f is an NCpoly representing a polynomial
% S is a set of nc polynomails defining D_S
% d is a starting degree for the hierarchy (even number)
% With params.precision we can set the smallest value that is considered to
%    be nonzero in numerical calculations; if the command is called without
%    it, we assume the precision set with the command NCsetPrecision or the
%    value set in NCparam.m.
% params.messages is used to optionally turn on (1) and off (0) verbose
%    output; default value is 1 (on).
% params.solver sets the solver to be used for SDP and overrides the value
%    set in the global option file NCparam.m. (currently SeDuMi, SDPA-M or
%    SDPT3 are supported)  
% params.eps sets the desired accuracy iy you are using SeDuMi as SDP
%    solver. Setting params.eps=0 lets SeDuMi run as long as it can make
%    progress.
% params.justSDP_data == 1 means that the program ends when the SDP_data is
%    prepared and nothing else is computed. It is optional; the default
%    value is 0.
% params.decomposition == 0 means that no SOHS decomposition over the module 
% will actually be computed. It is optional; the default value is 1.
% 
% output:
% opt ... optimal value of the SDP
% decom_sohs ... sohs part of the sohs decomposition over the module M_{S,d}
% decom_S ... weights of polynomials gin S
% base ... is a list of monomials which appear in the SOHS decomposition
%    over S
% SDP_data ... is a structure holding all the data used in SDP solver
% Z ... dual solution, that represent sohs
% Zg.... dual solution that contains wights
% H ... Hankel matrix
% Hg ... shifted Hankel matrices for g in S
% decom_err ... how much sohs decomposition differs from f
%
% possible usage: NCeigMin(f,S,d),NCeigMin(f,S,d,params)
%
% see also: NCoptBall, NCminCube, NCsos, NCmin, NCopt, NCdiff, NCcycSos,
% NCcycMin, NCsetPrecision, NCsetSolver, NCisConvex, NCisConvex0,
% NCisCycConvex, RProjRldlt
%
%% Call: [opt,decom_sohs,decom_S,base,SDP_data,Z,Zg,H,Hg,decom_err,Y] = NCeigMin(f,S,d,params)

% created: 28. 2. 2013 by J. Povh
% last modified: 16. 12. 2014 by JP
% last modified: 27. 7. 2015 by KC (output Y)
% last modified: 28. 7. 2015 by KC (cleaning)
% 7. 7. 2016 KC: added for complex variables
% last : 14.3.2018 KC, nargchk -> narginchk

%error(nargchk(1,4,nargin));
narginchk(1,4);


poly=NCpoly(f);

base=[];
SDP_data=[];
Z=[];
Zg=[];
H=[];
Hg=[];
%ne rabis?!
Z_dual=[];
decom_sohs=[];
decom_S=[];
opt = [];
decom_err = 0;
Y=[];

pars_sdp='';
justSDP_data=0;
decomposition=1;
%se ne uporabi?!
%module_up=0;
error_warn=0;

if nargin <= 3  
    NCparam;
    precision = NC_numeric_precision;
    messages=true;
elseif nargin == 4
   
    if isfield(params,'messages') && ~isempty(params.messages)
        if params.messages~=true && params.messages~=false
            error('ERROR: .messages must be logical true/false.');
        end
        messages=params.messages;
    else
        messages=true;
    end

    if isfield(params,'precision') && ~isempty(params.precision)
        if ~isnumeric(params.precision)
            error('ERROR: .precision must be a numerical value.');
        end
        precision = params.precision;
    else
        NCparam;
        precision = NC_numeric_precision;
    end
    
    if isfield(params,'solver') && ~isempty(params.solver)
        pars_sdp.solver = params.solver;
    end
    
    if isfield(params,'eps') && ~isempty(params.eps)
        if ~isnumeric(params.eps)
            error('ERROR: .eps must be a numerical value.');
        end
        pars_sdp.eps = params.eps;
    end

    if isfield(params,'justSDP_data') && ~isempty(params.justSDP_data)
        if (params.justSDP_data==1 || params.justSDP_data==true)
            justSDP_data=1;
        end
    end

    if isfield(params,'decomposition') && ~isempty(params.decomposition)
        if (params.decomposition==0 || params.decomposition==false)
            decomposition=0;
        end
    end
    
    % se ne uporabi?!
    %if isfield(params,'module_up') && (params.module_up==1 || params.module_up==0)
    %    module_up=params.module_up;
    %end
    
end



if nargin == 1 % we do eigevalue optimization over all possible matrices
    %[opt,Z_dual,base,decomp_sohs,g,SDP_data,H] = NCmin(f,params);
    %Z_dual? spremenil v Z
    [opt,Z,base,decomp_sohs,g,SDP_data,H] = NCmin(f);
    %dodal return
    return;
end
if messages
    fprintf('\n***** NCSOStools: module NCeigMin started *****\n\n');
end


structpoly=struct(poly);
monom=structpoly.monom;
if length(monom) == 1 && isempty(monom{1})
    fprintf('Polynomial is a constant so the problem is trivial.\n');
    opt = structpoly.koef;
    decom_sohs={0};
    decom_S={};
    base={1};
    SDP_data=[];
    Z=0;
    Zg=0;
    H=1;
    Hg=0;
    decom_err=0;
    return;
end

%  for complex - 7.7.2016
IS_complex1 = ~isreal(structpoly.koef);

if (poly~=poly')
    fprintf('Polynomial is not symmetric: there is no SOHS decomposition over an D_S.\n');
    fprintf('***** Program is quiting. *****\n');
    return;
end


var=NCvarsactive();
deg = compute_deg(poly);
deg_S=zeros(1,size(deg,2));
for i=1:length(S)
    deg_S=deg_S+sum(compute_deg(S{i}),1);
end
vars_active_ind=find(sum(deg,1)+deg_S);
var_active=var(1,vars_active_ind);
deg_active=deg(:,vars_active_ind);
d_f=max(sum(deg_active,2));

if nargin == 2  % default call - we take d=degree(f)/2
    %d = ceil(degree(f)/2);
    d = ceil(d_f/2);
else
    d=ceil(d/2);
end

if messages
    fprintf('Computing full base vector ... ');
end
[V,V_deg] = generateFullV(d,var_active);
base = V;
if messages
    fprintf('done.\n');
end

%

m=length(S); %number of polynomials in S
n_S=[];
d_S=[];
n_H=size(V,1);  % size of matrix H

for i=1:m
    d_S(i) = max(sum(compute_deg(S{i}),2)); %size of H
    n_S(i) = sum(V_deg<=floor(d-d_S(i)/2));   % size of H_{g_i}
end

if messages
    fprintf('Looking for Gram matrix ... ');
end
G=find_gram(f,V,'sos');
if messages
    fprintf('done.\n');
end


% construct SDP
% 

b=[];
A=cell(m+1,1);

A{1,1}=sparse(n_H^2,1); % 
for i=1:m
    A{i+1,1}=sparse(n_S(i)^2,1);
end


% constraint H(1)=1
count =1;
A{1,count} = [1;zeros(n_H^2-1,1)];
for i=1:m
    A{i+1,count} = zeros(n_S(i)^2,1);
end
b(count)=1;


if messages
    fprintf('Computing eq products ... ');
end
ekv_mon = eqProd(V);
ekv_mon_temp = ekv_mon;
if messages
    fprintf('done.\n');
end

if messages
    fprintf('Constructing SDP ... ');
end

% constraints on H
while ~isempty(ekv_mon_temp)
    mon_temp=ekv_mon_temp{1,1}{1,1};
    ind = vertcat(ekv_mon_temp{1,1}{:,2});
    ekv_mon_temp(1,:)=[];
    j=1; terminate = 0;
    while j <= size(ekv_mon_temp,1) && ~terminate
        if strcmp(mon_temp,monom_ast(ekv_mon_temp{j,1}{1,1}))
            ekv_mon_temp(j,:)=[]; 
            terminate = 1;
        end
        j=j+1;
    end
    for j=2:size(ind,1);
        M = sparse([ind(1,1);ind(j,1)],[ind(1,2);ind(j,2)],[-1;1],n_H,n_H); 
        % v realnem in kompleksnem se to mora simetrizirati!
        %if ~IS_complex1
            M=M+M';
        %end
        if norm(M,'fro')
            count = count +1;
            b(count)=0;
            A{1}(:,count) = M(:);
            for i=1:m
                A{i+1}(:,count)=sparse(n_S(i)^2,1);
            end
        end
    end
end

IS_complex2 = false;
for i=1:m  % constraints H_gi(u,v)=\sum_w gi_w L(u^* w v)
    if messages
        fprintf('%d ... ',i);
    end
    
    structpoly=struct(NCpoly(S{i}));
    monom=structpoly.monom;
    koef=structpoly.koef;
    % complex - 7.7.2016 - ce f ni complex, kaksna vez pa je
    if ~isreal(koef)
        IS_complex2 = true;
    end

    for j=1:n_S(i)
        u=ekv_mon{j}{1,1};
        for k=j:n_S(i)
            v=ekv_mon{k}{1,1};
            M1=sparse([k j],[j k],[1 1],n_S(i),n_S(i)); 
            M2=sparse(n_H,n_H);
            for el = 1:length(monom)
                word = concate(concate(monom_ast(u),monom{el}),v);
                found=0;
                p=1;
                while p<=length(ekv_mon) && ~found
                    if strcmp(word,ekv_mon{p,1}{1,1})
                        p_index=ekv_mon{p,1}{1,2};
                        M2=M2-koef(el)*sparse([p_index(1) p_index(2)],[p_index(2) p_index(1)],[1 1],n_H,n_H);
                        found=1;
                    else
                        p=p+1;
                    end
                end
            end
            count = count +1;
            A{1}(:,count) = M2(:);
            b(count)=0;
            for q=1:m
                if q==i
                    A{q+1}(:,count)=M1(:);
                else
                    A{q+1}(:,count)=zeros(n_S(q)^2,1);
                end
            end
        end
    end
end
  
if messages
    fprintf('done.\n');
end

if messages
    pars_sdp.messages=1;
else
    pars_sdp.messages=0;
end

K.s=[n_H n_S];


SDP_data.C=G(:);
SDP_data.A=A{1};
for i=1:m
    SDP_data.C=[SDP_data.C;zeros(n_S(i)^2,1)];
    SDP_data.A=[SDP_data.A;A{i+1}];  
end

% complex - popravi, ce bi zelja bila drugacna!
if (IS_complex1 || IS_complex2)
    K.scomplex=[1:length(K.s)];
    K.ycomplex=[2:length(b)]; % od 2 dalje zaradi opt
end

SDP_data.b=b';
SDP_data.K=K;
SDP_data.pars=pars_sdp;

if justSDP_data
    if messages
        fprintf('\n***** Program is quiting because of the .justSDP_data == 1 switch! *****\n');
        fprintf('***** Just the data for the SDP was returned.                      *****\n');
    end
    return;
end


[XX,Y,INFO]=solveSDP(SDP_data.A,SDP_data.b,SDP_data.C,SDP_data.K,SDP_data.pars);
SDP_data.INFO=INFO;

if messages
    disp([' ']);
    disp(['Residual norm: ' num2str(norm(SDP_data.A'*XX-SDP_data.b))]);
    disp([' ']);
    disp(INFO);
end

% if INFO.pinf==1 || INFO.dinf == 1
%     if messages
%         fprintf('\n***** Polynomial has NO SOHS decomposition over nc ball: primal SDP is INFEASIBLE. *****\n');
%     end
%     return;
% end

if INFO.numerr<0
    fprintf('***** ALERT: SDPT3 ran into numerical problems.        *****\n');
%     fprintf('***** Press any key to continue with the last data ... *****\n');
%     if messages
        fprintf('***** Polynomial MIGHT have NO SOHS decomposition over D_S.     *****\n');
%     end
    error_warn=1;
%     pause;
elseif INFO.numerr==1
    if abs(INFO.feasratio-1)>1e-1
        fprintf('***** ALERT: SeDuMi ran into minor numerical problems.                    *****\n');
%         fprintf('***** Press any key to continue with the last data ...                    *****\n');
%         if messages
% % KC: to sedaj v ncminball zakomentiral
% %             if INFO.feasratio < 0.2
% %                 fprintf('***** According to feasratio polynomial MIGHT have NO SOHS decomposition. *****\n');
% %             elseif INFO.feasratio > 0.8
% %                 fprintf('***** Nevertheless, according to feasratio given solution MIGHT be ok.    *****\n');
% %             else
% %                 fprintf('***** Given solution might be wrong.                                      *****\n');
% %             end
%         end
        error_warn=1;
%         pause;
    end
elseif INFO.numerr==2
    fprintf('***** ALERT: SeDuMi ran into SERIOUS numerical problems. *****\n');
%     if messages
    if abs(INFO.feasratio-1)>1e-1
        fprintf('***** Press any key to continue with the last data ...   *****\n');
        fprintf('***** Given solution is therefore presumably wrong.      *****\n');
        pause;
    else
        fprintf('***** Given solution might be wrong.                     *****\n');
        error_warn=1;
    end
%     end
end
    
opt = SDP_data.C'*XX;

if nargout>1
    %dal noter
    %se povozi, zato zakomentiral
    %H=sparse(n_H,n_H);
    %spremenil v vrstico
    %Hg=cell(m,1);
    Hg=cell(1,m);

    H=reshape(XX(1:n_H^2),n_H,n_H);
    for i=1:m
        Hg{i}=reshape(XX(n_H^2+1+norm(n_S(1:i-1))^2:n_H^2+norm(n_S(1:i))^2),n_S(i),n_S(i));
    end
    ZZ=SDP_data.C-SDP_data.A*Y;
    Z=reshape(ZZ(1:n_H^2),n_H,n_H);
    %dodal
    Zg=cell(1,m);
    for i=1:m
        Zg{i}=reshape(ZZ(n_H^2+1+norm(n_S(1:i-1))^2:n_H^2+norm(n_S(1:i))^2),n_S(i),n_S(i));
    end    
    %     var_active_ncp=cell2ncpolys(var_active);
    %     g=1-var_active_ncp.'*var_active_ncp;
    if decomposition
        %se ne uporabi, ker spodaj povozis
        %decom_sum=0;
        W=cell2NCpolys(base);
        Gw=round(cholPSD(Z)/precision)*precision;
        decom_sohs=Gw*W;    
        decom_sum=decom_sohs'*decom_sohs;
        %dodal
        decom_S=cell(1,m);
        for i=1:m
            Wi=W(1:n_S(i));
            Gwi=round(cholPSD(Zg{i})/precision)*precision;
            decom_S{i}=Gwi*Wi;
            if ~isempty(decom_S{i})
                decom_sum=decom_sum+decom_S{i}'*S{i}*decom_S{i};
            end
        end
    end    
    
    %premaknil od spodaj noter v if>1    
    if isempty(decom_sum)
        dif=f-opt;
    else
        dif=f-opt-decom_sum;
    end
    decom_err=norm(struct(dif).koef);
    if decom_err > 1e-4
        fprintf('\nWARNING! Decomposition for over module M_{S,d} not correct. Primal problem is likely to be infeasible \n');
    end

end % if nargout>1



if error_warn
    fprintf('\nWARNING! SDP solver returned some numerical problems. Check messages!\n');
end


function [X,fX,eig_val,eig_vec]=NCeigOpt(f,S,d)

% NCeigOpt
%
% description: [X,fX,eig_val,eig_vec]=NCeigOpt(f,S,d) computes minimizers
%     and the minimum of the polynomial f on D_S. 
%
% arguments:
% f is an NCpoly representing a polynomial
% S is a set of nc polynomails defining D_S
% d is a starting degree for the hierarchy (even number)
% 
% output:
% X: from GNS - a matrix where each of its rows represents a square matrix
% fX: f(X) where X is from GNS
% eig_val: eigenvalues of fX
% eig_vec: corresponding eigenvectors
%
% possible usage: NCeigOpt(f,S,d)
%
% see also: NCeigMin, GNS, NCoptBall, NCoptCube, NCopt
%
%% Call: [X,fX,eig_val,eig_vec]=NCeigOpt(f,S,d)

% created         7.3.2013 by J. Povh
% last modified:  3.6.2015 by J. Povh

% last modified:  28.7.2015 by KC (cleaning, delete params, A, fA)
% last : 14.3.2018 KC, nargchk -> narginchk

%error(nargchk(2,3,nargin));
narginchk(2,3);


if nargin==2
    d=0;
end
% if nargin==1
%     AW=false;
% end

f=NCpoly(f);

var=NCvarsactive();
deg = compute_deg(f);
deg_S=zeros(1,size(deg,2));
for i=1:length(S)
	deg_S=deg_S+sum(compute_deg(S{i}),1);
end
vars_active_ind=find(sum(deg,1)+deg_S);
var_active=var(1,vars_active_ind);
deg_active=deg(:,vars_active_ind);
d=ceil(d);

X=[];
fX=[];
eig_val=[];
eig_vec=[];
%odstranil
%A=[];
%fA=[];




n=length(var_active);

error_warn=0;

fprintf('\n***** NCSOStools: module NCeigOpt started *****\n\n');

params.messages=0;
params.decomposition=1;
%po moje nima pomena
%params.module_up=1;

%kje rabis?
d_f=max(sum(compute_deg(f),2));

for i=1:length(S)
    d_S(i) = max(sum(compute_deg(S{i}),2)); %sizes of Hg
end
N=5;
ii=1; stop=0;
%dodal
flat=0;
%kje rabis stop? kje se lahko spremeni? pri keyboard? sedaj dodal jaz ...
while ii<N && ~stop
    [opt,decom_sohs,decom_S,base,SDP_data,Z,Zg,H,Hg] = NCeigMin(f,S,d+max(d_S)*ii,params)

    if isempty(H)
        return;
    end

    n_S=zeros(length(S),1);
    %kje rabis?
    n_H=length(H);
    if n==1
        n_small = floor((d+max(d_S)*ii)/2)+1;
    else
        n_small=(n^(floor(d/2+(ii-1)*max(d_S)/2)+1)-1)/(n-1);
    end
    for i=1:length(S)
        n_S(i)=size(Hg{i},1);
    end


    %compute the left upper corner of H, corresponding to words in R<x>_{le d/2}
    H_d=H(1:n_small,1:n_small);
    [rd,r_col,tol_tmp,type]=rank_c(H_d);
    if type~=1
        %kje to rabis?
        tol_tmp=1e-4;
    end


    % computes flat extension of H

    rd1=rank_c(H);
    rd2=rank_c(H(:,1:n_small));
    R=[rd rd1 rd2]
    if rd~=rd1 || rd~=rd2
        % fprintf('\n***** Poisci tol, da bo rank(M_d,tol)==rank(M_d1,tol) *****\n');
        % keyboard;
        fprintf('***** Optimal solution over module M_{S,d+s} is not flat over left upper corner. *****\n');
        fprintf('***** Module NCeigOpt is trying to increase d.                                   *****\n');
        ii=ii+1;
    else
        fprintf('***** Flat extension found over module M_{S,d+s}. *****\n');
        %keyboard;
        %%konec? gns?
        %return
        %dodal stop in flat
        flat=1;
        stop=1;
    end
end

%konec? odstranil in dodelal �e gns
%return;

if ~flat
    fprintf('***** NO flat optimal solution over was FOUND. *****\n');
    fprintf('***** Module NCeigOpt is quiting.              *****\n');
    return;
end

%[X,err]=GNS(base,H_d1,var_active,[],n2);
%dodal in spremenil
[X,err]=GNS(base,H,var_active,[],n_small);

if err>0
    fprintf('\n***** Caution:                         *****\n');
    fprintf('***** GNS module did not end normally. *****\n');
    fprintf('***** Module NCeigOpt is quiting.      *****\n');
    return;
end

% da se izpise, odkomentiraj naslednjo vrstico ...
% X

[N,m]=size(X);
n=sqrt(m);
fprintf('Evaluating X');
subst={};
just_for_test=0;
for j=1:N
    tmp=reshape(X(j,:),n,n);
    % XGNS(:,:,j)=tmp;
    just_for_test=just_for_test+tmp^2;
    subst=[subst,{{NCvariable(var_active{j}),tmp}}];
end
fprintf(' ..... ');
fsubst=NCeval(f,subst);
fX=NCpoly2double(fsubst);
[eig_vec,eig_val]=eig(fX);
% sort
[dum1,dum2]=sort(diag(eig_val));
eig_val=diag(dum1);
eig_vec=eig_vec(:,dum2);

fprintf('completed.\n');

eig_min = eig_val(1,1);
% sort je ze prej narejen, zato je (1,1) res min
fprintf('\n*** Minimum eigenvalue for f is %f. ***\n',eig_min);

if abs(opt-eig_min)>1e-5
    error_warn=1;
    fprintf('\n WARNING: Minimum eigenvalue from GNS and from the dual SDP are different: %f, %f!\n',full(opt),full(eig_min));
    %fprintf('WARNING: Minimum from NCminBall and optimum are different: %f, %f!\n',opt,eig_val(1,1));
else
    fprintf('\n NOTICE:  Minimum eigenvalue from GNS and from the dual SDP are equal: %f, %f!\n',full(opt),full(eig_min));
end

%eps=1e-4;
%if max(eig(just_for_test))>1+eps
%    error_warn=1;
%    fprintf('\nERROR: Optimizers are not in the ball! Maximal eigenvalue: %f!\n',max(eig(just_for_test)));
%elseif max(eig(just_for_test))>1
%    error_warn=1;
%    fprintf('\nWARNING: Optimizers are numerically slightly out of the ball!\nMaximal eigenvalue: %f!\n',max(eig(just_for_test)));
%end



fprintf('\n***** NCSOStools: module NCeigOpt completed');
if error_warn
    fprintf(' with warnings!');
end
fprintf(' *****\n\n');


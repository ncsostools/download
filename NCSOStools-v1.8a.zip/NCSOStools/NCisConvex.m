function isConvex = NCisConvex(f)

% NCisConvex
%
% description: isConvex = NCisConvex(f) checks if the polynomial f is
% convex without SDP.
% 
% arguments: f is an NCpoly representing a polynomial
%
% output: isConvex equals 1 if the polynomial f is convex and 0 otherwise
% 
% possible usage: NCisConvex(f)
%
% see also: NCisCycConvex, NCisConvex0, NC2d, NCsos

% created: 20. 2. 2009 KC
% last modified: 20. 2. 2009 KC
% last : 14.3.2018 KC, nargchk -> narginchk

%error(nargchk(1,1,nargin));
narginchk(1,1);


poly=NCpoly(f);

deg = compute_deg(poly);

m=size(deg,2);
for i=m:-1:1
    if all(deg(:,i)==0)
        deg(:,i)=[];
    end
end

stopnje=sum(deg,2);

d=max(stopnje);
if d>2
    isConvex=false;
    return;
elseif d<2
    isConvex=true;
    return;
else
    m=length(stopnje);
    structpoly=struct(poly);
    koef=structpoly.koef;
    monom=structpoly.monom;
    for i=m:-1:1
        if stopnje(i)<2
            deg(i,:)=[];
            koef(i)=[];
            monom(i)=[];
        end
    end
    g = factor2NCpoly(koef,monom);
    if g~=g'
        isConvex=false;
        return;
    else
        [m,n]=size(deg);
        X=zeros(n);
        for k=1:m
            s=strfind(deg(k,:),2);
            if ~isempty(s)
                X(s,s)=koef(k);
            else
                s=strfind(deg(k,:),1);
                X(s(1),s(2))=koef(k);
                X(s(2),s(1))=koef(k);
            end
        end
        if all(eig(X)>=0)
            isConvex=true;
        else
            isConvex=false;
        end
    end
end
function [opt,g,decom_sohs,decom_cube,base,SDP_data,Z_dual,H,Hshift] = NCminCube(f,params)

% NCminCube
%
% description: [opt,g,decom_sohs,decom_cube,base,SDP_data,Z_dual,H,Hshift] =
% NCminCube(f,params) computes the minimum opt of the polynomial f on an nc
% polydisc.
% It solves:
%     min <L_f,H>
%     H ... hankel (moment) matrix
%     H(1) = 1
%     H >= 0
%     H_shift^j >=0 for all j
%     (H_shift)_(p,q)^j = L(p^*(1-x_j^2)q) for all j
%   WHICH is dual to:
%     sup eps
%     s.t. f-eps = SOHS + \sum_j \sum_i h_(i,j)^*(1-x_j^2)h_(i,j)
%
% arguments:
% f is an NCpoly representing a polynomial.
% With params.precision we can set the smallest value that is considered to
%    be nonzero in numerical calculations; if the command is called without
%    it, we assume the precision set with the command NCsetPrecision or the
%    value set in NCparam.m.
% params.messages is used to optionally turn on (1) and off (0) verbose
%    output; default value is 1 (on).
% params.solver sets the solver to be used for SDP and overrides the value
%    set in the global option file NCparam.m. (currently SeDuMi, SDPA-M or
%    SDPT3 are supported)  
% params.eps sets the desired accuracy iy you are using SeDuMi as SDP
%    solver. Setting params.eps=0 lets SeDuMi run as long as it can make
%    progress.
% params.justSDP_data == 1 means that the program ends when the SDP_data is
%    prepared and nothing else is computed. It is optional; the default
%    value is 0.
% params.decomposition == 0 means that no SOHS decomposition over an nc
%    polydisc will actually be computed. It is optional; the default value
%    is 1.
% params.module_up == 0 means that search for the decomposition is within
%    quadratic module of degree d_max and params.module_up == 1 means
%    module of degree d_max+2; the default value is 0. 
% 
% output:
% opt ... optimal value of the SDP
% g ... represents an nc polydisc
% decom_sohs ... sohs part of the sohs decomposition over nc polydisc
% decom_cube ... weighted part of the sohs decomposition over nc polydisc
% base ... is a list of monomials which appear in the SOHS decomposition
%    over nc polydisc
% SDP_data ... is a structure holding all the data used in SDP solver
% Z_dual ... dual solution
% H ... Hankel matrix
% Hshift ... shifted Hankel matrix
%
% possible usage: NCminCube(f), NCminCube(f,params)
%
% see also: NCoptCube, NCminBall, NCsos, NCmin, NCopt, NCdiff, NCcycSos,
% NCcycMin, NCsetPrecision, NCsetSolver, NCisConvex, NCisConvex0,
% NCisCycConvex, RProjRldlt
%
%% Call: [opt,g,decom_sohs,decom_cube,base,SDP_data,Z_dual,H,Hshift] = NCminCube(f,params)

% last modified: 18. 3. 2011 by KC
% last modified: 21. 11. 2014 by KC (eqProd,cell2NCpolys)
% last : 14.3.2018 KC, nargchk -> narginchk

%error(nargchk(1,2,nargin));
narginchk(1,2);


poly=NCpoly(f);

base=[];
g=NCpoly([]);
SDP_data=[];
H=[];
Hshift=[];
H_f=[];
Hshift_f=[];
Z_dual=[];
decom_sohs=[];
decom_cube=[];
opt = [];

pars_sdp='';
justSDP_data=0;
decomposition=1;
module_up=0;
error_warn=0;


if nargin == 1  % default call
    NCparam;
    precision = NC_numeric_precision;
    messages=true;
elseif nargin == 2  % default call

    if isfield(params,'messages') && ~isempty(params.messages)
        if params.messages~=true && params.messages~=false
            error('ERROR: .messages must be logical true/false.');
        end
        messages=params.messages;
    else
        messages=true;
    end

    if isfield(params,'precision') && ~isempty(params.precision)
        if ~isnumeric(params.precision)
            error('ERROR: .precision must be a numerical value.');
        end
        precision = params.precision;
    else
        NCparam;
        precision = NC_numeric_precision;
    end
    
    if isfield(params,'solver') && ~isempty(params.solver)
        pars_sdp.solver = params.solver;
    end
    
    if isfield(params,'eps') && ~isempty(params.eps)
        if ~isnumeric(params.eps)
            error('ERROR: .eps must be a numerical value.');
        end
        pars_sdp.eps = params.eps;
    end

    if isfield(params,'justSDP_data') && ~isempty(params.justSDP_data)
        if (params.justSDP_data==1 || params.justSDP_data==true)
            justSDP_data=1;
        end
    end

    if isfield(params,'decomposition') && ~isempty(params.decomposition)
        if (params.decomposition==0 || params.decomposition==false)
            decomposition=0;
        end
    end

    if isfield(params,'module_up') && (params.module_up==1 || params.module_up==0)
        module_up=params.module_up;
    end
    
end


if messages
    fprintf('\n***** NCSOStools: module NCminCube started *****\n\n');
end

structpoly=struct(poly);
monom=structpoly.monom;
if length(monom) == 1 && isempty(monom{1})
    fprintf('Polynomial is a constant so there is nothing to do.\n');
    fprintf('***** Module NCSosBall is quiting. *****\n');
    return;
end

if (poly~=poly')
    fprintf('Polynomial is not symmetric: there is no SOHS decomposition over nc polydisc.\n');
    fprintf('***** Module NCminCube is quiting. *****\n');
    return;
end


var=NCvarsactive();
deg = compute_deg(poly);
vars_active_ind=find(sum(deg,1));
var_active=var(1,vars_active_ind);
deg_active=deg(:,vars_active_ind);
num_var_active=length(var_active);


d_max=ceil(max(sum(deg_active,2)/2))*2;
if module_up==0
    meja=d_max/2;
else
    meja=d_max/2+1;
end
[V,V_deg] = generateFullV(meja,var_active);
base = V;
%

G=find_gram(f,V,'sos');


% construct SDP
% 

n1=size(V,1);  % size of matrix H
n2=sum(V_deg<=meja-1);  % size of matrices H_shift_i


% KC - a ne povozis tega v vsakem primeru?
A1=sparse(n1^2,1); % 
% KC - cube
A2=cell(1,num_var_active);
for s=1:num_var_active
    A2{s}=sparse(n2^2,1);
end

ekv_mon = eqProd(V);
count = 0;
ekv_mon_temp = ekv_mon;
% constraints on H
while ~isempty(ekv_mon_temp)
    mon_temp=ekv_mon_temp{1,1}{1,1};
    ind = vertcat(ekv_mon_temp{1,1}{:,2});
    ekv_mon_temp(1,:)=[];
    j=1; terminate = 0;
    while j <= size(ekv_mon_temp,1) && ~terminate
        if strcmp(mon_temp,monom_ast(ekv_mon_temp{j,1}{1,1}))
            % KC: to se ne rabi!
            % ind1 = vertcat(ekv_mon_temp{j,1}{:,2});
            ekv_mon_temp(j,:)=[]; 
            terminate = 1;
        end
        j=j+1;
    end
    for j=2:size(ind,1);
        M = sparse([ind(1,1);ind(j,1)],[ind(1,2);ind(j,2)],[-1;1],n1,n1); 
        M=M+M';
        if norm(M,'fro')
            count = count +1;
            A1(:,count) = M(:);
            for s=1:num_var_active
                A2{s}(:,count)=sparse(n2^2,1);
            end
        end
    end
end


% H_shift ... construction
count_shift=count+1;
% KC - cube 
velikost_dodana=num_var_active*n2*(n2+1)/2;
A1(:,count_shift:count_shift+velikost_dodana-1)=sparse(1,1);
for s=1:num_var_active
    % KC - cube
    A2{s}(:,count_shift:count_shift+velikost_dodana-1)=sparse(1,1);
    for i=1:n2;
        for j=i:n2
            % H_shift_s(p,q)=H(p,q)- H(p x_s,q x_s)
            % M1=sparse(i,j,1,n1,n1); KC: prestavil dol
            % KC: za spodaj
            p1 = concate(var_active{s},V{i,1});
            q1 = concate(var_active{s},V{j,1});
            ind_p=[];
            ind_q=[];      
            el = 1;
            while (el <= size(V,1)) && (isempty(ind_p) || isempty(ind_q))
                if strcmp(p1,V{el,1})
                    ind_p=el; 
                end
                if strcmp(q1,V{el,1})
                    ind_q=el;
                end      
                el = el+1;
            end
            if (isempty(ind_p) || isempty(ind_q))
                fprintf('\n ERROR: p1 and q1 should be found');
            end

            M1=sparse(i,j,1,n1,n1)-sparse(ind_p,ind_q,1,n1,n1);
            M2=sparse(i,j,-1,n2,n2);
            M1=M1+M1'; M2=M2+M2';
            count = count + 1;
            A1(:,count) = M1(:);
            A2{s}(:,count) = M2(:);
        end
    end
end


% constraint H(1)=1
% KC: dodal num_var_active
count = count + 1;
A1(:,count) = [1;zeros(n1^2-1,1)];
% KC - cube
for s=1:num_var_active
    A2{s}(:,count) = zeros(n2^2,1);
end
b=zeros(count,1); b(count)=1;


if messages
    pars_sdp.messages=1;
else
    pars_sdp.messages=0;
end

% KC: dodal num_var_active
K.s=[n1 n2*ones(1,num_var_active)];

% KC: dodal num_var_active
C=[G(:);zeros(n2^2*num_var_active,1)];

% KC - cube
SDP_data.A=[A1;vertcat(A2{:})];
SDP_data.b=b;
SDP_data.C=C;
SDP_data.K=K;
SDP_data.pars=pars_sdp;

if justSDP_data
    if messages
        fprintf('\n***** Program is quiting because of the .justSDP_data == 1 switch! *****\n');
        fprintf('***** Just the data for the SDP was returned.                      *****\n');
    end
    return;
end


[XX,Y,INFO]=solveSDP(SDP_data.A,SDP_data.b,SDP_data.C,SDP_data.K,SDP_data.pars);
SDP_data.INFO=INFO;

if messages
    disp([' ']);
    disp(['Residual norm: ' num2str(norm(SDP_data.A'*XX-SDP_data.b))]);
    disp([' ']);
    disp(INFO);
end

% if INFO.pinf==1 || INFO.dinf == 1
%     if messages
%         fprintf('\n***** Polynomial has NO SOHS decomposition over nc polydisc: primal SDP is INFEASIBLE. *****\n');
%     end
%     return;
% end

if INFO.numerr<0
    fprintf('***** ALERT: SDPT3 ran into numerical problems.        *****\n');
%     fprintf('***** Press any key to continue with the last data ... *****\n');
%     if messages
        fprintf('***** Polynomial MIGHT have NO SOHS decomposition over nc polydisc. *****\n');
%     end
    error_warn=1;
%     pause;
elseif INFO.numerr==1
    if abs(INFO.feasratio-1)>1e-1
        fprintf('***** ALERT: SeDuMi ran into minor numerical problems.                    *****\n');
%         fprintf('***** Press any key to continue with the last data ...                    *****\n');
%         if messages
% % KC: to sedaj v ncmincube zakomentiral
% %             if INFO.feasratio < 0.2
% %                 fprintf('***** According to feasratio polynomial MIGHT have NO SOHS decomposition. *****\n');
% %             elseif INFO.feasratio > 0.8
% %                 fprintf('***** Nevertheless, according to feasratio given solution MIGHT be ok.    *****\n');
% %             else
% %                 fprintf('***** Given solution might be wrong.                                      *****\n');
% %             end
%         end
        error_warn=1;
%         pause;
    end
elseif INFO.numerr==2
    fprintf('***** ALERT: SeDuMi ran into SERIOUS numerical problems. *****\n');
%     if messages
    if abs(INFO.feasratio-1)>1e-1
        fprintf('***** Press any key to continue with the last data ...   *****\n');
        fprintf('***** Given solution is therefore presumably wrong.      *****\n');
        pause;
    else
        fprintf('***** Given solution might be wrong.                     *****\n');
        error_warn=1;
    end
%     end
end

opt = SDP_data.C'*XX;

if nargout>1

    H=reshape(XX(1:n1^2),n1,n1);

    % KC: dodalal, da je vec Hshiftov in vec Z2
    ZZ = C-SDP_data.A*Y;
    Z1 = reshape(ZZ(1:n1^2),n1,n1);
    Z_dual = {Z1};
    star_konec = n1^2;
    Hshift = cell(1,num_var_active);
    Z2 = cell(1,num_var_active);
    for i = 1:num_var_active
        Hshift{i} = reshape(XX(star_konec+1:star_konec+n2^2),n2,n2);
        Z2{i} = reshape(ZZ(star_konec+1:star_konec+n2^2),n2,n2);
        star_konec=star_konec+n2^2;
        Z_dual=[Z_dual,{Z2{i}}];
    end
    
    
    % KC - vec g-jev
    var_active_ncp=cell2NCpolys(var_active);
    for j=1:length(var_active_ncp)
        g(j,1)=1-var_active_ncp(j)^2;
    end

    
    if decomposition
        Wd=cell2NCpolys(base);
        % KC: length(Z2) je bil n2, a ne?
        % W0=Wd(1:length(Z2));
        W0=Wd(1:n2);

        G_Z1=round(cholPSD(Z1)/precision)*precision;

        % KC: vec G_Z2-jev:
        G_Z2=cell(1,num_var_active);
        decom_cube=cell(num_var_active,1);
        for i=1:num_var_active
            G_Z2{i}=round(cholPSD(Z2{i})/precision)*precision;
            decom_sohs=G_Z1*Wd;
            decom_cube{i,1}=G_Z2{i}*W0;
        end
    end
    
end % if nargout>1

if error_warn
    fprintf('\nWARNING! SDP solver returned some numerical problems. Check messages!\n');
end


function [IsCycEq,X,base,sohs,g,SDP_data,L] = NCcycSos(f,params)

% NCcycSos
%
% description: [IsCycEq,X,base,sohs,g,SDP_data,L] = NCcycSos(f,params)
% checks whether the polynomial f is cyclically equivalent to a sum of
% hermitian squares.
% 
% arguments:
% f is an NCpoly representing a polynomial. 
% With params.precision we can set the smallest value that is considered to
%    be nonzero in numerical calculations; if the command is called without
%    it, we assume the precision set with the command NCsetPrecision or the
%    value set in NCparam.m.
% params.messages is used to optionally turn on (1) and off (0) verbose
%    output; default value is 1 (on).
% params.solver sets the solver to be used for SDP and overrides the value
%    set in the global option file NCparam.m. (currently SeDuMi, SDPA-M or
%    SDPT3 are supported)  
% params.eps sets the desired accuracy iy you are using SeDuMi as SDP
%    solver. Setting params.eps=0 lets SeDuMi run as long as it makes
%    progress.
% params.V is a column of monomials to be used as a basis in the SOHS
%    decomposition. It is optional; if the command is called without it, it
%    is constructed automatically.
% params.Vmethod sets the method to get the vector of possible monomials.
%    If it equals -1, the program uses the flawed Newton Cyclic Chip Method 
%    to get the vector of possible monomials and if it equals 0, the
%    program constructs all posible monomials from the Newton polytope
%    using alpha degrees. Default value is the Newton polytope.
% params.obj set the objective function C for the SDP solver. If it equals
%    0, C is a square matrix of zeros (finding the analytic center) and if
%    it equals 1, C is the identity matrix (minimizing rank). Default is 1.
% params.moment == 1 ... we keep all monomials in the base
% params.justSDP_data == 1 means that the program ends when the SDP_data is
%    prepared and nothing else is computed. It is optional; the default
%    value is 0.
% params.decomposition == 0 means that no SOHS decomposition will actually
%    be computed. It is optional; the default value is 1.
% 
% output:
% IsCyceq equals 1 if the polynomial f is cycl. equiv. to a sum of
%    hermitian squares, and 0 otherwise. 
% X is the Gram matrix solution of the corresponding SDP returned by the
%    solver.
% base is a list of monomials which appear in the SOHS decomposition.
% sohs is the SOHS decomposition of the polynomial cyclically equivalent to
%    the polynomial f
% g is the NCpoly representing sum_i m_i^*m_i to which the polynomial f is
%    cyclically equivalent
% SDP_data is a structure holding all the data for the SDP solver
% L is the operator representing the dual optimization problem (L ... the
%    dual feasible SDP matrix)
%
% possible usage: NCcycSos(f), NCcycSos(f,params)
%
% see also: NCcycMin, NCSos, NCmin, NCsetPrecision, NCsetSolver, NCisCycEq,
% NCcycEqRep, NCisCycConvex, NCisConvex, NCisConvex0, RProjRldlt,
% fac_reduct
%
%% Call: [IsCycEq,X,base,sohs,g,SDP_data,L] = NCcycSos(f,params)

% created: 3. 2. 2009 by J. Povh
% last modified: 8. 12. 2009 JP (eliminating bug in line 174)
% last: 26.3.2010 by KC (added operator representing the dual optimization problem)
% change: 9. 5. 2010 KC: sum(sum(deg)~=0) changed to sum(sum(deg,1)~=0) ... bug if only one monomial
% change: 10.5.2010 KC: counting of monomials in 0 or 1 variable 
% last: 6. 6. 2010 KC
% last: 13. 6. 2010 KC (med drugim mv=ekv_mon_v{i,1}{1,1} premaknil pred for)
% last: 8.3.2014
% last modified: 14.3.2018 KC, nargchk -> narginchk

%error(nargchk(1,2,nargin));
narginchk(1,2);

f=NCpoly(f);
justSDP_data=0;
decomposition=1;

IsCycEq=1;
X=[];
sohs=[];
g='';
SDP_data=[];
L=[];
f_orig=f;
lastenV=false;
Vmethod=0;
CforSDP=1;

error_warn=0;

post_do=0;

if nargin == 1  % default call
    NCparam;
    precision = NC_numeric_precision;
    messages=true;
    mom=0;
    post_do=1;
elseif nargin == 2  % default call

    if isfield(params,'messages') && ~isempty(params.messages)
        if params.messages~=true && params.messages~=false
            error('ERROR: .messages must be logical true/false.');
        end
        messages=params.messages;
    else
        messages=true;
    end

    if isfield(params,'precision') && ~isempty(params.precision)
        if ~isnumeric(params.precision)
            error('ERROR: .precision must be a numerical value.');
        end
        precision = params.precision;
    else
        NCparam;
        precision = NC_numeric_precision;
    end
    
    if isfield(params,'solver') && ~isempty(params.solver)
        pars_sdp.solver = params.solver;
    end
    
    if isfield(params,'eps') && ~isempty(params.eps)
        if ~isnumeric(params.eps)
            error('ERROR: .eps must be a numerical value.');
        end
        pars_sdp.eps = params.eps;
    end

    if isfield(params,'V') && ~isempty(params.V)
        if ~iscell(params.V)
            error('ERROR: .V must be a cell.');
        end
        V=params.V;
        lastenV=true;
        base=V;
        % razmisli, ce potrebujes tudi novi f ali lahko klices zgolj prerep
        % za ekv_mon_f
        % Op: rabis pri izpisu, kaj delas - da poves, koliko je manjsi V
        post_do=2;
        errorV=false;
    else
        Vmethod=0;
        if isfield(params,'Vmethod') && ~isempty(params.Vmethod)
            if (params.Vmethod==-1 || params.Vmethod==0) 
                Vmethod=params.Vmethod;
            else
                error('ERROR: .Vmethod must be -1 or 0.');
            end
        end
        post_do=3;
    end

    if isfield(params,'moment') && ~isempty(params.moment)  % this function is called for the moment extension purpose
		mom = params.moment;
    else
		mom = 0;
    end
    
    if isfield(params,'obj') && ~isempty(params.obj)
        if (params.obj==0 || params.obj==1)
            CforSDP=params.obj;
        else
            error('ERROR: .obj must be 0 or 1.');
        end
    end
    
    if isfield(params,'justSDP_data') && ~isempty(params.justSDP_data)
        if (params.justSDP_data==1 || params.justSDP_data==true)
            justSDP_data=1;
        end
    end

    if isfield(params,'decomposition') && ~isempty(params.decomposition)
        if (params.decomposition==0 || params.decomposition==false)
            decomposition=0;
        end
    end

end

if messages
    fprintf('\n***** NCSOStools: module NCcycSos started *****\n\n');

    deg = compute_deg(f_orig);
    structpoly=struct(f_orig);
    monom=structpoly.monom;
    len_m=length(monom);

    len_mon=sum(deg,2);  % contains lengths of monomials
    deg_max=max(len_mon);   % max degree of polynomial
    deg_min=min(len_mon);  % min degree of polynomial

    fprintf('Input polynomial has (max) degree %d and min degree %d.\n',deg_max,deg_min);
    tmp_num_var=sum(sum(deg,1)~=0);
    fprintf('Detected %d monomial',len_m);
    if len_m>1
        fprintf('s');
    end
    fprintf(' in %d variable',tmp_num_var);
    if tmp_num_var>1 || tmp_num_var==0
        fprintf('s');
    end
    fprintf('.\n');

    if tmp_num_var == 0
        tmp_num_all_mon = 1;
        tmp_num_minmax_mon = 1;
    elseif tmp_num_var == 1
        tmp_num_all_mon = deg_max+1;
        tmp_num_minmax_mon = deg_max-deg_min+1;
    else
        tmp_num_all_mon=(tmp_num_var^(deg_max+1)-1)/(tmp_num_var-1);
        tmp_num_minmax_mon=(tmp_num_var^(deg_max+1)-tmp_num_var^deg_min)/(tmp_num_var-1);
    end
    
    fprintf('There are %d monomial',tmp_num_all_mon);
    if tmp_num_all_mon>1
        fprintf('s');
    end
    fprintf(' in %d variable',tmp_num_var);
    if tmp_num_var>1 || tmp_num_var==0
        fprintf('s');
    end
    fprintf(' of degree at most %d.\n',deg_max);

    if deg_min>0
        fprintf('There are %d monomial',tmp_num_minmax_mon);
        if tmp_num_minmax_mon>1
            fprintf('s');
        end
        fprintf(' in %d variable',tmp_num_var);
        if tmp_num_var>1 || tmp_num_var==0
            fprintf('s');
        end
        if deg_max~=deg_min
            fprintf(' of degree at most %d and at least %d.\n',deg_max,deg_min);
        else
            fprintf(' of degree exactly %d.\n',deg_max);
        end
    end

    fprintf('\nPreprocessing the input polynomial ...\n');
end

if post_do>0
    switch post_do
        case 1
            [V,ekv_mon_f,errorV,f]=NCM_cyc(f,messages,Vmethod);
            base=V;
        case 2
            [f,ekv_mon_f]=NCcycEqRep(f);
        case 3
            [V,ekv_mon_f,errorV,f]=NCM_cyc(f,messages,Vmethod);
            base=V;
    end
end

if errorV
    IsCycEq=0;
    return;
end

if f == 0
    fprintf('\n***** Polynomial is cyclically equivalent to 0. *****\n');
    return;
elseif isempty(V) && ~lastenV
    fprintf('\n***** Polynomial is NOT cyclically equivalent to a SOHS (base vector is empty). *****\n');
    return;
elseif isempty(V) && lastenV
    fprintf('\n***** Base vector V is empty - try the default call. *****\n');
    return;
end

if messages
    deg = compute_deg(f);
    structpoly=struct(f);
    monom=structpoly.monom;

    len_m2=length(monom);
    if len_m~=len_m2
        len_m=len_m2;

        len_mon=sum(deg,2);  % contains lengths of monomials
        deg_max=max(len_mon);   % max degree of polynomial
        deg_min=min(len_mon);  % min degree of polynomial

        fprintf('\nReturned cyclically equivalent polynomial with (max) degree %d and min degree %d.\n',deg_max,deg_min);
        tmp_num_var=sum(sum(deg,1)~=0);

		fprintf('Detected %d monomial',len_m);
		if len_m>1
			fprintf('s');
		end
		fprintf(' in %d variable',tmp_num_var);
		if tmp_num_var>1 || tmp_num_var==0
			fprintf('s');
		end
		fprintf('.\n');

		if tmp_num_var == 0
			tmp_num_all_mon = 1;
			tmp_num_minmax_mon = 1;
		elseif tmp_num_var == 1
			tmp_num_all_mon = deg_max+1;
			tmp_num_minmax_mon = deg_max-deg_min+1;
		else
			tmp_num_all_mon=(tmp_num_var^(deg_max+1)-1)/(tmp_num_var-1);
			tmp_num_minmax_mon=(tmp_num_var^(deg_max+1)-tmp_num_var^deg_min)/(tmp_num_var-1);
		end	

		fprintf('There are %d monomial',tmp_num_all_mon);
		if tmp_num_all_mon>1
			fprintf('s');
		end
		fprintf(' in %d variable',tmp_num_var);
		if tmp_num_var>1 || tmp_num_var==0
			fprintf('s');
		end
		fprintf(' of degree at most %d.\n',deg_max);

		if deg_min>0
			fprintf('There are %d monomial',tmp_num_minmax_mon);
			if tmp_num_minmax_mon>1
				fprintf('s');
			end
			fprintf(' in %d variable',tmp_num_var);
			if tmp_num_var>1 || tmp_num_var==0
				fprintf('s');
			end
			if deg_max~=deg_min
				fprintf(' of degree at most %d and at least %d.\n',deg_max,deg_min);
			else
				fprintf(' of degree exactly %d.\n',deg_max);
			end
		end
    end
    
    if lastenV
        fprintf('\nUsing user''s monomial vector with %d monomials.\n',length(V));
    else
        if Vmethod==0
            fprintf('\nUsing alpha degree to construct the monomial vector.\n');
        elseif Vmethod==-1
            fprintf('\nUsing the flawed Newton Cyclic Chip Method for constructing the monomial vector.\n');
        end
        fprintf('Keeping %d monomials in the monomial vector.\n',length(V));
    end
end


if messages
    fprintf('\nComputing cyclically equivalent products ... ');
end
ekv_mon_v = cycEqProd(V);
if messages
    fprintf('done.\n');
    fprintf('\nPreparing linear constraints ...\n');
end


n=size(V,1);  % the size of matrix var. in sdp
m=size(ekv_mon_v,1);

A=[];
b=[];

ind_del = [];
ekv_mon_f_temp=ekv_mon_f;
count = 0;
const_del=[];
ind_star=zeros(m,1);
count_ns=0;
count_sym=0;
for i=1:m
    sz=size(ekv_mon_f_temp,1);
    found = 0;
    mv=ekv_mon_v{i,1}{1,1};
    mv_vsi=cycEqMonoms(mv);
    for j=1:sz;
        % se ne uporabi
        % M=sparse(n,n);
        if any(strcmp(ekv_mon_f_temp{j,1}{1,1},mv_vsi)) % there is j-th monomial in f, cycl. eq. to ekv_mon_v{i,1}
%         if isCycEqMonom(mv,ekv_mon_f_temp{j,1}{1,1}) % there is j-th monomial in f, cycl. eq. to ekv_mon_v{i,1}
            found = 1;
            if ~ind_star(i)  % this equation has not been added before
                ind = vertcat(ekv_mon_v{i,1}{:,2});
                M=sparse(ind(:,1),ind(:,2),ones(size(ind,1),1),n,n);  
                count = count + 1;
                M=(M+M')/2;
                A=[A M(:)];
                b=[b;ekv_mon_f_temp{j,2}];
            end
            ekv_mon_f_temp(j,:)=[];
            break;
        end
    end
    if ~found && ~ind_star(i)    % there is no monomial in f, cycl. eq. to ekv_mon_v{i,1}
        ind = vertcat(ekv_mon_v{i,1}{:,2});
        M = sparse(ind(:,1),ind(:,2),ones(size(ind,1),1),n,n); 
        M = (M+M')/2;
        count = count + 1;
        A = [A M(:)];
        b = [b;0];
        if min(ind(:,1)==ind(:,2))==1    % we will get equation \sum_i X_ii = 0
            ind_del = [ind_del;ind(:,1)];
            const_del=[const_del;count];
        end  
    end 
    mv_ast=monom_ast(mv);
    mv_ast_vsi=cycEqMonoms(mv_ast);

    if ~any(strcmp(mv,mv_ast_vsi))
%   if ~isCycEqMonom(mv,mv_ast)  % we eliminate eq. class corresp. to mv^*
        for k = i+1:m
            if any(strcmp(ekv_mon_v{k,1}{1,1},mv_ast_vsi))
%           if isCycEqMonom(mv_ast,ekv_mon_v{k,1}{1,1})
                ind_star(k) = 1;  % k-th class in ekv_mon_v is marked to be deleted
                count_ns = count_ns+1;
            end
        end
    else 
        count_sym=count_sym+1;
    end
end

if ~isempty(ekv_mon_f_temp)
    fprintf('Polynomial is not cyclically equivalent to sohs (the base vector is not large enough).\n');
    ekv_mon_f_temp{1}
    IsCycEq=0;
    return;
end

nn=length(base);
ok = 0;

while ~ok && ~mom
    base(ind_del,:)='';  % erases entries in base with index in ind_del
    A(:,const_del)=[];  % eliminates constraints corresponding to ind_candidate
    b(const_del)=[];
    m=size(A,2); % # of constraints which have remained
    % just prealloc. - changed by KC
    nnn=nn-length(ind_del);
    A_new=zeros(nnn^2,m);  % new A
    for i=1:m
        Ai=reshape(A(:,i),nn,nn);
        if norm(Ai-Ai','fro')
            keyboard;
        end
        Ai(:,ind_del) = [];
        Ai(ind_del,:) = [];
        A_new(:,i) = Ai(:);
    end
    nn=nnn;
    A=A_new;
    ind_del=[];
    const_del =[];
    for i = 1:size(A,2)
        if ~b(i)
            A_i=sparse(reshape(A(:,i),nn,nn));
            Aoffdiag = diag(diag(A_i))-A_i; % off-diagonal part of A_i
            if ~norm(Aoffdiag,'fro') || ~norm(A_i,'fro') % A_i is diagonal
                where = find(diag(A_i) ~= 0); % indices of non-zero diagonal entries
                if ~isempty(where)
                    ind_del=[ind_del;where];
                end
                const_del = [const_del;i];
            end
        end
    end
    if isempty(const_del)
        ok=1;
    end
end

if n~=nn
    fprintf('Additional optimization of the monomial vector ... Keeping %d monomials ... \n',nn);
end

n=nn;

A=A';
K.s=n;

if CforSDP==1
    C=eye(n);
elseif CforSDP==0
    C=zeros(n);
else
    error('ERROR: Unsupported objective function for the SDP solver.');
end

% dodano za enomonomske - KC - Janez preglej!
if n==1 && length(b)==1
	IsCycEq = b(1) >0;
    if IsCycEq
        X=b(1);
        NCparam;
        simple = NC_using_exponents;
        sohs = factor2NCpoly(sqrt(b(1)),base,simple,abs(log10(precision)));
        g=sohs'*sohs;
    end
	return;
end





m=size(A,1);

% A_sum=sum(A');
A_sum=sum(A,2);

ind_del=[];
for i=1:m
    if (A_sum(i)==0 && b(i)==0)
        ind_del=[ind_del;i];
    elseif A_sum(i)==0 && b(i)~=0
        fprintf('\nPolynomial is NOT cyclically equivalent to a SOHS.\n Contradiction obtained after reduction of constraints.\n');
        IsCycEq=0;
        return;
    end
end
A(:,ind_del)=[];
b(ind_del)=[];
      

if messages
    pars_sdp.messages=1;
else
    pars_sdp.messages=0;
end

C=C(:);
SDP_data.A=A;
SDP_data.b=b;
SDP_data.C=C;
SDP_data.K=K;
SDP_data.pars=pars_sdp;

if justSDP_data
    if messages
        fprintf('\n***** Program is quiting because of the .justSDP_data == 1 switch! *****\n');
        fprintf('***** Just the data for the SDP was returned.                      *****\n');
    end
    return;
end

[XX,Y,INFO]=solveSDP(A,b,C,K,pars_sdp);
if messages
    disp(' ');
    disp(['Residual norm: ' num2str(norm(A*XX-b))]);
    disp(' ');
    disp(INFO);
end

if INFO.pinf==1 || INFO.dinf == 1
    if messages
        fprintf('\n***** Polynomial is NOT CYCLICALLY EQUIVALENT to SOHS. *****\n');
    end
    IsCycEq=0;
    return;
end

if INFO.numerr<0
    fprintf('***** ALERT: SDPT3 ran into numerical problems.              *****\n');
%     fprintf('***** Press any key to continue with the last data ...       *****\n');
%     if messages
        fprintf('***** Polynomial MIGHT not be cyclically equivalent to SOHS. *****\n');
%     end
    error_warn=1;
%     pause;
elseif INFO.numerr==1
    if abs(INFO.feasratio-1)>1e-1
        fprintf('***** ALERT: SeDuMi ran into minor numerical problems.                        *****\n');
%         fprintf('***** Press any key to continue with the last data ...                        *****\n');
%         if messages
            if INFO.feasratio < 0.2
                fprintf('***** According to feasratio the polynomial MIGHT not be cyclically equivalent to SOHS. *****\n');
            elseif INFO.feasratio > 0.8
                fprintf('***** Nevertheless, according to feasratio given solution MIGHT be ok.        *****\n');
            else
                fprintf('***** Given solution might be wrong.                                          *****\n');
            end
%         end
        error_warn=1;
%         pause;
    end
elseif INFO.numerr==2
    fprintf('***** ALERT: SeDuMi ran into SERIOUS numerical problems. *****\n');
    fprintf('***** Press any key to continue with the last data ...   *****\n');
%     if messages
        fprintf('***** Given solution is therefore presumably wrong.      *****\n');
%     end
    pause;
end

if nargout>1
    X=reshape(XX,n,n);

    if nargout>3
		if decomposition
            if messages
                fprintf('Computing SOHS decomposition ... ');
            end
			% dalje pobrano iz NCsos - dodal KC
			G=cholPSD(X);
			GG=round(G/precision)*precision;
			sohs=NCpoly(0);
			count=1;
			for i=1:size(G,1)
				if max(abs(GG(i,:))) > 0

					NCparam;
					simple = NC_using_exponents;
					fact = factor2NCpoly(GG(i,:),base,simple,abs(log10(precision)));

					sohs(count,1)=fact;
					count=count+1;
				end
            end
            
            if nargout>4
				g=sohs'*sohs;
            end
            
            if messages
                fprintf('done.\n');
                fprintf('Found SOHS decomposition with %d factors.\n',length(sohs));
            end
		elseif messages
			fprintf('\n***** No SOHS decomposition was computed because of the .decomposition == 0 switch! *****\n');
		end

        if nargout>6
            % we extract from the dual solution the dual operator L, optimal solution of
            % inf L(f) s.t. L maps R<X>_2d to R, L(1)=1, L(\Theta^2)\ge 0
            L=reshape(C-A'*Y,n,n);
            % if L(1,1) > 1e-5
                L=L/L(1,1);
            % end
        end
    end
end

if error_warn
    fprintf('\nWARNING! SDP solver returned some numerical problems. Check messages!\n');
end


function [g,var_new] = NC2d(f)

% NC2d
%
% description: [g,varnew] = NC2d(f) computes the second derivative of the
% polynomial f:
% g = lim_{t->0} d^2/dt^2 (f(vars + t h))
% where h = (h1, h2, ... , hn) and the polynomial f does not contain any
% of the variables h1, h2, ...
%
% arguments: NCpoly representing the polynomial f
%
% output:
% g is an NCpoly representing the second derivative of the polynomial f
% varnew is a cell containing all NCvars and h
%
% possible usage: NC2d(f)
%
% see also: NCisCycConvex, NCisConvex, NCisConvex0

% created: 19. 9. 2008 by J. Povh
% last modified: 19. 2. 2009 by JP
% last : 14.3.2018 KC, nargchk -> narginchk

%error(nargchk(1,1,nargin));
narginchk(1,1);


poly=NCpoly(f);

var=NCvarsactive();

% we delete/ignore all hi
num_var = length(var);
j=0;
for i=1:num_var
    if length(var{i})==1 || var{i}(1)~='h' || isempty(str2num(var{i}(2:length(var{i}))))
        j=j+1;
        var_tmp{j}=var{i};
    end
end
var=var_tmp;


num_var = length(var);  % number of variables
h=cell(num_var,1);
var_new=cell(2*num_var,1);
for i=1:num_var
    h{i,1}=sprintf('h%d',i);  
    var_new{2*i-1,1}=var{i};
    var_new{2*i,1}=h{i,1};
    if length(var{i})==1 || var{i}(1)~='h' || isempty(str2num(var{i}(2:length(var{i}))))
        assignin('base',h{i,1},NCvariable(h{i,1}));
    end
end

structpoly=struct(poly);
koef=structpoly.koef;
monom=structpoly.monom;


len_m=length(monom);
deg = compute_deg(poly);


len_mon=sum(deg,2);  %contains lengths of monomials

koef_d=[];
monom_d=cell(1,1);
count = 0;
for i=1:length(monom)
    if len_mon(i)==1
        continue;
    end
    mon_curr=monom{i,1};
    ind=strfind(mon_curr,'*');
    for k=1:len_mon(i)-1
        if k==1
            var1 = mon_curr(1:ind(1)-1);
            w = strmatch(var1, var,'exact');
            monom_new=strcat(h{w,1},mon_curr(ind(1):length(mon_curr))); 
        else 
            var1 = mon_curr(ind(k-1)+1:ind(k)-1);
            w = strmatch(var1, var,'exact');
            monom_new=strcat(mon_curr(1:ind(k-1)),h{w,1},mon_curr(ind(k):length(mon_curr))); 
        end
        ind_new=strfind(monom_new,'*');
        for el=k+1:len_mon(i)
            if el==len_mon(i)
                var2 = monom_new(ind_new(el-1)+1:length(monom_new));
                w = strmatch(var2, var,'exact');
                monom_new1=strcat(monom_new(1:ind_new(el-1)),h{w,1});
            else 
                var2 = monom_new(ind_new(el-1)+1:ind_new(el)-1);
                w = strmatch(var2, var,'exact');
                monom_new1=strcat(monom_new(1:ind_new(el-1)),h{w,1},monom_new(ind_new(el):length(monom_new)));
            end       
            count = count +1;
            monom_d{count,1}=monom_new1;
            koef_d(count)=2*koef(i);
        end
    end
end

g=factor2NCpoly(koef_d,monom_d);


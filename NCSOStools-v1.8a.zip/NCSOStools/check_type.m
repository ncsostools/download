function bool = check_type(value,type)
% function checks whether 'value' is of the given type 'type'
% valid 'type's are: string, char, natural

% created: 06112008
% last modified: 14.3.2018 KC, nargchk -> narginchk

%error(nargchk(2,2,nargin))
narginchk(2,2)

switch type
    case {'string', 'char'}
        if ischar(value)==0
            bool=false;
        else
            bool=true;
        end
    case 'natural' % we include 0
        if isnumeric(value)==0
            bool=false;
        elseif abs(round(value))~=value
            bool=false;
        else
            if all(size(value)==1)
                bool=true;
            else
                bool=false;
            end
        end
    otherwise
        error('ERROR: unsupported second argument ''type''')
end

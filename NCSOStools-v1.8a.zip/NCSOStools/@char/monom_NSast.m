function monom2 = monom_NSast(monom)

% computes NS involution monom2 of monomial monom

% last modified: 9. 12. 2014 KC

monom_tmp=monom_ast(monom);

Utmp=upper(monom_tmp);
Ltmp=lower(monom_tmp);
mali=Utmp~=monom_tmp;
velik=Ltmp~=monom_tmp;

% konec=false;
% if ~any(mali)
%     monom_tmp = Ltmp;
%     konec=true;
% elseif ~any(velik)
%     monom_tmp = Utmp;
%     konec=true;
% end
% 
% if ~konec
%     monom_tmp(mali) = Utmp(mali);
%     monom_tmp(velik) = Ltmp(velik);
% end

monom_tmp(mali) = Utmp(mali);
monom_tmp(velik) = Ltmp(velik);

monom2 = monom_tmp;

function monom2 = monom_ast(monom)

% computes involution monom2 of monomial monom

% last modified: 4. 2. 2009 KC
% last modified: 6. 6. 2010 KC (rewriten from scratch)

pozicije=strfind(monom,'*');
if isempty(pozicije)
    monom2=monom;
else
    n=length(monom);
    pos1=[0 pozicije n+1];
    m=length(pos1);
    % pogledam, kje je skok za vec kot 2 - torej je ime sprem. vec kot 1
    kje=find(pos1(2:m)-pos1(1:m-1)>2);
    ind=[n:-1:1];
    if ~isempty(kje)
        s=length(kje);
        ind_popr=[];
        for i=1:s
            dum=[pos1(kje(i))+1:pos1(kje(i)+1)-1;pos1(kje(i)+1)-1:-1:pos1(kje(i))+1];
            ind_popr=[ind_popr dum];
        end
        ind_popr=n+1-ind_popr;
        ind(ind_popr(1,:))=ind(ind_popr(2,:));
    end
    monom2=monom(ind);
end

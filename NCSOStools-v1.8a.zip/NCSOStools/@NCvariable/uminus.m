function x = uminus(a)

x = uminus(NCpoly(a));

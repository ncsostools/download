function x = times(a,b)

x = times(NCpoly(a),NCpoly(b));

function display(X)

%

% last modified: 9. 1. 2009 KC

loose = isequal(get(0,'FormatSpacing'),'loose');
if loose, disp(' '), end
disp([inputname(1) ' =']);
if loose, disp(' '), end
disp(X)
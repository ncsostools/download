function f = trace(A)

f=trace(NCpoly(A));

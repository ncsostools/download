function A = horzcat(varargin)

%

% last modified: 9. 1. 2009 KC
% last modified: 12. 6. 2010 KC

args = varargin;
for k=1:length(args)
    m(k)=size(args{k},1);
    args{k} = NCpoly(args{k});
end
tmp=(m==0);
m(tmp)=[];
args(tmp)=[];
if any(m~=m(1))
    error('ERROR: All matrices must have the same number of rows.');
else
	A = builtin('horzcat',args{:});
end

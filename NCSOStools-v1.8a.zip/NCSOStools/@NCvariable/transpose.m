function B = transpose(A)

B=transpose(NCpoly(A));

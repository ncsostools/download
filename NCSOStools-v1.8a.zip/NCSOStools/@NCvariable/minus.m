function x = minus(a,b)

x = minus(NCpoly(a),NCpoly(b));

function g = hs(f)

g=hs(NCpoly(f));

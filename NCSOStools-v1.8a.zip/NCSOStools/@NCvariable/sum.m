function s = sum(A,dim)

if nargin ==1
    s = sum(NCpoly(A));
else
    s = sum(NCpoly(A),dim);
end
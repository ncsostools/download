function y=NCexpand(x)

y=NCpoly(x);
function iseq=eq(a,b)

if isa(a,'NCvariable')==0 | isa(b,'NCvariable')==0
   iseq=0;
elseif a.name==b.name
   iseq=1;
else
   iseq=0;
end
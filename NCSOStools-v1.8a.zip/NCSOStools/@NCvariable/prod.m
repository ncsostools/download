function p = prod(A,dim)

if nargin ==1
    p = prod(NCpoly(A));
else
    p = prod(NCpoly(A),dim);
end
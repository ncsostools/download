function h = NCcom(f,g)

h = NCcom(NCpoly(f),NCpoly(g));

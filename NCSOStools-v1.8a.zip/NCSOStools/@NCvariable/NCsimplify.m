function y=NCsimplify(x)

y=NCpoly(x);
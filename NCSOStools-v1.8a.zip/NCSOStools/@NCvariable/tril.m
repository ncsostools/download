function B = tril(A,k)

if nargin == 1
    B = tril(NCpoly(A));
else
    B = tril(NCpoly(A),k);
end

function s=NCvariable(x)

%

% last modified: 9. 1. 2009 KC

inferiorto('NCpoly');
superiorto('double');

if isa(x,'NCvariable')
    s=x;
elseif isnumeric(x)
	s=NCpoly(x);
elseif ~ischar(x)
    error('ERROR: conversion to ''NCvariable'' from ''%s'' is not possible. Only strings are accepted.', class(x))
elseif isvarname(x)
    s=class(struct('name',x),'NCvariable');
else
    error('ERROR: invalid variable name ''%s''',x)
end

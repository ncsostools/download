function y = power(x,n)

y = power(NCpoly(x),n);

function disp(X)

%

% last modified: 9. 1. 2009 KC

disp(NCpoly(X))
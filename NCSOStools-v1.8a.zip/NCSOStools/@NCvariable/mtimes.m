function x = mtimes(a,b)

x = mtimes(NCpoly(a),NCpoly(b));

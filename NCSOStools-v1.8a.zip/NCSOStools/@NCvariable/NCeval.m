function g=NCeval(f,subst)

% last : 14.3.2018 KC, nargchk -> narginchk

%error(nargchk(1,2,nargin));
narginchk(1,2);

if nargin==1
    g=NCeval(NCpoly(f));
else
    g=NCeval(NCpoly(f),subst);
end

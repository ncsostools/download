function x = plus(a,b)

x = plus(NCpoly(a),NCpoly(b));

function B = triu(A,k)

if nargin == 1
    B = triu(NCpoly(A));
else
    B = triu(NCpoly(A),k);
end

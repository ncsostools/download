function [success,message]=xlswrite(file,A,sheet,range)

% xlswrite
%

% last modified: 8. 3. 2014 KC

% Set default values.
Sheet1 = 1;

if nargin < 3
    sheet = Sheet1;
    range = '';
elseif nargin < 4
    range = '';
end

[success,message]=xlswrite(file,NCpoly(A),sheet,range);
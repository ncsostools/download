function A = vertcat(varargin)

%

% last modified: 9. 1. 2009 KC
% last modified: 12. 6. 2010 KC

args = varargin;
for k=1:length(args)
    n(k)=size(args{k},2);
    args{k} = NCpoly(args{k});
end
tmp=(n==0);
n(tmp)=[];
args(tmp)=[];
if any(n~=n(1))
    error('ERROR: All matrices must have the same number of columns.');
else
	A = builtin('vertcat',args{:});
end

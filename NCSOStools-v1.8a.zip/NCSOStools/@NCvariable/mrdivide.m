function x = mrdivide(a,b)

x = mrdivide(NCpoly(a),b);

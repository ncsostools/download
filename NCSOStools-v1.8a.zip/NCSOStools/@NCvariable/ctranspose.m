function y = ctranspose(x)

y=ctranspose(NCpoly(x));
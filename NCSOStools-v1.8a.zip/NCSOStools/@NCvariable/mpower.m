function y = mpower(x,n)

y = mpower(NCpoly(x),n);

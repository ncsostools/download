function M = char(A)

M=A.name;
function D = diag(A,k)

if nargin==1
    D=diag(NCpoly(A));
else
    D=diag(NCpoly(A),k);
end

function y=NSsimplify(x)

y=NSpoly(x);
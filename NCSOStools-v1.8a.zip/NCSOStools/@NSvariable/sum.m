function s = sum(A,dim)

if nargin ==1
    s = sum(NSpoly(A));
else
    s = sum(NSpoly(A),dim);
end
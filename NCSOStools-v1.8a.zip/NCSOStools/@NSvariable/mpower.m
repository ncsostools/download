function y = mpower(x,n)

y = mpower(NSpoly(x),n);

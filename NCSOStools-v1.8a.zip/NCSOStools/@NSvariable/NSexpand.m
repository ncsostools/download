function y=NSexpand(x)

y=NSpoly(x);
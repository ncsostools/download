function y = ctranspose(x)

y=ctranspose(NSpoly(x));
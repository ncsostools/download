function B = triu(A,k)

if nargin == 1
    B = triu(NSpoly(A));
else
    B = triu(NSpoly(A),k);
end

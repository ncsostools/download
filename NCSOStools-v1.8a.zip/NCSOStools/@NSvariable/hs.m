function g = hs(f)

g=hs(NSpoly(f));

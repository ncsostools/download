function B = transpose(A)

B=transpose(NSpoly(A));

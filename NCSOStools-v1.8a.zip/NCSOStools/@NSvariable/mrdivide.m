function x = mrdivide(a,b)

x = mrdivide(NSpoly(a),b);

function D = diag(A,k)

if nargin==1
    D=diag(NSpoly(A));
else
    D=diag(NSpoly(A),k);
end

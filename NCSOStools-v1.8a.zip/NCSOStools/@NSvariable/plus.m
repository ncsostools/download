function x = plus(a,b)

x = plus(NSpoly(a),NSpoly(b));

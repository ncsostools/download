function isneq=eq(a,b)

if isa(a,'NSvariable')==0 | isa(b,'NSvariable')==0
   isneq=1;
elseif a.name==b.name
   isneq=0;
else
   isneq=1;
end
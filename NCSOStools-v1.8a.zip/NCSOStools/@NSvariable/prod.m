function p = prod(A,dim)

if nargin ==1
    p = prod(NSpoly(A));
else
    p = prod(NSpoly(A),dim);
end
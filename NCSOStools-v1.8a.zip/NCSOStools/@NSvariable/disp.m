function disp(X)

%

% last modified: 5. 12. 2014 KC

disp(NSpoly(X))
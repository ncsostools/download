function [s1,s2]=NSvariable(x)

%

% last modified: 5. 12. 2014 KC

inferiorto('NSpoly');
superiorto('double');
s2=[];

if isa(x,'NSvariable')
    s1=x;
elseif isnumeric(x)
    s1=NSpoly(x);
elseif ~ischar(x)
    error('ERROR: conversion to ''NSvariable'' from ''%s'' is not possible. Only strings are accepted.', class(x))
elseif isvarname(x)
    s1=class(struct('name',lower(x)),'NSvariable');
    s2=class(struct('name',upper(x)),'NSvariable');
else
    error('ERROR: invalid variable name ''%s''',x)
end

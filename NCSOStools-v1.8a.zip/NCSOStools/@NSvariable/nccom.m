function h = NCcom(f,g)

h = NCcom(NSpoly(f),NSpoly(g));

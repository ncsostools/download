function x = times(a,b)

x = times(NSpoly(a),NSpoly(b));

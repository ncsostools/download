function f = trace(A)

f=trace(NSpoly(A));

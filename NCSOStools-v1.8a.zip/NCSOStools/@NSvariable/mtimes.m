function x = mtimes(a,b)

x = mtimes(NSpoly(a),NSpoly(b));

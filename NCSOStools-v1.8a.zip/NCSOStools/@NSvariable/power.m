function y = power(x,n)

y = power(NSpoly(x),n);

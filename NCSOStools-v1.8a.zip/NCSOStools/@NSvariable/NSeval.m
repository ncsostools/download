function g=NSeval(f,subst)

% last : 14.3.2018 KC, nargchk -> narginchk

%error(nargchk(1,2,nargin));
narginchk(1,2);

if nargin==1
    g=NSeval(NSpoly(f));
else
    g=NSeval(NSpoly(f),subst);
end

function x = minus(a,b)

x = minus(NSpoly(a),NSpoly(b));

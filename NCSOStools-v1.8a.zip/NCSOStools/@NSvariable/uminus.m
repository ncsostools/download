function x = uminus(a)

x = uminus(NSpoly(a));

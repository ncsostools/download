function iseq=eq(a,b)

if isa(a,'NSvariable')==0 | isa(b,'NSvariable')==0
   iseq=0;
elseif a.name==b.name
   iseq=1;
else
   iseq=0;
end
function B = tril(A,k)

if nargin == 1
    B = tril(NSpoly(A));
else
    B = tril(NSpoly(A),k);
end

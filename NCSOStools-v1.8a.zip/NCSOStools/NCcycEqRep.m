function [g,seznam]=NCcycEqRep(f)

% NCcycEqRep
%
% description: g=NCcycEqRep(f) constructs a canonical cyclically equivalent
% representative of the polynomial f.
% 
% arguments: f is an NCpoly representing a polynomial
% 
% output: g is an NCpoly representing a polynomial which is cyclically
% equivalent to the polynomial f
% 
% possible usage: NCcycEqRep(f)
%
% see also: NCisCycEq, NCcycSos, NCcycMin, NCisCycConvex

% created: 3. 2. 2009 KC
% last modified: 18. 2. 2009 KC
% last modified: 14.3.2018 KC, nargchk -> narginchk

%error(nargchk(1,1,nargin));
narginchk(1,1);

seznam=cycEqPreRep(f);
[m,n]=size(seznam);
koef=[];
monom={};
j=0;

for i=1:m
    if seznam{i,2}~=0
        j=j+1;
        % monom{j,1}=seznam{i,1}{1,1}
        tmp=cycEqMonoms(seznam{i,1}{1,1});
        monom{j,1}=tmp{1,1};
        koef(1,j)=seznam{i,2};
    end
end

g=factor2NCpoly(koef,monom);



function precision=NCsetPrecision(value)

% NCsetPrecision
%
% description: NCsetPrecision(precision) sets the precision to be used in
% numerical calculations. It is the smallest value that is considered to
% be nonzero in NCsos, NCmin, NCdiff, NCisConvex0, NCcycSos, NCcycMin,
% NCisCycConvex, ... and overrides the value set in the global option file 
% NCparam.m.
% NCsetPrecision, when called with no arguments returns the current
% precision.
% 
% arguments: no arguments or a numerical value for the precision
% 
% output: new or current precision
% 
% possible usage: NCsetPrecision, NCsetPrecision(precision)
%
% see also: NCresetPrecision, NCSos, NCmin, NCdiff, NCcycSos, NCcycMin,
% NCisConvex0, NCisCycConvex

% last modified: 11. 12. 2008 KC
% last : 14.3.2018 KC, nargchk -> narginchk

%error(nargchk(0,1,nargin));
narginchk(0,1);


global NC_numeric_precision

if nargin==0
	NCparam;
	precision=NC_numeric_precision;
else
	if isnumeric(value)
		if all(size(value)==1)
			NC_numeric_precision=value;
			precision=NC_numeric_precision;
		else
			error('arrays are not supported for precision');
		end
	else
		error('precision must be a numeric value');
	end
end

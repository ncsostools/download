clc
echo on

%**************************************************************************
% Rationalization                                                         *
%**************************************************************************
%
% In this section we will look at the module RprojRldlt which tries to find
% an exact rational positive semidefinite solution of the problem A*X=b
% from the floating point solution XX. The algorithm tries to find an
% appropiate rational approximation of the matrix XX which is after the
% projection on the hyperplane A*X=b a positive semidefinite matrix.
% Module has also an option to try to compute an exact rational LDU
% decomposition of a rational positive semidefinite solution of the problem 
% A*XX=b. Otherwise positive semidefiniteness relies on numerical
% computation of eigenvalues.
% This is usefull whenever we want to find a rational Gram matrix an
% therefore a rational sum of hermitian squares decomposition, i.e. in
% module NCsos, NCmin, NCcycSos, NCcycMin ...
%
% -------------------------------------------------------------------------
% First we construct some symbolic noncommuting variables and polynomial
% -------------------------------------------------------------------------
NCvars x y
f = 1 + 3*x^2*y*x^2*y + 7*x^2*y^2*x^2 + 2*x*y*x + 6*x*y*x*y*x^2;
pause % Strike any key to continue. 

% -------------------------------------------------------------------------
% With NCcycSos we can get numerical solution and therefore numerical
% (inexact) sum of hermitian squares decomposition. This will be our
% starting point in finding exact solution.
% For the rationalization is in most cases better to take objective
% function for the SDP solver to be zero; so we set this in parameter.
% -------------------------------------------------------------------------
pause % Strike any key to continue. 
params.obj = 0; [IsCycEq,XX,base,sohs,g,SDP_data] = NCcycSos(f, params)

pause % Strike any key to continue. 
% -------------------------------------------------------------------------
% Now we can use the algorithm in RprojRldlt to try to find an appropiate
% rational approximation of the matrix XX which is after the projection on
% the hyperplane A*X=b a positive semidefinite matrix; if we succeed in
% finding rational Gram matrix we can therefore get a rational sum of
% hermitian squares decomposition. The next step depends heavily on the
% 'quality' of the Gram matrix XX returned by the SDP solver. Here we
% measure 'quality' as large as possible minimal eigenvalue of XX.
% -------------------------------------------------------------------------
pause % Strike any key to continue. 
Xrat = RprojRldlt(XX,SDP_data,true); Xrat{1}, Xrat{2}

pause % Strike any key to continue. 
% -------------------------------------------------------------------------
% Now we got an exact rational Gram matrix Xrat where Xrat{1} are
% numerators and Xrat{2} adherent denominators. If we also want a rational
% sum of hermitian squares decomposition we need to slightly change a call
% to the module RprojRldlt to get a rational LDU decomposition of Xrat,
% more precise we get a rational decomposition of the form
% Xrat=(P*L)*D*(P*L)^T.
% -------------------------------------------------------------------------
pause % Strike any key to continue. 
[Xrat,L,D,P,err] = RprojRldlt(XX,SDP_data,true);
base
P
D{1}, D{2}
L{1}, L{2}

% If RprojRldlt was succesfull we gain an exact rational in the following
% way:
% - first we permute a base vector according to the permutation matrix P
% - each column of the matrix L corresponds to the coefficients of the one
% hermitian square in the decomposition multiplied by the corresponding
% element in the matrix D.

pause % Strike any key to end this demonstration. 
echo off
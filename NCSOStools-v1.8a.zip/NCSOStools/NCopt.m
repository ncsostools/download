function [X,fX,eig_val,eig_vec,A,fA]=NCopt(f,AW)

% NCopt
%
% description: [X,fX,eig_val,eig_vec,A,fA]=NCopt(f,AW) computes minimizers
% and the minimum of the polynomial f.
%
% arguments:
% f is an NCpoly representing a polynomial.
% AW: true/false whether AWbd is called.
%
% output:
% X: from GNS - a matrix where each of its rows represents a square matrix
% fX: f(X) where X is from GNS
% eig_val: eigenvalues of fX
% eig_vec: corresponding eigenvectors
% A: from AWbd
% fA: f(A) where A is from AWbd - actually on each block of A
%
% possible usage: NCopt(f), NCopt(f,AW)
%
% see also: GNS, AWbd, NCcycOpt, NCmin
%
%% Call: [X,fX,eig_val,eig_vec,A,fA]=NCopt(f,AW)

% last: 5. 6. 2010 KC
% last modified: 14.3.2018 KC, nargchk -> narginchk


%error(nargchk(1,2,nargin));
narginchk(1,2);

if nargin==1
    AW=false;
end
tol=[];

f=NCpoly(f);

X=[];
fX=[];
eig_val=[];
eig_vec=[];
A=[];
fA=[];

error_warn=0;

fprintf('\n***** NCSOStools: module NCopt started *****\n\n');


var=NCvarsactive();

deg = compute_deg(f);

delta = 0;
if ~any(sum(deg,2)==0)  % f does not have a constant term - we add it
    delta=1;
    f=f+delta;
end

vars_active_ind=find(sum(deg,1));

deg=deg(:,vars_active_ind);
var=var(1,vars_active_ind);

d_max=max(sum(deg,2))/2; % max degree in V

if d_max~=round(d_max)
    fprintf('ERROR: Total degree of the polynomial should be even.\n');
    return;
elseif d_max==0
    fprintf('Polynomial is a constant so there is nothing to do.\n');
    fprintf('***** Module NCopt is quiting. *****\n');
    return;
end

% Solving M_d+1 directly (as dual problem to NCmin)

[base_d,V_deg] = generateFullV(d_max,var);

% just for a matrix A and not for actual solution of the problem
V_new_d1 = generateFullV(d_max+1,var);
params.V=V_new_d1;
params.messages = 0;
params.justSDP_data = 1;

% We need only equations AX=b, contained in SDP_data_d1.
[IsSohs_d1,X_d1,base_d1,sohs_d1,g_d1,SDP_data_d1] = NCsos(f,params);
if isempty(SDP_data_d1)
	fprintf('The problem is infeasible (there is no lower bound) for one of\n');
	fprintf('the following reasons:\n');
	fprintf('  - the polynomial is non-symmetric OR \n');
	fprintf('  - the highest degree term is not a sum of hermitian squares\n');
	return;
end

A_d1=SDP_data_d1.A;
b_d1=SDP_data_d1.b;

[m,n]=size(A_d1);
nn=sqrt(n);

G=zeros(nn);
A_dual=[];

for i=1:m  % construction of Gram matrix
    [r,c]=find(reshape(A_d1(i,:),nn,nn));
    E=sparse(r,c,ones(size(r)),nn,nn);
    G=G+b_d1(i)/norm(A_d1(i,:),1)*E;
    [ru,cu]=find(triu(reshape(A_d1(i,:),nn,nn)));
    for j=2:length(ru)
        F=sparse([ru(1) ru(j)],[cu(1) cu(j)],[1 -1],nn,nn);
        F=F+F';
        A_dual=[A_dual;F(:)'];
    end
end

G(1,1)=G(1,1)-delta;  % undo for when we added a constant term (line about 54)
f=f-delta;

A_dual=[[1 zeros(1,nn^2-1)];A_dual];
b_dual=zeros(size(A_dual,1),1);
b_dual(1)=1;
K.s=nn;
[M_d1_sdp,Y_d1,INFO] = solveSDP(A_dual,b_dual,G(:),K,[]);
disp(INFO);

% dokaj pobrano iz ncmin:
if INFO.dinf == 1
    fprintf('\n***** Polynomial is unbounded from below. *****\n');
    return;
end

M_d1_sdp = reshape(M_d1_sdp,nn,nn);
f_dual = trace(G'*M_d1_sdp);

sumimo_probleme=0;

% ce bomo locevali, sicer lahko vse zdruzimo:
% tezave sdpt3-ja
if INFO.numerr<0
    sumimo_probleme=1;
% majhne tezave sedumija
elseif INFO.numerr==1
    % if INFO.feasratio > 0.8
    %    fprintf('***** najverjetneje ok. *****\n');
    % end
    sumimo_probleme=1;
% velike tezave sedumija
elseif INFO.numerr==2
    sumimo_probleme=1;
end

if sumimo_probleme
    fprintf('\n***** Warning: Some numerical problems occur. *****\n');
    fprintf('\n***** Starting advanced testing ... preparing for SDP solver ... *****\n\n');
    
    clear params;
    params.messages=0;
    params.decomposition=0;
    [fmin,dum1,dum2,dum3,dum4,SDP_data]=NCmin(f,params);
    INFO=SDP_data.INFO;
    % iz ncmin
    if INFO.pinf==1 || INFO.dinf == 1
        fprintf('***** Module NCopt is quiting.            *****\n');
        return;
    end
    
    % bi se kaj na feasratio gledali?

    % te meje je potrebno prestudirati, kaj je pametno!
    if abs(fmin-f_dual)<1e-3
        fprintf('\n***** Presumably everything is OK.  *****\n');
        fprintf('***** Continue ...                  *****\n');
    elseif abs(fmin-f_dual)<1e-1
        fprintf('\n***** WARNING!                               *****\n');
        fprintf('***** Maybe lower bound can not be attained. *****\n');
        fprintf('***** Returning an aproximation ...          *****\n');
        fprintf('***** Continue ...                           *****\n');
        error_warn=1;
    else
        fprintf('\n***** Give up because values of minimum differ too much. *****\n');
        fprintf('\n***** Module NCopt is quiting.                           *****\n');
        return;
    end
end

% Computing M_d+1 by extending M_d 
% border for M_{d-1}
where=find(V_deg~=d_max);
n_d_m1=length(where);
if n_d_m1~=max(where)
    fprintf('***** ERROR: Wrong degree!     *****\n');
    fprintf('***** Module NCopt is quiting. *****\n');
    return;
end

% border for M_{d}
n_d = length(base_d);
M_d = M_d1_sdp(1:n_d,1:n_d);
% M_d bi morala priti simetricna, a zaradi numerike v dolocenih primerih ne pride ravno :(
M_d=(M_d+M_d')/2;

% border for M_{d+1}
n_d1 = length(base_d1);

% case 5 v celotni seriji tipov
[r,r_col,tol_tmp,type]=rank_c(M_d);
if type~=1
    tol_tmp=1e-4;
end
B=M_d1_sdp(1:n_d,n_d+1:n_d1);
% krajse kar direkt s psevdoinverzom
% [U,S,V] = svd(M_d);
% Sinv=pinv(S,tol_tmp);
% Z=V*Sinv*U'*B;
Z=pinv(M_d,tol_tmp)*B;
B=M_d*Z;

C=Z'*B;

% C bi morala priti simetricna, a zaradi numerike v dolocenih primerih ne pride ravno :(
C=(C+C')/2;

M_d1=[M_d,B;B',C];

rd=rank_c(M_d);
rd1=rank_c(M_d1);
rd2=rank_c(M_d1(:,1:n_d));

if rd~=rd1 || rd~=rd2
    % fprintf('\n***** Poisci tol, da bo rank(M_d,tol)==rank(M_d1,tol) *****\n');
    % keyboard;
    fprintf('\n***** ERROR:                               *****\n');
    fprintf('***** Flat condition unexpectedly failed. *****\n');
    fprintf('***** Module NCopt is quiting.             *****\n');
    return;
end

[X,err]=GNS(V_new_d1,M_d1,var,tol,n_d);

if err>0
    fprintf('\n***** Caution:                         *****\n');
    fprintf('***** GNS module did not end normally. *****\n');
    fprintf('***** Module NCopt is quiting.         *****\n');
    return;
end

% da se izpise, odkomentiraj naslednjo vrstico ...
% X

[N,m]=size(X);
n=sqrt(m);
fprintf('Evaluating X');
subst={};
for j=1:N
    tmp=reshape(X(j,:),n,n);
    subst=[subst,{{NCvariable(var{j}),tmp}}];
end
fprintf(' ..... ');
fsubst=NCeval(f,subst);
fX=NCpoly2double(fsubst);
[eig_vec,eig_val]=eig(fX);
% sort
[dum1,dum2]=sort(diag(eig_val));
eig_val=diag(dum1);
eig_vec=eig_vec(:,dum2);

fprintf('completed.\n');

% sort je ze prej narejen, zato je (1,1) res min
fprintf('\n*** Minimum eigenvalue for f is %f. ***\n',eig_val(1,1));

if AW && nargout>4
    [Q_hat,bs,A]=AWbd(X);

    [N,m]=size(A);
    n=sqrt(m);

    block_number=length(bs);

    fprintf('Number of simultaneously diagonalized blocks: %d\n', block_number);

    if nargout>5
        start=1;
        fA={};
        for i=1:block_number
            fprintf('Evaluating block number: %d', i);

            bsi=bs(i);
            subst={};
            for j=1:N
                tmp=reshape(A(j,:),n,n);
                tmp=tmp(start:start+bsi-1,start:start+bsi-1);
                subst=[subst,{{NCvariable(var{j}),tmp}}];
            end

            fprintf(' ..... ');

            fsubst=NCeval(f,subst);

            fA=[fA,NCpoly2double(fsubst)];
            start=start+bsi;
            fprintf('completed.\n');
        end
    end
end


fprintf('\n***** NCSOStools: module NCopt completed');
if error_warn
    fprintf(' with warnings!');
end
fprintf(' *****\n\n');


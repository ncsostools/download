function h = factor2NCpoly(koef,monom,simple,dig,string_out)

% factor2NCpoly
%
% description: h = factor2NCpoly(koef,monom,simple,dig) transforms columns
% of active monomials and corresponding coefficients into an NC polynomial
%
% arguments: 
% koef and monom: data representing the polynomial to be converted
% simple ... if using exponents or not
% dig ... when converting coefficients to string we keep dig digits
% string_out ... if construct string representation or not
%
% output: h is an NC polynomial
%
% possible usage: factor2NCpoly(koef,monom,),
% factor2NCpoly(koef,monom,simple), factor2NCpoly(koef,monom,simple,dig),
% factor2NCpoly(koef,monom,simple,dig,string_out)
%
%% Call: h = factor2NCpoly(koef,monom,simple,dig,string_out)

% created: Igor 29082007 modified 30082007 03092007  05112008
% last modified: 28. 2. 2009 KC
% last: 13. 6. 2010 KC
% last modified: 14.3.2018 KC, nargchk -> narginchk

%error(nargchk(2,5,nargin))
narginchk(2,5)

if nargin < 4 || isempty(dig)
	NCparam;
	dig = NC_OPTIONS.precision;
end
if nargin<3 || isempty(simple) || (simple~=0 && simple~=1)
	NCparam;
	simple = NC_using_exponents;
end
if nargin < 5 || isempty(string_out) || string_out~=0
    string_out=1;
end

[koef,monom]=factor2nice(koef,monom);

if all(koef==0)
    h=NCpoly(0);
else
    monom_za_strukt=monom;

    poli='';
    if string_out==1
        d=length(monom);

        if simple==1
            for i=1:d
                monom{i,1}=short(monom{i,1});
            end
        end

        for i=1:d
            if isempty(monom{i})
                if imag(koef(i))==0
                    poli=[poli,num2str(koef(i),dig)];
                else
                    poli=[poli,zapiskomp(koef(i),dig)];
                end
            elseif koef(i)==1 && i==1
                poli=[poli,monom{i}];
            elseif koef(i)==1 && i>1
                poli=[poli,'+',monom{i}];       
            %dodan KC
            elseif koef(i)==-1
                poli=[poli,'-',monom{i}];       
            %realni in imaginarni del
            elseif (imag(koef(i))~=0 && real(koef(i))~=0)
                if i==1
                    poli=[poli,'(',zapiskomp(koef(i),dig),')','*',monom{i}];
                else
                    poli=[poli,'+','(',zapiskomp(koef(i),dig),')','*',monom{i}];
                end
            %od tu dalje samo realni ali samo imaginarni del    
            elseif koef(i)<0
                poli=[poli,num2str(koef(i),dig),'*',monom{i}];
            elseif koef(i)>0
                if i==1
                    poli=[poli,num2str(koef(i),dig),'*',monom{i}];
                else
                    poli=[poli,'+',num2str(koef(i),dig),'*',monom{i}];
                end
            elseif imag(koef(i))<0
                poli=[poli,zapiskomp(koef(i),dig),'*',monom{i}];
            elseif imag(koef(i))>0
                if i==1
                    poli=[poli,zapiskomp(koef(i),dig),'*',monom{i}];
                else
                    poli=[poli,'+',zapiskomp(koef(i),dig),'*',monom{i}];
                end
            end
        end
    end

    h=NCpoly(poli,koef,monom_za_strukt);
end





%enaka funkcija tudi v NCpoly
function novo=zapiskomp(stev,dig)
if real(stev)~=0
    if imag(stev)==1
        novo=[num2str(real(stev),dig),'+i'];
    elseif imag(stev)==-1
        novo=[num2str(real(stev),dig),'-i'];
    else
        novo=num2str(stev,dig);
    end
else
    if imag(stev)==1
        novo='i';
    elseif imag(stev)==-1
        novo='-i';
    else
        novo=[num2str(imag(stev),dig),'i'];
    end
end





function monom2=short(monom1)
% transforms monomial monom1 into form with '^'
% last modified: 28. 2. 2009 KC
pozicije=strfind(monom1,'*');
if isempty(pozicije)
    monom2=monom1;
else
    prvi=true;
    tmp2='';
    n=length(monom1);
    pozicije=[0 pozicije n+1 0];
    k=length(pozicije);
    lastvar=monom1(pozicije(1)+1:pozicije(2)-1);
    varcount=1;
    for i=2:k-1
        var=monom1(pozicije(i)+1:pozicije(i+1)-1);
        if ~strcmp(var,lastvar)
            if varcount==1
                if prvi
                    tmp2=lastvar;
                    prvi=false;
                else
                    tmp2=[tmp2,'*',lastvar];
                end
            else
                if prvi
                    tmp2=[lastvar,'^',sprintf('%.0f',varcount)];
                    prvi=false;
                else
                    tmp2=[tmp2,'*',lastvar,'^',sprintf('%.0f',varcount)];
                end

            end
            lastvar=var;
            varcount=1;
        else
            varcount=varcount+1;
        end
    end
    monom2=tmp2;
end





function mon_t = long(mon)
% transforms monom mon into form  without '^'
% created: 14. 5. 2007 by J. Povh
% last modified: 28. 12. 2008 KC
if strcmp(strtok(mon,'^'),mon)
    mon_t=mon;
else
    mon_t='';
    n=length(mon);
    j=0;
    i=1;
    while i<= n
        if  mon(i)=='*'   % i should point to char right after '*'
            i=i+1;
        end
        [base,rest]=strtok(mon(i:n),'*^'); 
        if (i+length(base)< n) && (mon(i+length(base))=='^')
            [num,rest]=strtok(mon(i+length(base)+1:n),'*');
            exp=str2num(num);
            if exp==[];
                error('ERROR: Invalid exponent in monomial.');
            end
            for k=1:exp  % repeats base (exp-1)-times
                j=j+1;
                if (~isempty(mon_t))
                    mon_t=[mon_t,'*',base];
                else
                    %mon_t=strcat(mon_t,base);  
                    mon_t=base;  
                end
            end  % for
            i=i+length(base)+length(num)+1;
        else
            if (~isempty(base)) && (~isempty(mon_t))
                mon_t=[mon_t,'*',base];
            else
                mon_t=[mon_t,base];
            end
            i=i+length(base);
        end   
    end    %  while
end





function [k2,m2] = factor2nice(koef,monom)

% gets rid of zeros in [koef,monom] and sorts monomials in monom

% created: 28. 2. 2009 KC

m2=cell(1,1);
k2=[];
if isempty(koef)
    k2=0;
    m2{1,1}='';
    return;
end

[m2,sort_ind,ind]=unique(monom);
n=length(m2);
if n==length(monom)
    k2=koef(sort_ind);
else
    k2=zeros(1,n);
    for i=1:n
        k2(i)=sum(koef(ind==i));
    end
end

brisi=(k2==0);
m2(brisi)=[];
k2(brisi)=[];

if isempty(k2)
    k2=0;
    m2{1,1}='';
    return;
end


function [k2,m2] = factor2nice_old(koef,monom)
% gets rid of zeros in [koef,monom] and sorts monomials in monom

% created: Igor 29082007

m2=cell(1,1);
k2=[];
if isempty(koef)
    k2=0;
    m2{1,1}='';
    return;
end
[mon_sort,ind]=sort(monom);
last=1;
simple_monom=cell(1,1);
simple_monom{last,1}=mon_sort{1,1};
simple_koef(last)=koef(ind(1));
j=2; 
d=length(monom);
while j<=d
    if (strcmp(mon_sort{j,1},simple_monom{last,1}))
        simple_koef(last)=simple_koef(last)+koef(ind(j));
    else
        last=last+1;
        simple_monom{last,1}=mon_sort{j,1};
        simple_koef(last)=koef(ind(j));
    end
    j=j+1;
end
d=length(simple_monom);
last=1;
for i=1:d
    if simple_koef(i)~=0
        k2(last)=simple_koef(i);
        m2(last,1)=simple_monom(i,1);
        last=last+1;
    end
end
if isempty(k2)
    k2=0;
    m2{1,1}='';
    return;
end
function solver=NCresetSolver()

% NCresetSolver
%
% description: NCresetSolver resets the choice of a solver to be used for
% SDP in NCsos, NCmin, NCdiff, NCisConvex0, NCcycSos, NCcycMin,
% NCisCycConvex, ... - to the value set in NCparam.m.
% 
% arguments: no arguments
% 
% output: default solver
% 
% see also: NCsetSolver

% last modified: 18. 4. 2010 KC
% last : 14.3.2018 KC, nargchk -> narginchk

%error(nargchk(0,0,nargin));
narginchk(0,0);

global NC_active_solver

NC_active_solver=[];

NCparam;

solver=NC_active_solver;

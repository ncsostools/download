function [epsilon,X,base,sohs,h,SDP_data] = NCdiff(f,g,params)

% NCdiff
%
% description: [epsilon,X,base,sohs,h,SDP_data] = NCdiff(f,g,params)
% computes the maximal epsilon such that the polynomial f-epsilon*g is a
% sum of hermitian squares.
% 
% arguments:
% f and g are NCpolys representing polynomials.
% With params.precision we can set the smallest value that is considered to
%    be nonzero in numerical calculations; if the command is called
%    without it, we assume the precision set with the command
%    NCsetPrecision or the value set in NCparam.m.
% params.messages is used to optionally turn on (1) and off (0) verbose
%    output; default value is 1 (on).
% params.solver sets the solver to be used for SDP and overrides the value
%    set in the global option file NCparam.m. (currently SeDuMi, SDPA-M or
%    SDPT3 are supported)  
% params.eps sets the desired accuracy iy you are using SeDuMi as SDP
%    solver. Setting params.eps=0 lets SeDuMi run as long as it can make
%    progress.
% params.justSDP_data == 1 means that the program ends when the SDP_data is
%    prepared and nothing else is computed. It is optional; the default
%    value is 0.
% params.decomposition == 0 means that no SOHS decomposition will actually
%    be computed. It is optional; the default value is 1.
% 
% output:
% epsilon is the maximal number such that f-epsilon*g is a sum of
%    hermitian squares
% X is the Gram matrix solution of the corresponding SDP returned
%    by the solver
% base is a vector of monomials appearing in the SOHS decomposition
%    of the polynomial f-epsilon*g
% sohs is the SOHS decomposition of the polynomial f-epsilon*g
% h is the NCpoly representing SOHS decomposition of the polynomial
%    f-epsilon*g
% SDP_data is a structure holding all the data used in SDP solver
% 
% possible usage: NCdiff(f,g), NCdiff(f,g,params)
%
% see also: NCsos, NCmin, NCsetPrecision, NCsetSolver, NCisConvex0
%
%% Call: [epsilon,X,base,sohs,h,SDP_data] = NCdiff(f,g,params)

% created: 16. 10. 2008 by J. Povh
% last modified: 4. 2. 2009 KC
% last: 9. 10. 2010 KC
% last : 14.3.2018 KC, nargchk -> narginchk

%error(nargchk(2,3,nargin));
narginchk(2,3);


poly1=NCpoly(f);
poly2=NCpoly(g);
justSDP_data=0;
decomposition=1;

sohs=[];
base=[];
X=[];
epsilon=[];
h=[];
SDP_data=[];

pars_sdp='';

var=NCvarsactive();

if nargin==2  %default call
    NCparam;
    precision = NC_numeric_precision;
    messages=true;
    params=[];
else
    
    if isfield(params,'messages') && ~isempty(params.messages)
        if params.messages~=true && params.messages~=false
            error('ERROR: .messages must be logical true/false.');
        end
        messages=params.messages;
    else
        messages=true;
    end

    if isfield(params,'precision') && ~isempty(params.precision)
        if ~isnumeric(params.precision)
            error('ERROR: .precision must be a numerical value.');
        end
        precision = params.precision;
    else
        NCparam;
        precision = NC_numeric_precision;
    end
    
    if isfield(params,'solver') && ~isempty(params.solver)
        pars_sdp.solver = params.solver;
    end
    
    if isfield(params,'eps') && ~isempty(params.eps)
        if ~isnumeric(params.eps)
            error('ERROR: .eps must be a numerical value.');
        end
        pars_sdp.eps = params.eps;
    end

    if isfield(params,'justSDP_data') && ~isempty(params.justSDP_data)
        if (params.justSDP_data==1 || params.justSDP_data==true)
            justSDP_data=1;
        end
    end

    if isfield(params,'decomposition') && ~isempty(params.decomposition)
        if (params.decomposition==0 || params.decomposition==false)
            decomposition=0;
        end
    end

end

num_var = length(var);  % number of variables

structpoly1=struct(poly1);
structpoly2=struct(poly2);
koef1=structpoly1.koef;
monom1=structpoly1.monom;
koef2=structpoly2.koef;
monom2=structpoly2.monom;


% we check if f=alfa*g
m=length(koef1);
if length(koef2)==m && isequal(monom1,monom2)
    test=true;
    if m==1
        alfa=koef1/koef2;
    else
        alfa=koef1(1)/koef2(1);
        for i=2:m
            if koef1(i)~=alfa*koef2(i)
                test=false;
                break;
            end
        end
    end

    if test
        tmp_param='';
        if ~isempty(params)
            tmp_param=params;
        end
        tmp_param.messages=false;

        IsSohs = NCsos(-poly2,tmp_param);
        if IsSohs
            fprintf('\n***** Problem is unbounded: epsilon_max = infinity. *****\n');
        else
            epsilon=alfa;
            sohs=0;
            h=0;
            fprintf('\n***** Optimal solution found: epsilon_max = %2.6f *****\n',epsilon);
        end
        return;
    end    
end



%***********************************************************


monom=monom1;
koef=[koef1' zeros(length(koef1),1)];
last = length(koef1)+1;
for i=1:length(monom2)
    found = 0;
    for j=1:length(monom1)
        if strcmp(monom2{i},monom1{j})
            koef(j,2)=koef2(i);
            found = 1;
            break;
        end
    end
    if ~found   %  monom2{i} does not appear in monom1 - we add it to the list
        % dodal 1 v monom - kc
        monom{last,1}=monom2{i};
        koef(last,1)=0;
        koef(last,2)=koef2(i);
        last = last+1;
        found = 0;
    end  
end    

ix = 1:length(koef);
poly=factor2NCpoly(ix,monom);  % we compose polynomial with coefficient 1 and monomials, which is union of monomials 
                               % from poly1 and poly2

[A,b,C,base,deg,info] = NCprepare_data(poly,var,1);  % prepares SDP data for the problem

if info == 0  && isempty(b)   % this happens if NCprepare_data quited by return 
    % There is no non-zero solution - we check if polynomial 1 is sohs

    tmp_param='';
    if ~isempty(params)
        tmp_param=params;
    end
    tmp_param.messages=false;

    [IsSohs,X,base,sohs,h] = NCsos(poly1,tmp_param);  
    if IsSohs
        epsilon = 0;
        if messages
            fprintf('\n***** Polynomial1 is SOHS: epsilon_max = 0 *****\n');
        end
    else
        fprintf('\n***** Problem is infeasible *****\n');
    end    
    return;
elseif info == -1  % error in the input data 
    return;
end

% change the sedumi data to cover the real problem
m=size(b,1);
n=size(C,1);
K.s=n;
K.f=1;
for i=1:m
    if b(i)  
        AA(i,:)=[koef(b(i),2) A(i,:)];
        bb(i,1)=koef(b(i),1);
    else
        AA(i,:)=[0 A(i,:)];
        bb(i,1)=0;
    end  
end

c=[-1;zeros(n^2,1)];

if messages
    pars_sdp.messages=1;
else
    pars_sdp.messages=0;
end

SDP_data.A=AA;
SDP_data.b=bb;
SDP_data.C=c;
SDP_data.K=K;
SDP_data.pars=pars_sdp;

if justSDP_data
    if messages
        fprintf('\n***** Program is quiting because of the .justSDP_data == 1 switch! *****\n');
        fprintf('***** Just the data for the SDP was returned.                      *****\n');
    end
    return;
end

[XX,Y,INFO]=solveSDP(AA,bb,c,K,pars_sdp);

if messages
    disp([' ']);
    disp(['Residual norm: ' num2str(norm(AA*XX-bb))]);
    disp([' ']);
    disp(INFO);
end

if INFO.pinf==1 
    fprintf('\n***** Problem is infeasible. *****\n');
    return;
end
if INFO.dinf == 1
    fprintf('\n***** Problem is unbounded: epsilon_max = infinity. *****\n');
    return;
end

if INFO.numerr<0
    fprintf('***** ALERT: SDPT3 ran into numerical problems.          *****\n');
    fprintf('***** Press any key to continue with the last data ...     *****\n');
%     if messages
        fprintf('***** Polynomial MIGHT be UNBOUNDED or problem INFEASIBLE. *****\n');
%     end
%     pause;
elseif INFO.numerr==1
    if abs(INFO.feasratio-1)>1e-1
        fprintf('***** ALERT: SeDuMi ran into minor numerical problems.               *****\n');
        fprintf('***** Press any key to continue with the last data ...                 *****\n');
    %     if messages
            if INFO.feasratio < 0.2
                fprintf('***** According to feasratio problem COULD be infeasible or unbounded. *****\n');
            elseif INFO.feasratio > 0.8
                fprintf('***** Nevertheless, according to feasratio given solution might be ok. *****\n');
            else
                fprintf('***** Given solution might be wrong.                                   *****\n');
            end
    %     end
%         pause;
    end
elseif INFO.numerr==2
    fprintf('***** ALERT: SeDuMi ran into serious numerical problems. *****\n');
    fprintf('***** Press any key to continue with the last data ...     *****\n');
%     if messages
        fprintf('***** Given solution is therefore presumably wrong.        *****\n');
%     end
    pause;
end


epsilon = XX(1);

X=reshape(XX(2:n^2+1),n,n);

if nargout>3
    if decomposition
        if messages
            fprintf('Computing SOHS decomposition ... ');
        end
        G=cholPSD(X);
        GG=round(G/precision)*precision;
        sohs=NCpoly(0);
        count=1;
        for i=1:size(G,1)
            if max(abs(GG(i,:))) > 0

                NCparam;
                simple = NC_using_exponents;
                fact = factor2NCpoly(GG(i,:),base,simple,abs(log10(precision)));

                sohs(count,1)=fact;
                count=count+1;
            end
        end

        if nargout>4
            h=sohs'*sohs;
        end
        
        if messages
            fprintf('done.\n');
            fprintf('Found SOHS decomposition with %d factors.\n',length(sohs));
        end
    elseif messages
        fprintf('\n***** No SOHS decomposition was computed because of the .decomposition == 0 switch! *****\n');
    end
end

if messages
    fprintf('\n***** Optimal solution found:  epsilon_max = %2.6f *****\n',epsilon);
end


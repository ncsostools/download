function [isConvex,g,sohs] = NCisConvex0(f,precision)

% NCisConvex0
%
% description: [isConvex,g,sohs] = NCisConvex0(f,precision) checks if the
% polynomial f is convex, i.e., if its second directional derivative is a
% sum of hermitian squares.
% 
% arguments: f is an NCpoly representing a polynomial.
% With precision we can set the smallest value that is considered to be
% nonzero in numerical calculations; if the command is called without it,
% we assume the precision set with the command NCsetPrecision or the value
% set in NCparam.m.
%
% output:
% isConvex equals 1 if the polynomial f is convex and 0 otherwise
% g is an NCpoly representing the second derivative of the polynomial f
% sohs is a SOHS decomposition for the polynomial g if the polynomial
%    f is convex
% 
% possible usage: NCisConvex0(f), NCIsConvex0(f,precision)
%
% see also: NC2d, NCisConvex, NCsetPrecision, NCsetSolver, NCsos

% created: 19.9.2008 by J. Povh
% last modified: 5. 1. 2009 KC
% last : 14.3.2018 KC, nargchk -> narginchk

%error(nargchk(1,2,nargin));
narginchk(1,2);


poly=NCpoly(f);

if nargin == 1  %default call
    NCparam;
    precision = NC_numeric_precision;
end

g = NC2d(poly);

params.precision=precision;
params.messages=0;

[isConvex,X,base,sohs] = NCsos(g,params);


function f=BMV(m,k)

% BMV
%
% description: f=BMV(m,k) constructs the (m,k) BMV polynomial with x and
% y as arguments = the sum of all words of total degree m and degree k in y
%
% arguments: m and k are non-negative integers
%
% output: f is the corresponding BMV polynomial
%
% possible usage: BMV(m,k)
%
% see also: BMVq
%
%% Call: f=BMV(m,k)

% last modified: 18. 4. 2010 KC
% last : 14.3.2018 KC, nargchk -> narginchk

%error(nargchk(2,2,nargin));
narginchk(2,2);


if (check_type(m,'natural')==0 || check_type(k,'natural')==0)
    error('ERROR: Inputs must be non-negative integers.');
elseif m<k
    error('ERROR: First argument must NOT be smaller than the second argument.');
elseif m==0 && k==0
    error('ERROR: Both arguments are zero.');
end

P=[m-k k];

V=constructBMV_V(P);

dum1=size(V,1);
koefs=ones(1,dum1);

assignin('base','x',NCvariable('x'));
assignin('base','y',NCvariable('y'));

f=factor2NCpoly(koefs,V);

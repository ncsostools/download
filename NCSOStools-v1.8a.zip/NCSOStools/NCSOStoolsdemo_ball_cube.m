clc
echo on

%**************************************************************************
% Nonnegativity on nc ball and nc polydisc and extracting corresponding   *
% minimizers                                                              *
%**************************************************************************
%
% -------------------------------------------------------------------------
% First we construct some symbolic noncommuting variables and some
% polynomial
% -------------------------------------------------------------------------
NCvars x y
f = 2 - x^2 + x*y^2*x - y^2;
pause % Strike any key to continue. 

% -------------------------------------------------------------------------
% We can compute the optimal value on the nc ball
% -------------------------------------------------------------------------
pause % Strike any key to continue. 

NCminBall(f)
pause % Strike any key to continue. 

% -------------------------------------------------------------------------
% Similarly we can compute the optimal value on the nc polydisc
% -------------------------------------------------------------------------
pause % Strike any key to continue. 

NCminCube(f)
pause % Strike any key to continue. 

clc
% -------------------------------------------------------------------------
% Together with the optimal value opt we can also return a certificate for
% positivity of f-opt for example on nc ball (and similarly on nc
% polydisc), i.e., a sohs decomposition with weights for f-opt.
% -------------------------------------------------------------------------
pause % Strike any key to continue. 

[opt,g,decom_sohs,decom_ball] = NCminBall(f)
pause % Strike any key to continue. 

% -------------------------------------------------------------------------
% NCminBall (and NCminCube) has many optional parameters. For example we
% can set the smallest value that is considered to be nonzero in numerical
% calculations.
% -------------------------------------------------------------------------
pause % Strike any key to continue. 

params.precision=1e-6;
[opt,g,decom_sohs,decom_ball] = NCminBall(f,params)
pause % Strike any key to continue. 

% -------------------------------------------------------------------------
% Let's check the obtained sohs decomposition with weights for f-opt.
% -------------------------------------------------------------------------
pause % Strike any key to continue. 

f-opt
decom_sohs'*decom_sohs + decom_ball'*g*decom_ball
pause % Strike any key to continue. 

clc
% -------------------------------------------------------------------------
% We can also compute minimizers to attain optimal value on nc ball.
% -------------------------------------------------------------------------
pause % Strike any key to continue. 

[X,fX,eig_val,eig_vec]=NCoptBall(f)

% It means that with A=reshape(X(1,:),5,5) and B=reshape(X(2,:),5,5) we get
% f(A,B) as fX with minimal eigenvalue eig_val(1,1) (which is also an
% optimal value on nc ball) and corresponding eigenvector eig_vec(:,1).

pause % Strike any key to continue. 

% -------------------------------------------------------------------------
% Similarly we can also compute minimizers to attain optimal value on nc
% polydisc).
% -------------------------------------------------------------------------
pause % Strike any key to continue. 

[X,fX,eig_val,eig_vec]=NCoptCube(f)

% It means that with A=reshape(X(1,:),5,5) and B=reshape(X(2,:),5,5) we get
% f(A,B) as fX with minimal eigenvalue eig_val(1,1) (which is also an
% optimal value on nc polydisc) and corresponding eigenvector eig_vec(:,1).

pause % Strike any key to end this demonstration. 
echo off
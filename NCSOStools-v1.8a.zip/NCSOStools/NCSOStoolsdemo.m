% NCSOStoolsdemo
%
% Description: NCSOStools Demonstration (brief tutorial and examples)
%

% if ~(exist('NCSOStoolsdemo_basics','file')==2)
%     fprintf('\nERROR: You have to set the path to the demo library (...\\NCSOStools\\demos\\)!\n\n')
%     return;
% end

demo{1}.opis='Toolbox for symbolic computation with polynomials in noncommuting variables';
demo{1}.ukaz='NCSOStoolsdemo_basics';

demo{2}.opis='Sum of hermitian squares (SOHS) related';
demo{2}.ukaz='NCSOStoolsdemo_sohs';

demo{3}.opis='Cyclic equivalence and sum of hermitian squares';
demo{3}.ukaz='NCSOStoolsdemo_cycsohs';

demo{4}.opis='Extracting minimizers or trace minimizers';
demo{4}.ukaz='NCSOStoolsdemo_minimizers';

demo{5}.opis='Rationalization';
demo{5}.ukaz='NCSOStoolsdemo_rationalize';

demo{6}.opis='Nonnegativity on nc ball and nc polydisc and extracting corresponding minimizers';
demo{6}.ukaz='NCSOStoolsdemo_ball_cube';

koliko=length(demo);

while (1)
    clc;
    echo off
    
    fprintf('\n\n  * ** *** **** ***** NCSOStools Demonstration ***** **** *** ** *\n\n');

    for i = 1:koliko
        fprintf('  %i) %s\n\n',i,demo{i}.opis);
    end
    fprintf('  %i) Quit\n\n',koliko+1);

    inp = input('Select demo: ');
    try
        if ~isempty(inp)
            switch(inp)
                case koliko+1
                    fprintf('Demonstration of NCSOStools is quiting ...\n\n');
                    return;
                otherwise
                    if inp<=koliko
                        eval(demo{inp}.ukaz);
                    end
            end
        end
    catch
        disp(lasterr);
        pause
    end
end


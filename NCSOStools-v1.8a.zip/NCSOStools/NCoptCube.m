function [X,fX,eig_val,eig_vec,A,fA]=NCoptCube(f,AW)

% NCoptCube
%
% description: [X,fX,eig_val,eig_vec,A,fA]=NCoptCube(f,AW) computes
% minimizers and the minimum of the polynomial f on an nc polydisc.
%
% arguments:
% f is an NCpoly representing a polynomial.
% AW: true/false whether AWbd is called.
%
% output:
% X: from GNS - a matrix where each of its rows represents a square matrix
% fX: f(X) where X is from GNS
% eig_val: eigenvalues of fX
% eig_vec: corresponding eigenvectors
% A: from AWbd
% fA: f(A) where A is from AWbd - actually on each block of A
%
% possible usage: NCoptCube(f), NCoptCube(f,AW)
%
% see also: GNS, AWbd, NCminCube, NCoptBall, NCopt
%
%% Call: [X,fX,eig_val,eig_vec,A,fA]=NCoptCube(f,AW)

% last modified: 18. 3. 2011 by KC
% XGNS lahko spodaj brises!
% last : 14.3.2018 KC, nargchk -> narginchk

%error(nargchk(1,2,nargin));
narginchk(1,2);


if nargin==1
    AW=false;
end

f=NCpoly(f);
var=NCvarsactive();
deg = compute_deg(f);
var_active=var(1,sum(deg,1)>0);

X=[];
fX=[];
eig_val=[];
eig_vec=[];
A=[];
fA=[];

error_warn=0;

fprintf('\n***** NCSOStools: module NCoptCube started *****\n\n');

params.messages=0;
params.decomposition=0;
params.module_up=1;

[opt,g,decom_sohs,decom_cube,base,SDP_data,Z_dual,H] = NCminCube(f,params);

% napaka v NCminCube ... recimo f ni simetricen ipd.
if isempty(H)
    return;
end


n1=length(H);
n2=length(Z_dual{2});

% computes flat extension of H
H_d=H(1:n2,1:n2);
[r,r_col,tol_tmp,type]=rank_c(H_d);
if type~=1
    tol_tmp=1e-4;
end
B=H(1:n2,n2+1:n1);
Z=pinv(H_d,tol_tmp)*B; % pseudo inverse
B=H_d*Z;
C=Z'*B;
% C bi morala priti simetricna, a zaradi numerike v dolocenih primerih ne pride ravno :(
C=(C+C')/2;

H_d1=[H_d,B;B',C];


% test za psd h_d_shift za kocko ni sprogramiran


rd=rank_c(H_d);
rd1=rank_c(H_d1);
rd2=rank_c(H_d1(:,1:n2));

if rd~=rd1 || rd~=rd2
    % fprintf('\n***** Poisci tol, da bo rank(M_d,tol)==rank(M_d1,tol) *****\n');
    % keyboard;
    fprintf('\n***** ERROR:                               *****\n');
    fprintf('***** Flat condition unexpectedly failed. *****\n');
    fprintf('***** Module NCoptCube is quiting.             *****\n');
    return;
end

[X,err]=GNS(base,H_d1,var_active,[],n2);

if err>0
    fprintf('\n***** Caution:                         *****\n');
    fprintf('***** GNS module did not end normally. *****\n');
    fprintf('***** Module NCoptCube is quiting.         *****\n');
    return;
end

% da se izpise, odkomentiraj naslednjo vrstico ...
% X

[N,m]=size(X);
n=sqrt(m);
fprintf('Evaluating X');
subst={};
just_for_test=[];
for j=1:N
    tmp=reshape(X(j,:),n,n);
    % XGNS(:,:,j)=tmp;
    just_for_test=[just_for_test,max(eig(tmp))];
    subst=[subst,{{NCvariable(var_active{j}),tmp}}];
end
fprintf(' ..... ');
fsubst=NCeval(f,subst);
fX=NCpoly2double(fsubst);
[eig_vec,eig_val]=eig(fX);
% sort
[dum1,dum2]=sort(diag(eig_val));
eig_val=diag(dum1);
eig_vec=eig_vec(:,dum2);

fprintf('completed.\n');

% sort je ze prej narejen, zato je (1,1) res min
fprintf('\n*** Minimum eigenvalue for f is %f. ***\n',eig_val(1,1));

if abs(opt-eig_val(1,1))>1e-5
    error_warn=1;
    fprintf('WARNING: Minimum from NCminCube and optimum are different: %f, %f!\n',opt,eig_val(1,1));
end

eps=1e-4;
if max(just_for_test)>1+eps
    error_warn=1;
    fprintf('\nERROR: Optimizers are not in the nc polydisc! Maximal eigenvalue: %f!\n',max(just_for_test));
elseif max(just_for_test)>1
    error_warn=1;
    fprintf('\nWARNING: Optimizers are numerically slightly out of the nc polydisc!\nMaximal eigenvalue: %f!\n',max(just_for_test));
end


if AW && nargout>4

    [Q_hat,bs,A]=AWbd(X);

    [N,m]=size(A);
    n=sqrt(m);

    block_number=length(bs);

    fprintf('Number of simultaneously diagonalized blocks: %d\n', block_number);

    if nargout>5
        start=1;
        fA={};
        for i=1:block_number
            fprintf('Evaluating block number: %d', i);

            bsi=bs(i);
            subst={};
            for j=1:N
                tmp=reshape(A(j,:),n,n);
                tmp=tmp(start:start+bsi-1,start:start+bsi-1);
                subst=[subst,{{NCvariable(var{j}),tmp}}];
            end

            fprintf(' ..... ');

            fsubst=NCeval(f,subst);

            fA=[fA,NCpoly2double(fsubst)];
            start=start+bsi;
            fprintf('completed.\n');
        end
    end
end


fprintf('\n***** NCSOStools: module NCoptCube completed');
if error_warn
    fprintf(' with warnings!');
end
fprintf(' *****\n\n');


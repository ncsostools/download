clc
echo on

%**************************************************************************
% Toolbox for symbolic computation with polynomials in noncommuting       *
% variables                                                               *
%**************************************************************************
%
% -------------------------------------------------------------------------
% First we construct some symbolic noncommuting variables.
% -------------------------------------------------------------------------
NCvars x y z
pause % Strike any key to continue. 

% -------------------------------------------------------------------------
% Now we can define some polynomials in noncommuting variables.
% -------------------------------------------------------------------------
f = x^2 + 5*x*y - y*z + 3*x*y*z;
g = 2*y*z - z^2;
pause % Strike any key to continue. 

% -------------------------------------------------------------------------
% All basic arithmetic operations are defined in standard way.
% -------------------------------------------------------------------------
f + g, f - g, f*g, -f, g^2, g'
pause % Strike any key to continue. 

clc
% -------------------------------------------------------------------------
% We can also define matrices of such polynomials.
% -------------------------------------------------------------------------
A = [2*x*y, x]
B = [x*y + x, y; y^2, x - y]
pause % Strike any key to continue. 

% -------------------------------------------------------------------------
% All basic operations on such matrices are defined.
% -------------------------------------------------------------------------
A*B, B*B, B.*B, A', trace(B), diag(B), triu(B), [A; sum(B)]
pause % Strike any key to continue. 

% -------------------------------------------------------------------------
% We can also do symbolic (in)equality test.
% -------------------------------------------------------------------------
B
B + diag(diag(B)) == tril(B) + triu(B)
B ~= B'
pause % Strike any key to continue. 

clc
% -------------------------------------------------------------------------
% We can evaluates a polynomial with substitutions and write monomials
% shortly using exponents or in expanded form without using exponents
% regardless of the parameter NC_using_exponents set in NCparam.m.
% -------------------------------------------------------------------------
f
NCeval(f,{{x,x+y},{y,x-y},{z,0}})
NCexpand(ans)
NCsimplify(ans)

pause % Strike any key to end this demonstration. 
echo off
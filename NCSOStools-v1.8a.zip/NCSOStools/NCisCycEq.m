function iscyceq = NCisCycEq(f,g,tol)

% NCisCycEq
%
% description: iscyceq = NCisCycEq(f,g) checks whether polynomials
% f and g are cyclically equivalent, i.e., whether f - g is a sum of
% commutators.
% 
% arguments: f and g are NCpolys representing the polynomials. If the
% function is called with only one parameter, g is assumed to be 0. That
% is, NCisCycEq(f) checks whether f is a sum of commutators.
% if tol > 0 than function checks if the sum of all coefficients of the
% cyclic representative of f-g is less than tol
% 
% output: iscyceq equals 1 if polynomials f and g are cyclically
% equivalent (up to tolenace tol)  and 0 otherwise
% 
% possible usage: NCisCycEq(f,g), NCisCycEq(f), NCisCycEq(f,g,tol)
%
% see also: NCcycEqRep, NCcycSos, NCcycMin, NCisCycConvex

% created: 2. 2. 2009 KC
% last modified: 2. 2. 2009 KC
% last modified: 12. 6. 2010 KC
% last modified 3.3.2013: by JP: added option tol
% last modified: 8. 3. 2014
% last : 14.3.2018 KC, nargchk -> narginchk

%error(nargchk(1,3,nargin));
narginchk(1,3);


if nargin == 1
	poly=NCpoly(f);
else
% 	poly=NCpoly(f)-NCpoly(g);
	poly=minus(NCpoly(f),NCpoly(g),0);
end

if nargin < 3
  tol = 0;
end
if poly==0
    iscyceq=1;
else
    structpoly=struct(poly);
    koefs=structpoly.koef;
    monoms=structpoly.monom;
    
    if size(monoms,1)==1
        iscyceq=0;
    else
        iscyceq=1;
        while ~(isempty(koefs))
%             testni=monoms{1,1};
            eqmonoms=cycEqMonoms(monoms{1,1}); % 20100612
            koefSum=koefs(1,1);

            tmp=length(koefs);
            brisi=false(tmp,1);
            brisi(1)=true;
            
            for i=2:size(monoms,1)
%                 if isCycEqMonom(testni, monoms{i,1})
                if any(strcmp(monoms{i,1},eqmonoms)) % 20100612
                    koefSum = koefSum + koefs(1,i);
                    brisi(i)=true;
                end
            end
            
            if abs(koefSum)<=tol
                monoms(brisi)=[];
                koefs(brisi)=[];
            else
                iscyceq=0;
                return;
            end
        end
    end
end

clc
echo on

%**************************************************************************
% Extracting minimizers or trace minimizers                               *
%**************************************************************************
%
% -------------------------------------------------------------------------
% First we construct some symbolic noncommuting variables
% -------------------------------------------------------------------------
NCvars x y
pause % Strike any key to continue. 

% -------------------------------------------------------------------------
% We can compute minimizers and the minimum of the polynomial.
% -------------------------------------------------------------------------
pause % Strike any key to continue. 

f = (1 - y + x*y + y*x)'*(1 - y + x*y + y*x) + (-2 + y^2)^2 + (-x + x^2)^2;
[X,fX,eig_val,eig_vec] = NCopt(f)

% It means that with A=reshape(X(1,:),4,4) and B=reshape(X(2,:),4,4) we get
% f(A,B) as fX with minimal eigenvalue eig_val(1,1) (which is also a
% minimum) and corresponding eigenvector eig_vec(:,1).
pause % Strike any key to continue. 

clc
% -------------------------------------------------------------------------
% Whenever the tracial moment matrix corresponding to the polynomial is
% flat we can also compute trace minimizers and the trace minimum of that
% polynomial
% -------------------------------------------------------------------------
pause % Strike any key to continue. 

f1 = 3 + x^2 + 2*x^3 + 2*x^4 + x^6 - 4*x^4*y + x^4*y^2 + 4*x^3*y;
f2 = 2*x^3*y^2 - 2*x^3*y^3 + 2*x^2*y - x^2*y^2 + 2*x^2*y^3 - 4*x*y;
f3 = 8*x*y*x*y + 4*x*y^2 + 6*x*y^4 - 2*y + y^2 - 4*y^3 +  2*y^4 + 2*y^6;
f = f1 + f2 + f3;
[X,f_min] = NCcycOpt(f)

% We get a matrix X each of whose rows represent a square matrix
% A_i=reshape(X(i,:),4,4) that is a trace minimizer for f. The matrices A_i
% are simultaneously block diagonal. f_min represents the trace minimum of
% f; Each element in this vector equals the trace of the evaluation of f in
% equally positioned diagonal blocks consisting of matrices A_i.

pause % Strike any key to end this demonstration. 
echo off
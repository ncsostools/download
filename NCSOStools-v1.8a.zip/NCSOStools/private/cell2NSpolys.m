function polys=cell2NSpolys(cell)

n=length(cell);
for i=1:n
    polys(i,1)=factor2NSpoly(1,cell(i));
end
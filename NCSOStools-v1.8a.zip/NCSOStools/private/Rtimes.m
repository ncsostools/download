function C=Rtimes(A,B)

stev1=A{1};
imen1=A{2};
stev2=B{1};
imen2=B{2};

if all(size(stev1) == 1) && all(size(stev2) == 1)
    [C{1},C{2}]=Rtimes_simple(stev1,imen1,stev2,imen2);
elseif all(size(stev1) == 1)
    [m,n]=size(stev2);
    imen3=imen2;
    stev3=stev2;
    for i=1:m
       for j=1:n
           [stev3(i,j),imen3(i,j)]=Rtimes_simple(stev1,imen1,stev2(i,j),imen2(i,j));
       end
    end
    C={stev3,imen3};
elseif all(size(stev2) == 1)
    [m,n]=size(stev1);
    imen3=imen1;
    stev3=stev1;
    for i=1:m
       for j=1:n
           [stev3(i,j),imen3(i,j)]=Rtimes_simple(stev1(i,j),imen1(i,j),stev2,imen2);
       end
    end
    C={stev3,imen3};
elseif size(stev1,2) == size(stev2,1)
    [m1,n1]=size(stev1);
    [m2,n2]=size(stev2);
    stev3=zeros(m1,n2);
    imen3=ones(m1,n2);
    for km=1:m1
        for kn=1:n2
            temp={0,1};
            for l=1:n1
                [tmp2{1},tmp2{2}]=Rtimes_simple(stev1(km,l),imen1(km,l),stev2(l,kn),imen2(l,kn));
                temp=Rplus(temp,tmp2);
            end
            stev3(km,kn)=temp{1};
            imen3(km,kn)=temp{2};
        end
    end
    C={stev3,imen3};
else
    error('Inner matrix dimensions must agree.')
end




function [st3,im3]=Rtimes_simple(st1,im1,st2,im2)
st3=st1*st2;
im3=im1*im2;
dum=gcd(st3,im3);
st3=st3/dum;
im3=im3/dum;

function G=cholPSD(A)

% Cholesky decomposition for positive semidefinite (not necessarily stricly
% positive). If A is not positive definite, G is computed from an eigenvalue 
% decomposition of A.

[G,p] = chol(A);

%positive semidefinite (and not definite):
if p>0
    [V,D] = eig(full(A));
    if any(diag(D)<-1e-5)
        fprintf('\n***** WARNING (cholPSD): *****\nMatrix is possibly not a positive definite!\nSetting those eigenvalues to 0!\n');
    end
    D(D<0)=0;
    G=sqrt(D)*V';
end
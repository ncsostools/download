function [opt,decom_sohs,decom_S,base,SDP_data,Z,Zg,H,Hg,decom_err] = NCeigMinRand(f,H0,S,d,params)

% NCeigMinRand
%
% description: this function tries to extend Hankel matrix to a flat
%     solution by using idea of J. Nie: 
% It solves:
%     min <R,H>
%     H ... hankel (moment) matrix
%     H(1) = 1
%     H >= 0
%     H^g >= 0
%     (H_g)_p,q = L(p^*gq), for all g in S
%     H_{\le d-1} = H0  .. H0 is optimal solution of problem for d (is of
%     order d)
%     R .. random gram matrix
% where H is of order |W_{d/2+1}| and H_g is of order |W_{d/2-deg(g)/2}|
% and d is input
%
% arguments:
% f is an NCpoly representing a polynomial.
% H0
% S
% d
% With params.precision we can set the smallest value that is considered to
%    be nonzero in numerical calculations; if the command is called without
%    it, we assume the precision set with the command NCsetPrecision or the
%    value set in NCparam.m.
% params.messages is used to optionally turn on (1) and off (0) verbose
%    output; default value is 1 (on).
% params.solver sets the solver to be used for SDP and overrides the value
%    set in the global option file NCparam.m. (currently SeDuMi, SDPA-M or
%    SDPT3 are supported)  
% params.eps sets the desired accuracy iy you are using SeDuMi as SDP
%    solver. Setting params.eps=0 lets SeDuMi run as long as it can make
%    progress.
% params.justSDP_data == 1 means that the program ends when the SDP_data is
%    prepared and nothing else is computed. It is optional; the default
%    value is 0.
% params.decomposition == 0 means that no SOHS decomposition over S
% will actually be computed. It is optional; the default value is 1.
% params.obj == 0 - put objective function to be zero matrix - usefule if
% we want to maximize rank
% 
% output:
% opt ... optimal value of the SDP
% decom_sohs ... sohs part of the sohs decomposition over S
% decom_S ... weights of polynomials g\in S
% base ... is a list of monomials which appear in the SOHS decomposition
%    over S
% SDP_data ... is a structure holding all the data used in SDP solver
% Z ... dual solution, that represent sohs
% Zg.... dual solution that contains wights
% H ... Hankel matrix
% Hg ... shifted Hankel matrices for g in S
% decom_err ... how much the decomposition differs from f
% possible usage: NCeigMinRand(f,H0,S,d), NCeigMinRand(f,H0,S,d,params)
%
% see also: NCoptBall, NCminCube, NCsos, NCmin, NCopt, NCdiff, NCcycSos,
% NCcycMin, NCsetPrecision, NCsetSolver, NCisConvex, NCisConvex0,
% NCisCycConvex, RProjRldlt
%
%% Call: [opt,decom_sohs,decom_S,base,SDP_data,Z,Zg,H,Hg,decom_err] = NCeigMinRand(f,H0,S,d,params)

% created: 28. 2. 2013 by J. Povh
% last modified: 22. 7. 2014 by JP
% last modified: 28. 11. 2014 by KC (cell2NCpolys)
% last modified: 28. 7. 2015 by KC (cleaning)
% last : 14.3.2018 KC, nargchk -> narginchk

%error(nargchk(1,5,nargin));
narginchk(1,5);

poly=NCpoly(f);

base=[];
SDP_data=[];
Z=[];
Zg=[];
H=[];
Hg=[];
%ne rabis
%Z_dual=[];
decom_sohs=[];
decom_S=[];
opt = [];
decom_err=0;

pars_sdp='';
justSDP_data=0;
decomposition=1;
%se ne uporabi?!
%module_up=0;
error_warn=0;

%d=ceil(d/2);
if nargin <= 4  
    NCparam;
    precision = NC_numeric_precision;
    messages=true;
elseif nargin == 5
   
    if isfield(params,'messages') && ~isempty(params.messages)
        if params.messages~=true && params.messages~=false
            error('ERROR: .messages must be logical true/false.');
        end
        messages=params.messages;
    else
        messages=true;
    end

    if isfield(params,'precision') && ~isempty(params.precision)
        if ~isnumeric(params.precision)
            error('ERROR: .precision must be a numerical value.');
        end
        precision = params.precision;
    else
        NCparam;
        precision = NC_numeric_precision;
    end
    
    if isfield(params,'solver') && ~isempty(params.solver)
        pars_sdp.solver = params.solver;
    end

    if isfield(params,'obj') && ~isempty(params.obj)
        SDP_obj=0;
    end

    
    
    if isfield(params,'eps') && ~isempty(params.eps)
        if ~isnumeric(params.eps)
            error('ERROR: .eps must be a numerical value.');
        end
        pars_sdp.eps = params.eps;
    end

    if isfield(params,'justSDP_data') && ~isempty(params.justSDP_data)
        if (params.justSDP_data==1 || params.justSDP_data==true)
            justSDP_data=1;
        end
    end

    if isfield(params,'decomposition') && ~isempty(params.decomposition)
        if (params.decomposition==0 || params.decomposition==false)
            decomposition=0;
        end
    end

    % se ne uporabi?!
    %if isfield(params,'module_up') && (params.module_up==1 || params.module_up==0)
    %    module_up=params.module_up;
    %end
    
end



%TODO! ni ok ... degree, params?!
if nargin == 1 % we do eigevalue optimization over all possible matrices
    %[opt,Z_dual,base,decomp_sohs,g,SDP_data,H] = NCmin(f,params);
    %Z_dual? spremenil v Z
    [opt,Z,base,decomp_sohs,g,SDP_data,H] = NCmin(f);
    %dodal return
    return;
%prestavil nizje za na=2
%elseif nargin == 2  % default call - we take d=degree(f)/2
%    d = ceil(degree(f)/2);
end

if messages
    %fprintf('\n***** NCSOStools: module NCeigOpt started *****\n\n');
    fprintf('\n***** NCSOStools: module NCeigMinRand started *****\n\n');
end


structpoly=struct(poly);
monom=structpoly.monom;
if length(monom) == 1 && isempty(monom{1})
    fprintf('Polynomial is a constant so there is nothing to do.\n');
    fprintf('***** Program is quiting. *****\n');
    return;
end

if (poly~=poly')
    fprintf('Polynomial is not symmetric: there is no SOHS decomposition over this module.\n');
    fprintf('***** Program is quiting. *****\n');
    return;
end


var=NCvarsactive();
deg = compute_deg(poly);
deg_S=zeros(1,size(deg,2));
for i=1:length(S)
    deg_S=deg_S+sum(compute_deg(S{i}),1);
end
vars_active_ind=find(sum(deg,1)+deg_S);
var_active=var(1,vars_active_ind);
deg_active=deg(:,vars_active_ind);
d_f=max(sum(deg_active,2));

%prestavil sem
if nargin == 2  % default call - we take d=degree(f)/2
    %d = ceil(degree(f)/2);
    d = ceil(d_f/2);
else
    d=ceil(d/2);
end



[V,V_deg] = generateFullV(d,var_active);
base = V;
%

%prestavil gor
%d_f=max(sum(deg_active,2));
m=length(S); %number of polynomials in S
n_S=[];
d_S=[];
n_H=size(V,1);  % size of matrix H

for i=1:m
    d_S(i) = max(sum(compute_deg(S{i}),2)); %size of H
    n_S(i)=sum(V_deg<=floor(d-d_S(i)/2));   % size of H_{g_i}
end

%glej vrstico cca 330, kjer se enkrat, ztao tukaj zakomentiral
%G=find_gram(f,V,'sos');


% construct SDP
% 

b=[];
A=cell(m+1,1);

A{1,1}=sparse(n_H^2,1); % 
for i=1:m
    A{i+1,1}=sparse(n_S(i)^2,1);
end


% constraint H(1)=1
count =1;
A{1,count} = [1;zeros(n_H^2-1,1)];
for i=1:m
    A{i+1,count} = zeros(n_S(i)^2,1);
end
b(count)=1;


ekv_mon = eqProd(V);
ekv_mon_temp = ekv_mon;
% constraints on H
while ~isempty(ekv_mon_temp)
    mon_temp=ekv_mon_temp{1,1}{1,1};
    ind = vertcat(ekv_mon_temp{1,1}{:,2});
    ekv_mon_temp(1,:)=[];
    j=1; terminate = 0;
    while j <= size(ekv_mon_temp,1) && ~terminate
        if strcmp(mon_temp,monom_ast(ekv_mon_temp{j,1}{1,1}))
            ekv_mon_temp(j,:)=[]; 
            terminate = 1;
        end
        j=j+1;
    end
    for j=2:size(ind,1);
        M = sparse([ind(1,1);ind(j,1)],[ind(1,2);ind(j,2)],[-1;1],n_H,n_H); 
        M=M+M';
        if norm(M,'fro')
            count = count +1;
            b(count)=0;
            A{1}(:,count) = M(:);
            for i=1:m
                A{i+1}(:,count)=sparse(n_S(i)^2,1);
            end
        end
    end
end

for i=1:m  % constraints H_gi(u,v)=\sum_w gi_w L(u^* w v)
    structpoly=struct(NCpoly(S{i}));
    monom=structpoly.monom;
    koef=structpoly.koef;
    for j=1:n_S(i)
        u=ekv_mon{j}{1,1};
        for k=j:n_S(i)
            v=ekv_mon{k}{1,1};
            M1=sparse([k j],[j k],[1 1],n_S(i),n_S(i)); 
            M2=sparse(n_H,n_H);
            for el = 1:length(monom)
                word = concate(concate(monom_ast(u),monom{el}),v);
                found=0;
                p=1;
                while p<=length(ekv_mon) && ~found
                    if strcmp(word,ekv_mon{p,1}{1,1})
                        p_index=ekv_mon{p,1}{1,2};
                        M2=M2-koef(el)*sparse([p_index(1) p_index(2)],[p_index(2) p_index(1)],[1 1],n_H,n_H);
                        found=1;
                    else
                        p=p+1;
                    end
                end
            end
            count = count +1;
            A{1}(:,count) = M2(:);
            b(count)=0;
            for q=1:m
                if q==i
                    A{q+1}(:,count)=M1(:);
                else
                    A{q+1}(:,count)=zeros(n_S(q)^2,1);
                end
            end
        end
    end
end
  
flag=count;  % up to flag we have constraint from original SDP
% contraint H_{<=d-1}=H0  %constraints that forses flatness
for i=1:size(H0,1)
    for j=i:size(H0,2)
        count = count +1;
        M1=sparse([i j],[j i],[1 1],n_H,n_H); 
        b(count)=2*H0(i,j);
        A{1}(:,count)=M1(:);
        for q=1:m
            A{q+1}(:,count)=zeros(n_S(q)^2,1);
        end
    end
end


% Random R
R0 = randn(n_H,n_H); 
R=R0'*R0;
Vp=cell2NCpolys(V);
%VV in VV_deg ne rabis ...
[G1,VV,VV_deg]=find_gram(Vp'*R*Vp,V);
% si ze naredil zgoraj ta G! zgoraj zakomentiral ...
G=find_gram(f,V,'sos');
if messages
    pars_sdp.messages=1;
else
    pars_sdp.messages=0;
end

K.s=[n_H n_S];


SDP_data.C=G1(:);
SDP_data.A=A{1};
for i=1:m
    SDP_data.C=[SDP_data.C;zeros(n_S(i)^2,1)];
    SDP_data.A=[SDP_data.A;A{i+1}];  
end
SDP_data.b=b';
SDP_data.K=K;
SDP_data.pars=pars_sdp;

if justSDP_data
    if messages
        fprintf('\n***** Program is quiting because of the .justSDP_data == 1 switch! *****\n');
        fprintf('***** Just the data for the SDP was returned.                      *****\n');
    end
    return;
end


[XX,Y,INFO]=solveSDP(SDP_data.A,SDP_data.b,SDP_data.C,SDP_data.K,SDP_data.pars);
SDP_data.INFO=INFO;

if messages
    disp([' ']);
    disp(['Residual norm: ' num2str(norm(SDP_data.A'*XX-SDP_data.b))]);
    disp([' ']);
    disp(INFO);
end

 if INFO.pinf==1 
     if messages
         fprintf('\n***** Dual solution has no flat extension: SDP is INFEASIBLE. *****\n');
     end
     return;
 end

if INFO.numerr<0
    fprintf('***** ALERT: SDPT3 ran into numerical problems.        *****\n');
%     fprintf('***** Press any key to continue with the last data ... *****\n');
%     if messages
        fprintf('***** Polynomial MIGHT have NO SOHS decomposition over this module.     *****\n');
%     end
    error_warn=1;
%     pause;
  elseif INFO.numerr==1
    if abs(INFO.feasratio-1)>1e-1
        fprintf('***** ALERT: SeDuMi ran into minor numerical problems.                    *****\n');
%         fprintf('***** Press any key to continue with the last data ...                    *****\n');
%         if messages
% % KC: to sedaj v ncminball zakomentiral
% %             if INFO.feasratio < 0.2
% %                 fprintf('***** According to feasratio polynomial MIGHT have NO SOHS decomposition. *****\n');
% %             elseif INFO.feasratio > 0.8
% %                 fprintf('***** Nevertheless, according to feasratio given solution MIGHT be ok.    *****\n');
% %             else
% %                 fprintf('***** Given solution might be wrong.                                      *****\n');
% %             end
%         end
        error_warn=1;
%         pause;
    end
elseif INFO.numerr==2
    fprintf('***** ALERT: SeDuMi ran into SERIOUS numerical problems. *****\n');
%     if messages
    if abs(INFO.feasratio-1)>1e-1
        fprintf('***** Press any key to continue with the last data ...   *****\n');
        fprintf('***** Given solution is therefore presumably wrong.      *****\n');
        pause;
    else
        fprintf('***** Given solution might be wrong.                     *****\n');
        error_warn=1;
    end
%     end
end
    
opt = SDP_data.C'*XX;

if nargout>1
    %dal noter
    %se povozi, zato zakomentiral
    %H=sparse(n_H,n_H);
    %spremenil v vrstico
    %Hg=cell(m,1);
    Hg=cell(1,m);

    H=reshape(XX(1:n_H^2),n_H,n_H);
    for i=1:m
        Hg{i}=reshape(XX(n_H^2+1+norm(n_S(1:i-1))^2:n_H^2+norm(n_S(1:i))^2),n_S(i),n_S(i));
    end
    C_orig=SDP_data.C;  % to get back the SOHS decomposition 
                        % we should take SDP where objective is not random
    C_orig(1:n_H^2)=G(:);
    ZZ=C_orig-SDP_data.A(:,1:flag)*Y(1:flag);
    Z=reshape(ZZ(1:n_H^2),n_H,n_H);
    %dodal
    Zg=cell(1,m);
    for i=1:m
        Zg{i}=reshape(ZZ(n_H^2+1+norm(n_S(1:i-1))^2:n_H^2+norm(n_S(1:i))^2),n_S(i),n_S(i));
    end    
    %     var_active_ncp=cell2NCpolys(var_active);
    %     g=1-var_active_ncp.'*var_active_ncp;
    if decomposition
        %se ne uporabi, ker spodaj povozis
        %decom_sum=0;
        W=cell2NCpolys(base);
        Gw=round(cholPSD(Z)/precision)*precision;
        decom_sohs=Gw*W;    
        decom_sum=decom_sohs'*decom_sohs;
        %dodal
        decom_S=cell(1,m);
        for i=1:m
            Wi=W(1:n_S(i));
            Gwi=round(cholPSD(Zg{i})/precision)*precision;
            decom_S{i}=Gwi*Wi;
            decom_sum=decom_sum+decom_S{i}'*S{i}*decom_S{i};
        end
    end
    
    %premaknil od spodaj noter v if>1
    dif=f-C_orig'*XX-decom_sum;
    decom_err=norm(struct(dif).koef);
    %bi kaj izpisal pri kakih decom_err? kot pri nceigmin

end % if nargout>1


if error_warn
    fprintf('\nWARNING! SDP solver returned some numerical problems. Check messages!\n');
end


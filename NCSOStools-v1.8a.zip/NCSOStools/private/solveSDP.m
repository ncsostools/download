function [XX,Y,INFO]=solveSDP(AA,bb,c,K,pars_sdp)
% last modified: 28. 11. 2014 test

if nargin==4
    pars_sdp='';
    NCparam;
    solver=lower(NC_active_solver);
else
    if isfield(pars_sdp,'solver')
        solver=lower(pars_sdp.solver);
    else
        NCparam;
        solver=lower(NC_active_solver);
    end
end

% Janez test
ind=K.s==0;
K.s(ind)=[];

% optimiziraj potem naprej
izpisitekst=true;
if isfield(pars_sdp,'messages')
    if ~pars_sdp.messages
        izpisitekst=false;
    end
end

if izpisitekst
    fprintf('Number of linear constraints: %d.\n',length(bb));
    fprintf('\nStarting SDP solver ...\n\n');
end

switch solver
    case 'sedumi'
        if isfield(pars_sdp,'eps')
            pars.eps=pars_sdp.eps;
        else
            %pars.eps = 0;
             pars.eps = 1e-9;
        end
        
        if isfield(pars_sdp,'messages')
            pars.fid=pars_sdp.messages;
        end
        
        [XX,Y,INFO] = sedumi(AA,bb,c,K,pars);
        if isfield(INFO,'iter')
            INFO=rmfield(INFO,{'iter'});
        end
        if isfield(INFO,'timing')
            INFO=rmfield(INFO,{'timing'});
        end
        if isfield(INFO,'cpusec')
            INFO=rmfield(INFO,{'cpusec'});
        end

    case 'sdpa'
        % pars is actually not used ... OPTIONS is really used
        OPTION = param;
        if isfield(pars_sdp,'eps')
            pars.eps=pars_sdp.eps;
        else
            %pars.eps = 0;
            pars.eps = 1e-9;
        end

        if isfield(pars_sdp,'messages')
            pars.fid=pars_sdp.messages;
            if pars_sdp.messages==0
                OPTION.print='no';
            end
        end
        
        OPTION.gammaStar=0.83;
        [XX,Y,INFOsdpa] = sedumiwrap(AA,bb,c,K,pars,OPTION);
   		INFO.SDPAphasevalue=INFOsdpa.phasevalue;
        INFO.dualError=INFOsdpa.dualError;
        INFO.primalError=INFOsdpa.primalError;
        INFO.numerr=0;
        
        switch INFOsdpa.phasevalue
        	case 'pdOPT'
        		INFO.pinf=0;
        		INFO.dinf=0;
        	case 'noINFO'
        		INFO.pinf=-1;
        		INFO.dinf=-1;
                INFO.numerr=3;
        	case 'pFEAS'
        		INFO.pinf=0;
        		INFO.dinf=-1;
        	case 'dFEAS'
        		INFO.pinf=-1;
        		INFO.dinf=0;
        	case 'pdFEAS'
        		INFO.pinf=0;
        		INFO.dinf=0;
        	case 'pdINF'
        		INFO.pinf=1;
        		INFO.dinf=1;
        	case 'pFEAS_dINF'
        		INFO.pinf=0;
        		INFO.dinf=1;
        	case 'pINF_dFEAS'
        		INFO.pinf=1;
        		INFO.dinf=0;
        	case 'pUNBD'
        		INFO.pinf=0;
        		INFO.dinf=1;
        	case 'dUNBD'
        		INFO.pinf=1;
        		INFO.dinf=0;
        end

    case 'sdpt3' % version 4
        [blk,AA2,c2,bb2] = read_sedumi(AA,bb,c,K);

        add_options=false;
        if isfield(pars_sdp,'messages')
            if pars_sdp.messages==0
                OPTIONS.printlevel=0;
                add_options=true;
            end
        end
        
        if add_options
            [obj,X,Y,Z,infoSDPT] = sdpt3(blk,AA2,c2,bb2,OPTIONS);
        else
            [obj,X,Y,Z,infoSDPT] = sdpt3(blk,AA2,c2,bb2);
        end
        
        XX = zeros(length(c),1);
        indeks = 1;
        
        if isfield(K,'f')
            free_nmb=K.f;
        else
            free_nmb=0;
        end
        
        if free_nmb ~= 0
            XX(1:free_nmb) = X{1}(:);
            indeks = 2;
        end

        if K.s ~= 0
            start=free_nmb+1;
            Ks=K.s;
            % pred 8.3.2014
            % for i=1:length(Ks)
            %     tmp=X{indeks}(sum(Ks(1:i-1))+1:sum(Ks(1:i)),sum(Ks(1:i-1))+1:sum(Ks(1:i)));
            %     XX(start:start+Ks(i)^2-1) = tmp(:);
            %     start=start+Ks(i)^2;
            % end
            % po 8.3.2014 - je to ok?
            blk_size=size(blk,1);
            for i=1:blk_size
              if blk{i,1}=='s'
                for j=1:length(blk{i,2})
                  tmp=X{i}(sum(blk{i,2}(1:j-1))+1:sum(blk{i,2}(1:j)),sum(blk{i,2}(1:j-1))+1:sum(blk{i,2}(1:j)));
                  XX(start:start+blk{i,2}(j)^2-1) = tmp(:);
                  start=start+blk{i,2}(j)^2;
                end
              end
            end
        end

        % INFO.iter = infoSDPT.iter;
        % INFO.cpusec = infoSDPT.cputime;
        INFO.pinfeas=infoSDPT.pinfeas;
        INFO.dinfeas=infoSDPT.dinfeas;
        if infoSDPT.termcode == 1
            INFO.pinf = 1;
        else
            INFO.pinf = 0;
        end
        if infoSDPT.termcode == 2
            INFO.dinf = 1;
        else
            INFO.dinf = 0;
        end
        if infoSDPT.termcode == 3
            INFO.pinf = 1;
            INFO.dinf = 1;
        end
        if infoSDPT.termcode<= 0
            INFO.numerr = infoSDPT.termcode;
        else
            INFO.numerr = 0;
        end
       
    case 'sdpt3-v3' % version 3
        At=AA';
        b=bb;
        save NCsostools_sedumi-SDPT3 At b c K;
        [blk,AA2,c2,bb2] = read_sedumi('NCsostools_sedumi-SDPT3.mat');
        delete NCsostools_sedumi-SDPT3.mat;

        add_options=false;
        if isfield(pars_sdp,'messages')
            if pars_sdp.messages==0
                OPTIONS.printlevel=0;
                add_options=true;
            end
        end
        
        if add_options
            [obj,X,Y,Z,infoSDPT] = sqlp(blk,AA2,c2,bb2,OPTIONS);
        else
            [obj,X,Y,Z,infoSDPT] = sqlp(blk,AA2,c2,bb2);
        end
        
        XX = zeros(length(c),1);
        indeks = 1;
        
        if isfield(K,'f')
            free_nmb=K.f;
        else
            free_nmb=0;
        end
        
        if free_nmb ~= 0
            XX(1:free_nmb) = X{1}(:);
            indeks = 2;
        end

        if K.s ~= 0
            start=free_nmb+1;
            Ks=K.s;
            for i=1:length(Ks)
                tmp=X{indeks}(sum(Ks(1:i-1))+1:sum(Ks(1:i)),sum(Ks(1:i-1))+1:sum(Ks(1:i)));
                XX(start:start+Ks(i)^2-1) = tmp(:);
                start=start+Ks(i)^2;
            end
        end

        % INFO.iter = infoSDPT(2);
        % INFO.cpusec = infoSDPT(6);
        INFO.pinfeas=infoSDPT(4);
        INFO.dinfeas=infoSDPT(5);
        if infoSDPT(1) == 1
            INFO.pinf = 1;
        else
            INFO.pinf = 0;
        end
        if infoSDPT(1) == 2
            INFO.dinf = 1;
        else
            INFO.dinf = 0;
        end
        if infoSDPT(1) == 3
            INFO.pinf = 1;
            INFO.dinf = 1;
        end
        if infoSDPT(1)<= 0
            INFO.numerr = infoSDPT(1);
        else
            INFO.numerr = 0;
        end
    
    otherwise
        error('ERROR: unsupported SDP solver!');
end

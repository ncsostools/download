function [G,V,V_deg]=find_gram(f,V,option)
% constructs a Gram matrix G such that:
% f=V^*G V, if option = 'sos'
% f \csim V^* G V if option = 'cycsos'
% default call: [G,V,V_deg]=find_gram(f) find G regarding the smallest V
% OUTPUT:
% G...gram matrix
% V...vector of monomials in the base
% V_deg...vector of degrees of V
% last modified: 28. 11. 2014 KC
% last : 14.3.2018 KC, nargchk -> narginchk

%error(nargchk(1,3,nargin));
narginchk(1,3);

G=[];
poly=NCpoly(f);
structpoly=struct(poly);
koef=structpoly.koef;
monom=structpoly.monom;
deg = compute_deg(poly);
len_m=length(monom);


var=NCvarsactive();

d_max=max(sum(deg'));


if nargin <= 2  % default call
    option = 'sos';
end

if nargin == 1  || isempty(V) % default call
    [V,V_deg] = generateFullV(ceil(d_max/2),var); 
    V_poly=cell2NCpolys(V);
else
    V_poly=cell2NCpolys(V);

    V_deg=zeros(size(V));

    for i=1:length(V_poly)
        deg_V=compute_deg(V_poly(i));
        V_deg(i)= max(sum(deg_V'));  
    end
end

d_V=max(V_deg);

if 2*d_V < d_max
   fprintf('\n There is no Gram matrix: max degree od poly: %d, max degree of V: %d.\n',d_max,d_V);
   return;
end

n=size(V,1);
G=sparse(n,n);

base = V;
len_base=length(base);
base_ast=cell(size(base));
for i=1:len_base
    base_ast{i}=monom_ast(base{i});
end

const_cnt=0;
A=sparse(len_base^2,1);
b=[];


if strcmp(option,'sos')
    for i=1:len_m    % finds possible decompositions
        MM=sparse(len_base,len_base);
        temp_mon = monom{i,1};
        % KC: tega ne rabis!
        % temp_mon_rev = char(monom_ast(temp_mon));
        len_mon = length(temp_mon);
        for j = 1:len_base
            factor=base_ast{j,1};
            len_fact = length(factor);
            if (len_fact == 0)||(len_fact <=len_mon && strcmp(factor,temp_mon(1:len_fact)))
                for k=1:len_base   % searching for the right part of temp_mon
                    factor_rev=base{k,1};
                    product = concate(factor,factor_rev);
                    if strcmp(temp_mon,product)
                        MM(j,k)=1;
                    end  % if
                end % for
            end % if
        end   % for
        if sum(sum(MM))==0  % there must be always a decomposition
            fprintf('\nError: something wrong with base vector.\n');
            return;
        end
        const_cnt=const_cnt+1;
        G=G+MM*koef(i)/sum(sum(MM));    
    end   % for
    if(NCclean(f-V_poly'*G*V_poly,1e-10)~=0);
        fprintf('\nError: wrong Gram matrix\n');
    end
elseif strcmp(option,'cycsos')
    [f,ekv_mon_f]=NCcycEqRep(f);
    ekv_mon_v = cycEqProd(V);
    ekv_mon_f_temp=ekv_mon_f;
    m=size(ekv_mon_v,1);
    for i=1:m
        sz=size(ekv_mon_f_temp,1);
        if sz      
            for j=1:sz;
                if isCycEqMonom(ekv_mon_v{i,1}{1,1},ekv_mon_f_temp{j,1}{1,1}) % there is j-th monomial in f, cycl. eq. to ekv_mon_v{i,1}
                    ind = vertcat(ekv_mon_v{i,1}{:,2});
                    M=sparse(ind(:,1),ind(:,2),ones(size(ind,1),1),n,n);  
                    G=G+M*ekv_mon_f_temp{j,2}/sum(sum(M));
                end
            end
        end
    end
    if ~NCisCycEq(f-V_poly'*G*V_poly,0,1e-10);
        fprintf('\nError: wrong Gram matrix\n');
    end
end

function isCycEqMonom=isCycEqMonom(monom1,monom2)

% description: isCycEqMonom=isCycEqMonom(monom1,monom2) checks whether
% monomials monom1 and monom2 are cyclically equivalent
% 
% arguments: monom1 and monom2 are strings representing monomials
% 
% output: isCycEqMonom equals 1 if monomials monom1 and monom2 are
% cyclically equivalent and 0 otherwise
% 
% possible usage: isCycEqMonom(monom1,monom2)

% created: 2. 2. 2009 KC
% last modified: 2. 2. 2009 KC
% last modified: 25. 5. 2010 KC
% last modified: 6. 6. 2010 KC

size1=length(strfind(monom1,'*'));
if size1==length(strfind(monom2,'*'))
    isCycEqMonom=any(strfind(['*' monom1 '*' monom1 '*'],['*' monom2 '*']));
else
    isCycEqMonom=0;
end

function [deg,var] = compute_NSdeg(poly,type)

% computes degrees of monomials in poly
% returnes matrix deg such that
%   deg_i,j = degree of i-th variable in j-th monomial of poly
% type=2 count x and X as one
%% Call: [deg,var] = compute_NSdeg(poly)

% last modified: 11. 12. 2014 KC
% last: 14.3.2018, KC, nargchk -> narginchk

%error(nargchk(1,2,nargin));
narginchk(1,2);

if nargin==1
    type=1;
end

poly=NSpoly(poly);

structpoly=struct(poly);
monom=structpoly.monom;

var=NSvarsactive();

if type==2
    var=unique(lower(var));
    monom=lower(monom);
end

num_var = length(var);  % number of variables

len_m=length(monom);
deg=zeros(len_m,num_var);

var_zv=cell(1,num_var);
for j=1:num_var  
    var_zv{j}=['*',var{j},'*'];
end

for i=1:len_m
    str = ['*',monom{i,1},'*'];
    for j=1:num_var  
        deg(i,j)=length(strfind(str,var_zv{j}));
    end
end

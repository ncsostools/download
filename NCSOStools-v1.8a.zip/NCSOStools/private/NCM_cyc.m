function [V,ekv_mon_f,flag,f]=NCM_cyc(f,messages,chip_method)
% executes the Newton chip method for cyclic equivalence
% if chip_method == -1 then we create V by the socalled newton cyclic chip method:
% we take all cyclic permutations of monomials of even degree and for each
% of those equivalents which are Herm. squares we take all right chips.
% this is valid only if support of f is the same as support of SOHS, which is cyc.
% eq. to f.


V = [];
ekv_mon_f = [];
f = NCpoly(f);
[f,ekv_mon_f] = NCcycEqRep(f);

var = NCvarsactive();
flag = false;
deg = compute_deg(f);

% dodano posebej za stevila - Janez preveri ce je to pravi pogoj!
if all(deg==0)
    if f ~= 0
        V={''};
    else
        V = {};
    end
    return;
end

max_tot_len = 0;
for i = 1:size(ekv_mon_f)
    max_tot_len = max(max_tot_len,length(ekv_mon_f{i,1}));
end

len_mon=sum(deg,2);  % contains lengths of monomials
deg_max=max(len_mon);   % max degree of polynomial
deg_min=min(len_mon);  % min degree of polynomial
deg_var_min = min(deg,[],1);  % for every variable we compute its minimal degree in poly
deg_var_max = max(deg,[],1);  % for every variable we compute its maximal degree in poly
if ~all(mod(deg_var_min,2)==0) ||~all(mod(deg_var_max,2)==0) || ~all(mod(deg_max,2)==0) || ~all(mod(deg_min,2)==0)
    if messages
        fprintf('\n***** Polynomial is NOT CYCLICALLY EQUIVALENT to SOHS - min or max degree is odd *****\n');
    end
    flag=1;
    return;
end

zero = find(deg_var_max==0); % if some variables do not appear
deg_var_min(zero)=[];
deg_var_max(zero)=[];
num_var=length(deg_var_max);
deg(:,zero)=[];




count = 0;
V=cell(1,1);
V_deg = [];

if chip_method==-1
  
    for i = 1:size(ekv_mon_f,1)
        eqmonoms = cycEqMonoms(ekv_mon_f{i,1}{1,1});
        mon_poly = factor2NCpoly([1],{eqmonoms{1,1}});
        deg = compute_deg(mon_poly);
        mon_len = sum(deg,2);
        if ~mod(mon_len,2)  % zthe class must be of even lengths, is the string length must be odd
            for j=1:length(eqmonoms)
                monom = eqmonoms{j,1};
                if mod(length(monom),2) && min(monom_ast(monom)==monom)  % monom is symmetric
                    count = count+1;
                    V{count,1}=monom;
                    V_deg=[V_deg;deg];
                end
            end
        end
    end

    fin_count = 0;
    V_chip = cell(1,1);
    for i = 1:count
        monom_curr = V{i,1};
        asterix = strfind(monom_curr,'*');
        V_len = sum(V_deg(i,:),2);
        for j= deg_min/2:V_len/2
            if j==0
                chip='';
                chip_len=0;
            elseif j> length(asterix)
                fprintf('ERROR: something wrong on the input.\n\n');
                flag = 1;
                return;
            else
                chip = monom_curr(1:asterix(j)-1);  %left chip of monomial of length j
                chip_len=j;
            end
            is_candidate=1;
            chip_poly = factor2NCpoly([1],{chip});
            chip_deg = compute_deg(chip_poly);
            chip_deg(zero)=[];

            if ~isempty(chip_deg) && min(chip_deg >= deg_var_min/2) && min(chip_deg <= deg_var_max/2)
                fin_count = fin_count+1;
                V_chip{fin_count,1}=monom_ast(chip);
            end
        end
    end
    %%% eliminate multipliers from V_chip
    if size(V_chip,1)== 1
        V = V_chip;
        return;
    end
    [V_chip_s,ix] = sort(V_chip);
    V_chip_f=cell(1,1);
    new_count = 0;
    i = 1;
    while i <= fin_count
        j=i+1;
        while j <= fin_count && strcmp(V_chip_s{i,1},V_chip_s{j,1})
            j = j+1;
        end
        new_count = new_count+1;
        V_chip_f{new_count,1} = V_chip_s{i,1};
        i = j;
    end 
    V = V_chip_f;
else  % we implement alpha degree constraint
    [V,V_deg,ekv_mon_f,error]=construct_V(f,messages);
    [res] = alpha_deg(V_deg,deg);
    keep = find(sum(res(:,3:4)') == 2);
    V=V(keep);
end

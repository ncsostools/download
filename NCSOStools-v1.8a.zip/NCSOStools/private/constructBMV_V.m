function V=constructBMV_V(P,type,before,after)

if nargin==1
    type=1;
    before='';
    after='';
elseif nargin==2
    before='';
    after='';
elseif nargin==3
    after='';
end

if type==2
    var={'x*x','y*y'};
else
    var={'x','y'};
end

V=cell(1,1);

len=sum(P);

position=1:len;
wherey=nchoosek(position,P(2));
meja=size(wherey,1);
start=ones(1,len);
for i=1:meja
    which=start;
    which(wherey(i,:))=2;
    monom = var{which(1)};
    for t=2:length(which)
        monom = [monom,'*',var{which(t)}];
    end
    isbefore = ~isempty(before);
    isafter = ~isempty(after);
    if isbefore && isafter
        monom = [before, '*', monom, '*' after];
    elseif isbefore
        monom = [before, '*', monom];
    elseif isafter
        monom = [monom, '*' after];
    end
    V{i,1}=monom;    
end

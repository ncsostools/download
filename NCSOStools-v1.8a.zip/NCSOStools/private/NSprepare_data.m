function [A,b,C,base,deg,info] = NSprepare_data(poly,var,diff,messages,base)

% prepares SDP data corresponding to finding SOHS factorization
% poly is a polynomial in variables, defined in cell var
% if var is not defined, we assume two variables: 'x' and 'y'
% diff==1, then it prepares data even if poly is obviously not SOHS
% (default value for diff = 0)
% messages: 0,1,2 ... 0 = no, 1 = yes, 2 = just data about poly
%
% A, b, c, K is input for SEDUMI
% info: information why we quit by return
% info==0: there is no sohs
% info==-1: there must be error in the input data
% info==1: program quited regulary
% info==2: program quited earlier, but there is sohs
%% Call: [A,b,C,base,deg,info] = NSprepare_data(poly,var,diff,messages,base);

% last modified: 11. 12. 2014 KC
% 15. 12. veszprem
% last: 14.3.2018, KC, complex
% last: 14.3.2018, KC, nargchk -> narginchk

%error(nargchk(1,5,nargin));
narginchk(1,5);

info = 1;

% default output if we quit by ''return'' 
A = []; b = []; C = []; K = []; X = []; deg = [];

poly = NSpoly(poly);

lasten_base = false;
if nargin==1  %default call
    var = NSvarsactive();
    diff = 0;
    messages = 1;
    base = [];
elseif nargin==2  %default call
    diff = 0;
    messages = 1;
    base = [];
elseif nargin==3  %default call
    messages = 1;
    base = [];
elseif nargin==4
    base = [];
elseif nargin==5 && ~isempty(base)
    lasten_base = true;
    base_ast = cell(size(base));
    for i = 1:length(base)
        base_ast{i} = monom_NSast(base{i});
    end
end

%tmp 
%diff = 1;

if diff~=0 && diff~=1
    error('ERROR: third argument must be logical true/false.');
end

if messages~=0 && messages~=1 && messages~=2
    error('ERROR: fourth argument must be 0, 1 or 2.');
end

structpoly = struct(poly);
koef = structpoly.koef;
monom = structpoly.monom;

% for complex:
IS_complex = ~isreal(koef);

len_m = length(monom);
deg = compute_NSdeg(poly);

deg2 = compute_NSdeg(poly,2);
var2 = unique(lower(var));
num_var2 = length(var2);  % number of variables where x and X count as one

num_var = length(var);  % number of variables

max_tot_len = 0;
if isempty(base)
    for i = 1:length(monom)
        max_tot_len = max(max_tot_len,length(monom{i,1}));
    end
else
    for i = 1:length(base)
        max_tot_len = max(max_tot_len,2*length(base{i,1})+1);
    end
end

%veszprem
%len_mon = sum(deg,2);  % contains lengths of monomials
len_mon = sum(deg2,2);  % contains lengths of monomials
deg_max = max(len_mon);   % max degree of polynomial
deg_min = min(len_mon);  % min degree of polynomial
deg_var_min = min(deg,[],1);  % for every variable we compute its minimal degree in poly
deg_var_max = max(deg,[],1);  % for every variable we compute its maximal degree in poly

deg_var2_min = min(deg2,[],1);  % for every nonsymmetric variable we compute its minimal degree in poly
deg_var2_max = max(deg2,[],1);  % for every nonsymmetric variable we compute its maximal degree in poly

if messages==1 || messages==2
    fprintf('Input polynomial has (max) degree %d and min degree %d.\n',deg_max,deg_min);

    tmp_num_var = sum(sum(deg,1)~=0);
    tmp_num_var2 = sum(sum(deg2,1)~=0);
    fprintf('Detected %d monomial',len_m);
    if len_m>1
        fprintf('s');
    end
    fprintf(' in %d nonsymmetric variable',tmp_num_var2);
    if tmp_num_var2>1 || tmp_num_var2==0
        fprintf('s');
    end
    fprintf('.\n');

    if tmp_num_var2==0
        tmp_num_all_mon = 1;
        tmp_num_minmax_mon = 1;
    %v nesim tega ne more biti, ker imas vedno sodo mnogo, ce pogledas kot
    %razlicne
    %elseif tmp_num_var==1
    %    tmp_num_all_mon = deg_max+1;
    %    tmp_num_minmax_mon = deg_max-deg_min+1;
    else
        tmp_num_all_mon = ((2*tmp_num_var2)^(deg_max+1)-1)/(2*tmp_num_var2-1);
        tmp_num_minmax_mon = ((2*tmp_num_var2)^(deg_max+1)-(2*tmp_num_var2)^deg_min)/(2*tmp_num_var2-1);
    end

    fprintf('There are %d monomial',tmp_num_all_mon);
    if tmp_num_all_mon>1
        fprintf('s');
    end
    fprintf(' in %d nonsymmetric variable',tmp_num_var2);
    if tmp_num_var2>1 || tmp_num_var2==0
        fprintf('s');
    end
    fprintf(' of degree at most %d.\n',deg_max);

    if deg_min>0
        fprintf('There are %d monomial',tmp_num_minmax_mon);
        if tmp_num_minmax_mon>1
            fprintf('s');
        end
        fprintf(' in %d nonsymmetric variable',tmp_num_var2);
        if tmp_num_var2>1 || tmp_num_var2==0
            fprintf('s');
        end
        if deg_max~=deg_min
            fprintf(' of degree at most %d and at least %d.\n',deg_max,deg_min);
        else
            fprintf(' of degree exactly %d.\n',deg_max);
        end
    end
end


if length(monom)==1 && isempty(monom{1}) && koef(1)>=0
    base = {''};
    A = 1;
    C = 1;
    b = koef(1);
    if messages==1
        fprintf('\nPolynomial is SOHS - it is a non-negative real number\n\n');
    end
    info = 2;
    return;
end

if length(monom)==1 && isempty(monom{1}) && koef(1)<0
    if messages==1
        fprintf('\nPolynomial is not SOHS - it is a negative real number\n\n');
    end
    info = 0;
    return;
end


if sum(len_mon)==0  && ~isempty(monom{1})
    if messages==1 || messages==2
        fprintf('\nError on the INPUT: wrong variable names entered\n\n');
    end
    info = -1;
    return;
end


if poly~=poly'
%if poly~=poly' && ~diff
    if messages==1
        fprintf('\nPolynomial is not SOHS - it is not SYMMETRIC\n\n');
    end
    info = 0;
    return;
end


% a je tu za diff ali ne?
if ~diff && (max(mod(deg_var2_min,2))>0 || max(mod(deg_var2_max,2))>0 || mod(deg_max,2)>0 || mod(deg_min,2)>0)
    if messages==1
        fprintf('\nPolynomial is not SOHS - each nonsymmetric variable must have EVEN min and max degree\n\n');
    end
    info = 0;
    return;
end

 
if mod(deg_max,2)>0 || mod(deg_min,2)>0
    if messages==1
        fprintf('\nPolynomial is not SOHS - min degree and max degree must be EVEN numbers\n\n');
    end
    info = 0;
    return;
end


sym_highest = 0;
sym_lowest = 0;
sym_highest_i = zeros(1,num_var2);
sym_lowest_i = zeros(1,num_var2);

for i = 1:len_m
    if (len_mon(i)==deg_max || len_mon(i)==deg_min || max(deg2(i,:)==deg_var2_max)>0 || max(deg2(i,:)==deg_var2_min)>0) && strcmp(monom{i},monom_NSast(monom{i}))
        if sym_highest==0 && len_mon(i)==deg_max
            sym_highest = 1;
        end
        if sym_lowest==0 && len_mon(i)==deg_min
            sym_lowest = 1;    
        end
        if min(sym_highest_i)==0 && max(deg2(i,:)==deg_var2_max)>0
            sym_highest_i = sym_highest_i+(deg2(i,:)==deg_var2_max);    
        end
        if min(sym_lowest_i)==0 && max(deg2(i,:)==deg_var2_min)>0
            sym_lowest_i = sym_lowest_i+(deg2(i,:)==deg_var2_min);    
        end
    end
end

% a je tu diff ali ne?
if ~diff && (min(sym_highest,sym_lowest)==0 || min (sym_highest_i)==0 || min (sym_lowest_i)==0)
    if messages==1
        fprintf('\nPolynomial is not SOHS:\nThere exist extremal degree (max or min) for which there is no symmetric monomial of this degree\n\n')
    end
    info = 0;
    return;
end




if ~lasten_base
    base_ast = cell(1,1);
    base = cell(1,1);
    len_base = 0;
    table_len = [];

    monom_sym = cell(1,1);
    sym_len = 0;

    % Newton chip method
    for i = 1:len_m
        monom_curr = monom{i,1};
        if strcmp(monom_curr,monom_NSast(monom_curr)) && mod(len_mon(i),2)==0;  % it is enough to consider symmetric monomials of even length
            sym_len = sym_len+1;
            monom_sym{sym_len} = monom_curr;
            l_bound = deg_min/2;
            u_bound = min(len_mon(i)/2,deg_max/2);
            asterix = strfind(monom_curr,'*');
            asterix = [asterix length(monom_curr)+1]; % we add last index to assure that also the last variable in monom_curr comes on order
            for j = l_bound:u_bound
                if j==0
                    chip = '';
                    chip_len = 0;
                elseif j>length(asterix)
                    fprintf('\nERROR: something wrong on the input.\n\n');
                    info = -1;
                    return;
                else
                    chip = monom_curr(1:asterix(j)-1);  %left chip of monomial of length j
                    chip_len = j;
                end
                is_candidate = 1;
                p = 1;
                %while p<=num_var &&  is_candidate
                %    deg_p = length(strfind(strcat('*',chip,'*'),strcat('*',var{p},'*')));%%%!!!!!!!!!!!!!!!!
                %    if (deg_p<deg_var_min(p)/2 || deg_p>deg_var_max(p)/2)
                %        is_candidate = 0;  % chip can not be a candidate for the base since deg of p-th var in chip i too small or too large
                %    end
                %    p = p+1;
                %end
                while p<=num_var2 &&  is_candidate
                    deg_p = length(strfind(strcat('*',chip,'*'),strcat('*',lower(var2{p}),'*'))) + length(strfind(strcat('*',chip,'*'),strcat('*',upper(var2{p}),'*')));%%%!!!!!!!!!!!!!!!!
                    if (deg_p<deg_var2_min(p)/2 || deg_p>deg_var2_max(p)/2)
                        is_candidate = 0;  % chip can not be a candidate for the base since deg of p-th var in chip is too small or too large
                    end
                    p = p+1;
                end
                
                k = 1;
                while k<=len_base && is_candidate    
                    is_candidate = ~strcmp(base_ast(k),chip);
                    k = k+1;
                end
                
                if is_candidate

                    % alpha_deg
                    %h = factor2NSpoly([1],{chip});
                    %du = compute_deg(h);
                    %[low,up,low1,up1] = alpha_deg(du,deg);
                    %if low+up<=1
                    %   keyboard; %the extended check for good monomials is stronger
                    %end

                    len_base = len_base+1;
                    base_ast{len_base,1} = chip;

                    % je chip res monom?
                    % base{len_base,1} = ast(chip);
                    base{len_base,1} = monom_NSast(chip);

                    table_len(len_base) = chip_len;  %length of the chip
                end
            end    
        end
    end
    
    
    %konec osnove ns ncm
    [base_ast_s,ix] = sort(base_ast);
    base_s = base(ix);
    table_len_s = table_len(ix)';

    jumps = [];  % where a new chain of monomials in base_ast_s starts


    if isempty(base_ast_s{1}) && length(base_ast_s)>1  % monomial '' is not important - can't produce  a square
        start = 2;
    else
        start = 1;
    end
    jumps(1) = start;
    last = start;
    last_len = length(base_ast_s{last});

    for i = start+1:len_base
        if ~strncmp(base_ast_s{last},base_ast_s{i},last_len)
            jumps = [jumps; i];
            last = i;
            last_len = length(base_ast_s{last});
        end
    end

    cand_sym = cell(1,1);
    cand_sym_fac = zeros(1,2);
    prod_sym_len = 0;

    if isempty(base_ast_s{1})  %we should consider also all symmetric members of base of even length since they can eliminate others sohs
        for i = 1:len_base
            if mod(table_len_s(i),2)==0 && strcmp(base_ast_s{i},base_s{i}) 
                prod_sym_len = prod_sym_len+1;
                cand_sym{prod_sym_len,1} = base_ast_s{i};
                cand_sym_fac(prod_sym_len,:) = [1 i]';
            end
        end
    end


    for i = 1:length(jumps)
        first = jumps(i);
        if i==length(jumps)
            last = len_base;
        else
            last = jumps(i+1)-1;  
        end
        for k = first:last
            for el = k:last
                if mod(table_len(k)+table_len(el),2)==0 % we are interested only for candidates of even length
                    m = min(table_len(k),table_len(el));
                    if strncmp(base_ast_s{k},base_ast_s{el},m)
                        prod = concate(base_ast_s{k},base_s{el});
                        if strcmp(prod,monom_NSast(prod)) % we include only symmetric candidates
                            prod_sym_len = prod_sym_len+1;
                            cand_sym{prod_sym_len,1} = prod;
                            cand_sym_fac(prod_sym_len,:) = [k el];
                        end
                    end
                end
            end
        end
    end



    cand_elim = [];
    [cand_sym_s,ix] = sort(cand_sym);
    cand_sym_fac_s = cand_sym_fac(ix,:);
    elim_ix = [];
    i = 1;

    while i<=prod_sym_len
        prod = cand_sym_s{i};
        k = 1;
        while k<=sym_len && ~strcmp(monom_sym{k},prod)
            k = k+1;
        end
        if k>sym_len  % prod does not appear in monom_sym, hence is candidate for elimination
            cand_elim = [cand_elim;i i];
            p = i+1;
            while p<=prod_sym_len && strcmp(prod,cand_sym_s{p})
                cand_elim = [cand_elim;p i];
                p = p+1;
            end
            i = p;  
        else
            i = i+1;
        end
    end
    
    % brisanje odve�nih
    elim_ix = [];
    j = 1;
    while j<=size(cand_elim,1)
        k = j+1;
        count = 1;
        stop = size(cand_elim,1);
        while k<=stop && cand_elim(k,2)==cand_elim(j,2)
            count = count +1;
            k = k+1;
        end  
        if count==1 % we will delete j 
            ix_del = cand_elim(j,1);  
            if cand_sym_fac_s(ix_del,1)~=cand_sym_fac_s(ix_del,2)
                fprintf('\nERROR: this should be a SOHS\n\n');
                j = j+1;
          %      keyboard;
            else
                fact_del = cand_sym_fac_s(ix_del,1);
                elim_ix = [elim_ix;fact_del];
                pos = union(find(cand_sym_fac_s(:,1)==fact_del),find(cand_sym_fac_s(:,2)==fact_del));
                for s = 1:length(pos)
                    where = find(cand_elim(:,1)==pos(s));
                    cand_elim(where,:) = [];            
                end
                if length(pos)==1 && length(where)==1  % we deleted only 1 from cand_elim, which was j-th entry of cand_elim.
                    % we should continue on j-th entry of new  cand_elim
                    j = k-1;
                else
                    j = 1;
                end
            end
        else
            j = k;
        end
    end


    base_ast_s(elim_ix) = [];
    base_s(elim_ix) = [];

    %27.2.2015
    %base_ast = base_ast_s;
    %base = base_s;
    [base,ix] = sort(base_s);
    base_ast = base_ast_s(ix);

end % end of ~lasten_base

len_base = length(base);

const_cnt = 0;
A = sparse(len_base^2,1);
b = [];
for i = 1:len_m    % finds possible decompositions
    MM = sparse(len_base,len_base);
    temp_mon = monom{i,1};

    %temp_mon_rev = char(ast(temp_mon));
    temp_mon_rev = char(monom_NSast(temp_mon));

    if str_rel(temp_mon,temp_mon_rev)>=0  %% temp_mon appears  before temp_mon^*  or is equal to temp_mon^*
        len_mon = length(temp_mon);
        for j = 1:len_base
            factor = base_ast{j,1};
            len_fact = length(factor);
            if (len_fact==0)||(len_fact<=len_mon && strcmp(factor,temp_mon(1:len_fact)))
                %temp_mon_rev = temp_mon(len_mon:-1:len_fact+1);
                for k = 1:len_base   % searching for the right part of temp_mon
                    factor_rev = base{k,1};
                    [product] = concate(factor,factor_rev);
                    if strcmp(temp_mon,product)
                        MM(j,k) = 1;
                    end  % if
                end % for
            end % if
        end   % for

	% for complex:
        % if data is complex we add only (non-symmetric) constraints for w > w*
        % solver than cares about cosntraints for w*
        %MM = (MM+MM')/2;
        if ~IS_complex              
          MM=(MM+MM')/2;
        end

        if sum(sum(MM))==0
            info = 0;
            A = [];b = [];C = [];
            if ~diff  % this function is not run by NSdiff
                if messages==1
                    fprintf('\nNO SOHS - one monomial of lowest or highest degree is cancelled\n\n');
                end
            end
            return;
        end
        const_cnt = const_cnt+1;
        A(:,const_cnt) = MM(:);  

	% for complex
        %b(const_cnt) = koef(i);
        b(const_cnt) = conj(koef(i));  %changed - because base is in the reverse order
        
    end   % if
end   % for
b = b';

% KC - 20100429
% U = reshape(sum(A'),len_base,len_base);
U = reshape(sum(A,2),len_base,len_base);

%%%  constraints with zero right hand side

BP = [];
ind_bp = [];
len_base_bp = 0;
for i = 1:len_base
    mon_i = base_ast{i,1};
    for j = 1:len_base
        if U(i,j)==0  % product  'base(i)*base(j)' doesn't appear in poly
            len_base_bp = len_base_bp+1;
            ind_bp = [ind_bp;i j];
            len = length(base_ast{i,1})+length(base{j,1});
            [product] = concate(base_ast{i,1},base{j,1});
            BP = [BP;[product,blanks(max_tot_len-length(product))]];
        end
    end
end

[BP_s,index_s] = sortrows(BP);
len_BP = size(BP_s,1);
if len_BP>0
    i = 1;    
    temp_prod = strcat('',BP_s(i,:));  % to remove blanks at the end

    % for complex:
    prod_j = temp_prod;  % if there is only one term in BP - happens in complex

    while i<=len_BP
        j = i+1;
        while j<=len_BP 
            prod_j = strcat('',BP_s(j,:)); % to remove blanks
            if strcmp(temp_prod,prod_j)==1  % temp_prod repeats at leat 2 times
                j = j+1;
            else
                break;
            end
        end

        % saj je monom, a ne?
        % temp_prod_rev = ast(temp_prod);
        temp_prod_rev = monom_NSast(temp_prod);

        if str_rel(temp_prod,temp_prod_rev)>=0    %% temp_prod appears  before temp_prod^*  or is equal to temp_prod^*
            MM = sparse(ind_bp(index_s(i:j-1),1),ind_bp(index_s(i:j-1),2),ones(j-i,1),len_base,len_base);
            MM = (MM+MM')/2;
            A = [A MM(:)];  
            b = [b;0];
        end
        i = j;
        temp_prod = prod_j;
    end
end
  
% OPTIMIZATION: if there is a constraint of type X_ii = 0, we eliminate this constraint and 
%     corresponding component of base and update all constraints

ok = 0;
while ~ok && ~lasten_base
    NZ = A~=0;  % where are nonzeros
    Snz = sum(NZ)';  % how many nonzero entries are in matrices defining constraints
    Snz_ones = find(Snz==1);
    ind_candidate = Snz_ones(b(Snz_ones)==0);  % indices of constraints of type Xii = 0, which will be removed
    if isempty(ind_candidate)
        ok = 1;
    else
        n = len_base;  % size of Matrix variable X   
        ind_del = [];  
        for j = 1:length(ind_candidate)
            A_j = reshape(A(:,ind_candidate(j)),n,n);
            where = find(A_j~=0);
            del = (where+n)/(n+1);  % this row and column will be deleted
            ind_del = [ind_del;del];
        end
        base_ast(ind_del,:) = '';  % erases entries in base with index in ind_del
        base(ind_del,:) = '';  % erases entries in base with index in ind_del
        len_base = len_base-length(ind_del);
        A(:,ind_candidate) = [];  %eliminates constraints corresponding to ind_candidate
        b(ind_candidate) = [];
        m = size(A,2); %% # of constraints which have remained
        A_new = [];  % new A
        for i = 1:m
            Ai = reshape(A(:,i),n,n);
            Ai(:,ind_del) = [];
            Ai(ind_del,:) = [];
            A_new(:,i) = Ai(:);
        end
        A = A_new;
    end
end

m = size(A,2);
A_sum = sum(A,1);
ind_del = [];
for i = 1:m
    if (A_sum(i)==0 && b(i)==0)
        ind_del = [ind_del;i];
    elseif A_sum(i)==0 && b(i)~=0
        error('\nNO SOHS factorisation: after elimination of constraints: CONTRADICTION')
    end
end
A(:,ind_del) = [];
b(ind_del) = [];
      
A = A';       
C = eye(len_base);


if messages==1 || messages==2
    fprintf('After Newton Chip Method keeping %d monomials.\n',len_base);
end





function rel = str_rel(str1,str2)

% relates str1 and str2
% returns 1, if str1 is in alphabetic order before str2 
% returns 0  if str1==str2
% returns -1 if str2 is in alphabetic order before str1 
%% Call: rel = str_rel(str1,str2)

s1 = ''; % remove possible blanks
j = 1;
for i = 1:length(str1)
    if str1(i)~=' '
        s1(j) = str1(i);
        j = j+1;
    end
end

s2 = '';
j = 1;
for i = 1:length(str2)
    if str2(i)~=' '
        s2(j) = str2(i);
        j = j+1;
    end
end

if strcmp(str1,str2)==1
    rel = 0;
    return;
end
S = cell(1,1);
S{1,1} = str1;
S{2,1} = str2;
SS = sort(S);
if(strcmp(SS{1,1},str1)==1)
    rel = 1;
else
    rel = -1;
end

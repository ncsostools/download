function [A_og,b_og]=gs(A,b,start)

m=size(A,1); % number of equations
if nargin ==1
    b=zeros(m,1);
end

if nargin < 3 || ~isnumeric(start)
    i=2;
    fprintf('Starting Gram-Schmidt process ...\n');
else
    i=start;
    fprintf('Starting Gram-Schmidt process - starting from the row %d ...\n',start);
end

A_og = A';
b_og=b;

del_num=0;
while i<=m
    for j=1:i-1
        prod = A_og(:,i)'*A_og(:,j);
        if prod~=0
            norm2=A_og(:,j)'*A_og(:,j);
            A_og(:,i) = A_og(:,i)*norm2-prod*A_og(:,j);
            b_og(i) = b_og(i)*norm2-prod*b_og(j);

            tmp=unique(abs([A_og(:,i);b_og(i)]));
            if tmp(1)==0
                tmp(1)=[];
            end
            tmp_len=length(tmp);
            if tmp_len>0
                skupni=tmp(1);
                % unique tudi posortira, torej je prvi najmanjsi
                if skupni>1
                    for k=2:tmp_len
                        skupni=gcd(skupni,tmp(k));
                    end
                    if skupni>1
                        A_og(:,i)=A_og(:,i)/skupni;
                        b_og(i)=b_og(i)/skupni;
                    end
                end
            end
        end
    end
    if norm (A_og(:,i)) < 1e-5
        A_og(:,i)=[];
        m=m-1;
        b_og(i)=[];
        fprintf('found linearly dependent equation ... deleting it ... \n');
        del_num=del_num+1;
    else
        i=i+1;          
    end
end
A_og = A_og';
if del_num>1
    fprintf('%d equations were deleted.\n',del_num);
end
fprintf('Gram-Schmidt process completed ...\n\n');

function [res] = alpha_deg(u,deg)
% checks whether 
% mindeg_\alpha f <= 2 deg_\alpha u(i)  <= deg_\alpha f, for i=1,....
%  deg ... matrix of degrees of monomials in undelying 
%  du ... degree vector of u
% res_new = [obj_up1 obj_low1 up1 low1]... for each row of u, where obj_up1
% and obj_low1 are optimal value of corresponding LP, up1 and low1 are
% decions whether to keep u or not

% created: 2009-09-08 by J. Povh
% last change: 2009-10-23 by J. Povh
% - deleted computing alpha degree for alpha\in \R^n_+
% implemented for u being matrix
% last: 14.3.2018, KC, optimset -> optimoptions in simplex -> dual-simplex

ss=sum(deg,1);
nonzero = ss~=0;
low = [];
up=[];
[m,n]=size(deg);
nn=n+1;
res=[];
c=1;

% optimset -> optimoptions in simplex -> dual-simplex
%options = optimset('Display', 'off', 'LargeScale', 'off', 'Simplex', 'on');
options = optimoptions('linprog','Display', 'off','Algorithm','dual-simplex');

len_u=size(u,1);
while c<=len_u
%	keyboard;
    du = u(c,:);
    % upper bound: min_{\alpha\in [-1,1]^n ,t}  t such that \alha^T(d_w-2du)-t <= 0
    f=zeros(1,nn);f(nn)=1;  %
    A=deg-2*ones(m,1)*du;
    b=zeros(m,1);
    A=[A -ones(m,1)];
    e=-ones(m,1);
    lb=-ones(nn,1);lb(nn)=-100;
    ub = ones(nn,1);ub(nn)=100;
    [x,obj_up1,exitflag] = linprog(f,A,b,[],[],lb,ub,[],options);
    obj_up1 = round(1e12*obj_up1)*1e-12;
    up1 = obj_up1 >=0;

    %NEW  lower bound: max_{\alpha \in [-1,1]^n,t}  t such that \alha^T(d_w-2du)-t >= 0
    f=zeros(1,nn);f(nn)=-1;  %linprog computes min
    A=deg-2*ones(m,1)*du;
    b=zeros(m,1);
    A=[A -ones(m,1)];
    e=ones(m,1);
    lb=-ones(nn,1);lb(nn)=-100;
    ub = ones(nn,1);ub(nn)=100;
    [x,obj_low1] = linprog(f,-A,-b,[],[],lb,ub,[],options);
    obj_low1 = round(1e12*obj_low1)*1e-12;
    obj_low1 = -obj_low1;
    low1 = obj_low1 <=0;
    res=[res;obj_up1 obj_low1 up1 low1];
    next = c+1;
    if (up1+low1 < 2)  % current du is not candidate
        while (next<=len_u)&& min(du==u(next,:))
            next = next+1;
            res=[res;obj_up1 obj_low1 up1 low1];
        end
    end
    c = next;
end
function [NewSDP_data, Xnew_small, Vnew]=NCpostSolve(SDP_data,X,z,Vprev)
% z is a set of orthogonal integer vectors from the kernel of X
% Function reduces the size of X by using the fact that z is in the kernel of X
% OUTPUT
% Returns X_new = P*\hat X *P^T, where
%  \hat X is feasible solution of 
%    \min tr(C_new*\hat X)
%    such that \hat X ... PSD
%              trace (P^T A_i * P* \hat X) = b_i
%    where  A_i,b_i,C  are from SDP_data
%
%   NewSDP_data ... contains A_new, b_new, C_new
% 
%   INPUT
%   SDP_data ... sdp data for sdp solver
%   X solution corresponding to SDP_data
%   
%% Call: [NewSDP_data, Xnew_small, Vnew]=NCpostSolve(SDP_data,X,z,Vprev)

% created 2009-11-25 by JP
% last modified 2009-12-22 by J.P.
% last modified 2010-01-15 by K.C.
% last modified 19. 9. 2011 by K.C. (v -> z, n_v -> n_z)

if nargin == 3
    Vprev={};
end

% in case of premature end
NewSDP_data=SDP_data;
Xnew_small=X;
Vnew=Vprev;

n=size(X,1);

if size(z,1)~=n && size(z,2)==n
    z=z';
elseif size(z,1)~=n
    fprintf('\nNumber of rows in X and z do not match!\n');
    return;
end

V=[z eye(n)];
V_og = V;

n_z = size(z,2);

% if norm(X*z) > 1e-2
%     fprintf('Vector seems not to be the kernel of the matrix');
%     return;
% end

A=SDP_data.A;
b=SDP_data.b;
C=SDP_data.C;
K=SDP_data.K;


% to se nikjer ni uporabilo, zato zakomentiral (KC)
% alpha = z'*z;

i = 2;
while i <= size(V_og,2)
    for j=1:i-1
        prod = V_og(:,i)'*V_og(:,j);
        if prod~=0
            tmp=V_og(:,j)'*V_og(:,j);
%             V_og(:,i) = V_og(:,i)-prod*V_og(:,j)/(V_og(:,j)'*V_og(:,j));
%             V_og(:,i) = V_og(:,i)*(V_og(:,j)'*V_og(:,j));
            V_og(:,i) = V_og(:,i)*tmp-prod*V_og(:,j);

            tmp=unique(abs(V_og(:,i)));
            if tmp(1)==0
                tmp(1)=[];
            end
            tmp_len=length(tmp);
            if tmp_len>0
                skupni=tmp(1);
                % unique tudi posortira, torej je sedaj prvi najmanjsi
                if skupni>1
                    for k=2:tmp_len
                        skupni=gcd(skupni,tmp(k));
                    end
                    if skupni>1
                        V_og(:,i)=V_og(:,i)/skupni;
                    end
                end
            end
            
        end
    end
    if norm (V_og(:,i)) < 1e-5
        V_og(:,i)=[];
    else
        i=i+1;
    end
end
lambda=V_og'*V_og;
if norm(diag(lambda))~=norm(lambda,'fro')
    error('ERROR: V is not orthogonal');
end

lam_denom = 1;
tmp_diag=unique(diag(lambda));
tmp=length(tmp_diag);
for i=1:tmp
    lam_denom = lcm(lam_denom,tmp_diag(i));
end

lambda_inv=eye(n);
for i=1:n
    lambda_inv(i,i)=lam_denom/lambda(i,i);
end

A_new=[];
b_new=[];
V_og_l=V_og*lambda_inv;
for i=1:size(A,1)
    A_i=V_og_l'*reshape(A(i,:),n,n)*V_og_l;
    B_i=A_i(n_z+1:n,n_z+1:n);
    if norm(B_i)
        A_new=[A_new; B_i(:)'];
        b_new=[b_new;b(i)];
    end
end

C=reshape(C,n,n);
C_new=C(n_z+1:n,n_z+1:n);
K.s=n-n_z;

[XX,Y,INFO]=solveSDP(A_new,b_new,C_new(:),K);

disp(' ');
disp(INFO);

error_found=false;
if INFO.pinf==1
    fprintf('ALERT: Primal infeasibility ... \n');
    error_found=true;
end
if INFO.dinf == 1
    fprintf('ALERT: Dual infeasibility ... \n');
    error_found=true;
end
if INFO.numerr==2
    if INFO.feasratio<0.2
        fprintf('ALERT: Serious error ... \n');
        error_found=true;
    elseif INFO.feasratio<0.8
        fprintf('ALERT: Numerical problems ... \n');
        error_found=true;
    end
end

if error_found
    % v resnici vrnes torej stare vrednosti, ker je to na zacetku def
    fprintf('Undoing changes ... \n');
    return;
else
    NewSDP_data.A=A_new;
    NewSDP_data.b=b_new;
    NewSDP_data.C=C_new;
    NewSDP_data.K=K;

    Xnew_small=reshape(XX,K.s,K.s);
    % samo test
    % X1 = [zeros(n_z,n);zeros(n-n_z,n_z) Xnew_small];
    % Xnew = V_og_l*X1*V_og_l';

    Vnew=[V_og_l,Vprev];
end

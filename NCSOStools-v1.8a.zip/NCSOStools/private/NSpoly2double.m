function B = NSpoly2double(A)

B = NCpoly2double(A);
function ekv_mon = cycEqPreRep(f)

% constructs cell of cyclically equivalent monomials and adherent sums
% of coefficients

% created: KC
% last modified: KC
% last modified: 25. 5. 2010 KC
% last modified: 12. 6. 2010 KC

structpoly=struct(NCpoly(f));
koefs=structpoly.koef;
monoms=structpoly.monom;

if size(monoms,1)==1
    ekv_mon={monoms,koefs};
else
    razredi=0;
    while ~(isempty(koefs))
        testni=monoms{1,1};
        eqmonoms=cycEqMonoms(testni); % 20100612

        za_zbrisati=1;
        koefSum=koefs(1,1);
        razredi=razredi+1;
        ekv_mon{razredi,1}={testni};
        stevecekv=1;
        for i=2:size(monoms,1)
%             if isCycEqMonom(testni, monoms{i,1})
            if any(strcmp(monoms{i,1},eqmonoms)) % 20100612
                koefSum = koefSum + koefs(1,i);
                stevecekv=stevecekv+1;
                ekv_mon{razredi,1}{stevecekv,1}=monoms{i,1};
                za_zbrisati=[za_zbrisati,i];
            end
        end
        ekv_mon{razredi,2}=koefSum;
        monoms(za_zbrisati,:)=[];
        koefs(:,za_zbrisati)=[];
    end
end
function eqmonoms=cycEqMonoms(monom)

% description: eqmonoms=cycEqMonoms(monom) collects all cyclically
% equivallent monomials to given monomial monom
% 
% arguments: monom is string representing given monomial
% 
% output: eqmonoms is cell of cyclically equivallent monomials
% 
% possible usage: cycEqMonoms(monom)

% created: 4. 2. 2009 KC
% last modified: 4. 3. 2009 KC
% last modified: 25. 5. 2010 KC
% last modified: 12. 6. 2010 KC
% last : 14.3.2018 KC, nargchk -> narginchk

%error(nargchk(1,1,nargin));
narginchk(1,1);

if ~isa(monom,'char')
    error('ERROR: input should be a STRING representing monomial.');
end

len_monom=length(monom);
pozicije=strfind(monom,'*');
size1=length(pozicije);
eqmonoms=cell(size1+1,1);
eqmonoms{1}=monom;
if size1>0
    monom2=[monom '*' monom]; % 20100612
    for i=1:size1
%         monom_cyc=[monom(pozicije(i)+1:len_monom) '*' monom(1:pozicije(i)-1)];
        monom_cyc=monom2(pozicije(i)+1:pozicije(i)+len_monom); % 20100612
        eqmonoms{i+1}=monom_cyc;
    end
    eqmonoms=unique(eqmonoms);
end

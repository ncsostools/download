function [deg,var] = compute_deg(poly)

% computes degrees of monomials in poly
% returnes matrix deg such that
%   deg_i,j = degree of i-th variable in j-th monomial of poly
%% Call: [deg,var] = compute_deg(poly)

% created: 19. 2. 2009 by J. Povh
% last modified: 4. 3. 2009 KC
% last modified: 24. 5. 2010 KC (added var to output)
% last: 14.3.2018, KC, nargchk -> narginchk

%error(nargchk(1,1,nargin));
narginchk(1,1);

poly=NCpoly(poly);

var=NCvarsactive();


num_var = length(var);  % number of variables

structpoly=struct(poly);
monom=structpoly.monom;

len_m=length(monom);
deg=zeros(len_m,num_var);

var_zv=cell(1,num_var);
for j=1:num_var  
    var_zv{j}=['*',var{j},'*'];
end

for i=1:len_m
    str = ['*',monom{i,1},'*'];
    for j=1:num_var  
        deg(i,j)=length(strfind(str,var_zv{j}));
    end
end

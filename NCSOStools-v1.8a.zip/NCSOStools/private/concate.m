function prod = concate(fact1,fact2)
% concatenates fact1 and fact 2 and puts '*' between them
% prod = fact1*fact2 if non of them is equal to ''
% otherwise prod = nontrivial factor
% created: 20. 2. 2008 by J. Povh
% last modifies: 20. 2. 2008 by J. Povh
% Call: prod = concate(fact1,fact2);

len1 = length(fact1);
len2 = length(fact2);

if (len1+len2)==0
    prod='';
elseif (len1==0 || len2==0)
    prod=strcat(fact1,fact2);
else
    prod=strcat(fact1,'*',fact2);
end

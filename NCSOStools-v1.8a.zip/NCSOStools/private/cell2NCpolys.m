function polys=cell2NCpolys(cell)

n=length(cell);
for i=1:n
    polys(i,1)=factor2NCpoly(1,cell(i));
end
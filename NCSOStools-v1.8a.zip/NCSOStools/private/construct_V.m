
function [V,V_deg,ekv_mon_f,error]=construct_V(f,messages)
% construsts base V for cycl. equiv. check
% constructs all monomials of length at most deg (f)/2

V=[];
var=NCvarsactive();
% num_var = length(var);  % number of variables

ekv_mon_f = cycEqPreRep(f);

error=false;

% len_m=size(ekv_mon_f,1);
% deg=zeros(len_m,num_var);

deg = compute_deg(f);
V_deg =[];
% dodano posebej za stevila - Janez preveri ce je to pravi pogoj!
if all(deg==0)
    V={''};
    V_deg = zeros(size(deg,2));
    return;
end

max_tot_len = 0;
for i = 1:size(ekv_mon_f)
    max_tot_len = max(max_tot_len,length(ekv_mon_f{i,1}));
end


len_mon=sum(deg,2);  %contains lengths of monomials
deg_max=max(len_mon);   %max degree of polynomial
deg_min=min(len_mon);  %min degree of polynomial
deg_var_min = min(deg,[],1);  % for every variable we compute its minimal degree in poly
deg_var_max = max(deg,[],1);  % for every variable we compute its maximal degree in poly
if ~all(mod(deg_var_min,2)==0) ||~all(mod(deg_var_max,2)==0) || ~all(mod(deg_max,2)==0) || ~all(mod(deg_min,2)==0)
    if messages
        fprintf('\n***** Polynomial is NOT CYCLICALLY EQUIVALENT to SOHS - min or max degree is odd *****\n');
    end
    error=true;
    return;
end

zero = find(deg_var_max==0);
deg_var_min(zero)=[];
deg_var_max(zero)=[];
num_var=length(deg_var_max);
deg(:,zero)=[];

var(zero)=[];
P=[];
for i=1:num_var
    P=cartprod(P,[deg_var_min(i)/2:deg_var_max(i)/2]');
end
where_del = [];
for i=1:size(P,1)
    if sum(P(i,:))< deg_min/2 || sum(P(i,:)) > deg_max/2
        where_del=[where_del;i];
    end
end  
P(where_del,:)=[];
count = 0;
V=cell(1,1);
for i=1:size(P,1) % constructing base
    len =sum(P(i,:));
    if ~len
        count = count+1;  
        V{count,1}='';
        V_deg = [V_deg;zeros(1,size(deg,2))];
        continue;
    end
    if len > deg_max/2  % all monimioals in base V must be of length at most deg_max/2
        continue;
    end
    tot=[1:len];
    position = [];
    curr_len = len;  
    for j=1:size(P,2)
        if ~P(i,j)
            where = [];
        else
            where=nchoosek(tot,P(i,j));
        end
        position =cartprod(position,where);
        curr_len = curr_len - P(i,j);
        tot = [1:curr_len];
    end  % for
    for k=1:size(position,1) % we construct monomials from position
        tot=[1:len];
        which=zeros(1,len);
        start = 1;
        for j = 1:size(P,2)
            finish  = start + P(i,j)-1;
            which(tot(position(k,start:finish)))=j;
            tot(position(k,start:finish))=[];
            start = finish+1;
        end
        monom = var{which(1)};
        for t=2:length(which)
            monom = [monom,'*',var{which(t)}];
        end
        count = count + 1;
        V{count,1}=monom;
        V_deg=[V_deg;P(i,:)];
    end
end
%keyboard;
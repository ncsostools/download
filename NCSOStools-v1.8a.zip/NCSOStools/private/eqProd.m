function ekv_mon = eqProd(monoms)

% input is a cell vector of strings representing monomials, ie. {'x';'x*y'}
% output is cell of all possible products {w^*u; w,u \in monomials\} and
% adherent indexes 

% last modified: 1. 9. 2010 JP
% last : 14.3.2018 KC, nargchk -> narginchk

%error(nargchk(1,1,nargin));
narginchk(1,1);

if ~isa(monoms,'cell')
    error('ERROR: input should be a CELL of monomials ie. {''x'';''x*y''}.');
end

m=size(monoms,1);
produkti=cell(m^2,1);
for i=1:m
    for j=1:m     
        produkti{(i-1)*m+j,1}={concate(monom_ast(monoms{i,1}),monoms{j,1}),[i j]};
    end
end

if length(produkti)==1
    ekv_mon={{produkti{1,1}{1,1},[1 1]}};
else
    razredi=0;
    ekv_mon=cell(1,1);
    while ~(isempty(produkti))
        testni=produkti{1,1}{1,1};
        razredi=razredi+1;
        ekv_mon{razredi,1}{1,1}=testni;
        ekv_mon{razredi,1}{1,2}=produkti{1,1}{1,2};
        stevecekv=1;
        
        tmp=length(produkti);
        brisi=false(tmp,1);
        brisi(1)=true;
        for i=2:tmp
            if strcmp(produkti{i,1}{1,1},testni)
                stevecekv=stevecekv+1;
                ekv_mon{razredi,1}(stevecekv,:)=produkti{i,1};
                brisi(i)=true;
            end
        end
        produkti(brisi)=[];
    end
end

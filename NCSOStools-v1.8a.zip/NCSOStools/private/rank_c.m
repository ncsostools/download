function [r,r_col,tol,type]=rank_c(M,tol,type)

% custom rank computation
%
% ce zelis rocno vpisati type, ne zelis pa vpisati tol, vpisi [] za tol ...
% type==1: rank, type==2: rref, type==3: svd in kvocienti, type==4: stevilo
% dolocimo z rank, kateri pa z rref
%
% r je rang, r_col so pripadajoci vektorji, tol in type sta tolerenca in
% tip, ki sta bila upostevana pri racunanju

% default type
if nargin<3
    type=4;
end

% default tol
if nargin==1 || (nargin>1 && isempty(tol))
    switch type
        % rank
        case 1
            % tol = sqrt(max(size(M)) * eps(norm(M)));
            % tol=1e-4;
            tol = min(1e-4, sqrt(sqrt(max(size(M)) * eps(norm(M)))));
        % rref
        case 2
            % tol = sqrt(sqrt(max(size(M)) * eps(norm(M))));
            % tol=1e-3;
            tol = min(1e-3, sqrt(sqrt(max(size(M)) * eps(norm(M)))));
        % singular value change
        case 3
            tol=1e-4;
        % rank in rref
        case 4
            % tol = sqrt(max(size(M)) * eps(norm(M)));
            % tol=1e-4;
            tol = min(1e-3, sqrt(sqrt(max(size(M)) * eps(norm(M)))));
    end
end

switch type
    case 1
        [m,n]=size(M);
        r_col=1;
        for i=2:n
            if rank(M(:,[r_col,i]),tol)>rank(M(:,r_col),tol)
                r_col=[r_col,i];
            end
        end
        r=length(r_col);
    case 2
        [dum1,r_col]=rref(M,tol);
        r=length(r_col);
    case 3
        [m,n]=size(M);
        r_col=1;
        for i=2:n
            s1=svd(M(:,r_col));
            s2=svd(M(:,[r_col,i]));
            l1=length(s1);
            l2=length(s2);
            dum1=find(s1(2:l1)./s1(1:l1-1)<tol);
            dum2=find(s2(2:l2)./s2(1:l2-1)<tol);
            if isempty(dum1)
                r1=l1;
            else
                r1=dum1(1);
            end
            if isempty(dum2)
                r2=l2;
            else
                r2=dum2(1);
            end
            
            if r2>r1
                r_col=[r_col,i];
            end
        end
        r=length(r_col);
    case 4
        r=rank(M,tol);
        if nargout>1
            [dum,r_rr]=rref(M,tol);
            if length(r_rr)<r
                % tmp=0.5;
                % tmp=0.75;
                tmp=0.67; 
                tol_temp=tol*tmp;
            elseif length(r_rr)>r
                % tmp=2;
                % tmp=1.35;
                tmp=1.5;
                tol_temp=tol*tmp;
            end
            while length(r_rr)~=r
                [dum,r_rr]=rref(M,tol_temp);
                tol_temp=tol_temp*tmp;
                if (tmp<1 && length(r_rr)>r) || (tmp>1 && length(r_rr)<r)
                    % fprintf('\nERROR: Finding of r linearly independent vectors failed.\n\n');
                    % reset tol???
                    break;
                end
            end
            r_col=r_rr;
            r=length(r_col);
        end
end

function P=cartprod(A,B,type)

% description: returns cartesian product of rows of A and B
% A and B must be numeric matrices (row vectors)
% P is a matrix, where rows contain rows [A(i,:) B(j,:), for all i,j
% 
%% Call: P=cartprod(A,B);

% created: 3. 2. 2009 by JP
% last modified: 3. 2. 2009
% last: 19.5.2010 KC (type)

P=[];
if nargin ==0
    return;
end
if nargin==1 
    P=A;
end
if nargin<3 
    type=1;
end
    
if isempty (A)
    P=B;
end
if nargin == 2 && isempty (B)
    P=A;
end

if type==2
    for j=1:size(B,1)
        for i=1:size(A,1)
            P=[P;A(i,:) B(j,:)];
        end
    end
else
    for i=1:size(A,1)
        for j=1:size(B,1)
            P=[P;A(i,:) B(j,:)];
        end
    end
end

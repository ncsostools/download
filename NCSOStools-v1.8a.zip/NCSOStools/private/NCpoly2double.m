function B = NCpoly2double(A)

B=[];
[m,n]=size(A);
C=zeros(m,n);

for i=1:m
    for j=1:n
        tmp=struct(A(i,j));
        tmpm=tmp.monom;
        if length(tmpm)==1 && isempty(tmpm{1})
            C(i,j)=tmp.koef;
        else
            fprintf('\n***** ERROR: Element on position %d,%d is not a constant! *****\n',i,j);
            fprintf('***** Conversion failed!                                *****\n');
            return;
        end
    end
end


B=C;
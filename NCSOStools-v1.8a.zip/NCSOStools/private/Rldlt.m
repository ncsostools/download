function [L,D,P,err]=Rldlt(A)
% [L,D,P,err]=Rldlt(A)
% A must be a cell of two matrices - numenators and denominators

A_stev=A{1};
A_imen=A{2};

n=size(A_stev,1);
% L=zeros(n,n);
% L=eye(n);
L_stev=eye(n);
L_imen=ones(n);

D_stev=zeros(n);
D_imen=ones(n);

L={L_stev,L_imen};
D={D_stev,D_imen};

P=eye(n);
piv=1:n;
err=0;
v_imen=ones(1,n);
v_stev=zeros(1,n);
d_imen=ones(1,n);
d_stev=zeros(1,n);

for j=1:n,
    [max_val,max_ind]=max(diag(A_stev(j:n,j:n)./A_imen(j:n,j:n)));
    q=j+max_ind-1;

    if q~=j
        piv([j q])=piv([q j]);

        A_stev([j q],:)=A_stev([q j],:);
        A_stev(:,[j q])=A_stev(:,[q j]);
        A_imen([j q],:)=A_imen([q j],:);
        A_imen(:,[j q])=A_imen(:,[q j]);

        L_stev([j q],:)=L_stev([q j],:);
        L_stev(:,[j q])=L_stev(:,[q j]);
        L_imen([j q],:)=L_imen([q j],:);
        L_imen(:,[j q])=L_imen(:,[q j]);
    end
    
    if (A_stev(j,j)/A_imen(j,j)<0) || (A_stev(j,j)==0 && ~all(A_stev(:,j)==0))
        err=j;
        D_stev=diag(d_stev);
        dum=length(d_imen);
        D_imen=ones(dum)-eye(dum)+diag(d_imen);
        D={D_stev,D_imen};
        P=P(:,piv);
        return;
    elseif A_stev(j,j)/A_imen(j,j)>0
        if (j > 1),

            % v(1:j-1)=L(j,1:j-1).*d(1:j-1);
            for k=1:j-1
                try
                    dummy=Rtimes({L_stev(j,k),L_imen(j,k)},{d_stev(k),d_imen(k)});
                catch
                    fprintf('ERROR: Too large numbers in rational LDLT decomposition.\n');
                    L={[],[]};
                    D={[],[]};
                    P=[];
                    err=-1;
                    return;
                end
                v_stev(k)=dummy{1};
                v_imen(k)=dummy{2};
            end
            
            % v(j)=A(j,j)-L(j,1:j-1)*v(1:j-1)';
            try
                dummy = Rminus({A_stev(j,j),A_imen(j,j)},Rtimes({L_stev(j,1:j-1),L_imen(j,1:j-1)},{v_stev(1:j-1)',v_imen(1:j-1)'}));
            catch
                fprintf('ERROR: Too large numbers in rational LDLT decomposition.\n');
                L={[],[]};
                D={[],[]};
                P=[];
                err=-1;
                return;
            end
            v_stev(j) = dummy{1};
            v_imen(j) = dummy{2};
            
            % d(j)=v(j);
            d_stev(j)=v_stev(j);
            d_imen(j)=v_imen(j);

            if d_stev(j)/d_imen(j)<0
                err=j;
                D_stev=diag(d_stev);
                dum=length(d_imen);
                D_imen=ones(dum)-eye(dum)+diag(d_imen);
                D={D_stev,D_imen};
                P=P(:,piv);
                return;
            elseif (d_stev(j)/d_imen(j)>0) && (j<n),
                % L(j+1:n,j)=(A(j+1:n,j)-L(j+1:n,1:j-1)*v(1:j-1)')/v(j);
                % na koncu je namesto deljenja mnozenje z obratnim!
                try
                    dummy=Rtimes(Rminus({A_stev(j+1:n,j),A_imen(j+1:n,j)},Rtimes({L_stev(j+1:n,1:j-1),L_imen(j+1:n,1:j-1)},{v_stev(1:j-1)',v_imen(1:j-1)'})),{v_imen(j),v_stev(j)});
                catch
                    fprintf('ERROR: Too large numbers in rational LDLT decomposition.\n');
                    L={[],[]};
                    D={[],[]};
                    P=[];
                    err=-1;
                    return;
                end
                L_stev(j+1:n,j)=dummy{1};
                L_imen(j+1:n,j)=dummy{2};
            end
        else
            v_stev(1)=A_stev(1,1);
            v_imen(1)=A_imen(1,1);
            d_stev(1)=v_stev(1);
            d_imen(1)=v_imen(1);
            if d_stev(1)/d_imen(1)<0
                err=1;
                D_stev=diag(d_stev);
                dum=length(d_imen);
                D_imen=ones(dum)-eye(dum)+diag(d_imen);
                D={D_stev,D_imen};
                P=P(:,piv);
                return;
            elseif d_stev(1)/d_imen(1)>0
                % L(2:n,1)=A(2:n,1)/v(1);
                % na koncu je namesto deljenja mnozenje z obratnim!
                try
                    dummy=Rtimes({A_stev(2:n,1),A_imen(2:n,1)},{v_imen(1),v_stev(1)});
                catch
                    fprintf('ERROR: Too large numbers in rational LDLT decomposition.\n');
                    L={[],[]};
                    D={[],[]};
                    P=[];
                    err=-1;
                    return;
                end
                L_stev(2:n,1)=dummy{1};
                L_imen(2:n,1)=dummy{2};
            end
        end
    end
end
D_stev=diag(d_stev);
dum=length(d_imen);
D_imen=ones(dum)-eye(dum)+diag(d_imen);
P=P(:,piv);
if nargout==2
    if err>0
        error('ERROR: Matrix is not a PSD!');
    else
        % L=P*L;
        try
            dummy=Rtimes({P,ones(n)},{L_stev,L_imen});
        catch
            fprintf('ERROR: Too large numbers in rational LDLT decomposition.\n');
            L={[],[]};
            D={[],[]};
            P=[];
            err=-1;
            return;
        end
        L_stev=dummy{1};
        L_imen=dummy{2};
    end
end
L={L_stev,L_imen};
D={D_stev,D_imen};


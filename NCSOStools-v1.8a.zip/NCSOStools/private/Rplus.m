function C=Rplus(A,B)

stev1=A{1};
imen1=A{2};
stev2=B{1};
imen2=B{2};

imen3=lcm(imen1,imen2);
[m,n]=size(stev1);
%for i=1:m
%    for j=1:n
%        stev3(i,j)=stev1(i,j)*imen3(i,j)/imen1(i,j)+stev2(i,j)*imen3(i,j)/imen2(i,j);
%    end
%end
stev3(1:m,1:n)=stev1(1:m,1:n).*(imen3(1:m,1:n)./imen1(1:m,1:n))+stev2(1:m,1:n).*(imen3(1:m,1:n)./imen2(1:m,1:n));
dum=gcd(stev3,imen3);
stev3=stev3./dum;
imen3=imen3./dum;
C={stev3,imen3};

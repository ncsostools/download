function [Xp,errP]=Rproj(X,A,b)


Xp=[];
errP=false;
A_stev=A{1};
A_imen=A{2};
[m,n]=size(A_imen);

% normA = sum(A.*A,2);
for i=1:m
    tmp={[0],[1]};
    for j=1:n
        try
            tmp=Rplus(tmp,{A_stev(i,j)^2,A_imen(i,j)^2});
        catch
            fprintf('ERROR: Too large numbers in rational projection.\n');
            errP=true;
            return;
        end
    end
    normA_stev(i,1)=tmp{1};
    normA_imen(i,1)=tmp{2};
end

% Xp=X - A'*((A*X-b)./normA);
try
    dum=Rminus(Rtimes(A,X),b);
catch
    fprintf('ERROR: Too large numbers in rational projection.\n');
    errP=true;
    return;
end

for i=1:m
    try
        dum2=Rtimes({dum{1}(i),dum{2}(i)},{normA_imen(i),normA_stev(i)});
    catch
        fprintf('ERROR: Too large numbers in rational projection.\n');
        errP=true;
        return;
    end

    tmp_stev(i,1)=dum2{1};
    tmp_imen(i,1)=dum2{2};
end
try
    Xp = Rminus(X,Rtimes({A_stev',A_imen'},{tmp_stev,tmp_imen}));
catch
    fprintf('ERROR: Too large numbers in rational projection.\n');
    errP=true;
    return;
end

        

function [V,V_deg] = generateFullV(d_max,var)
%
% generateFullV
%
% generates all NC monimials of degree <= d_max in variables defined by a
% cell var
%
%% Call: [V,V_deg] = generateFullV(d_max,var)

% last change 26.4.2010 KC
% last change 7.7.2016 KC
% last modified: 14.3.2018 KC, nargchk -> narginchk


%error(nargchk(1,2,nargin));
narginchk(1,2);

num_var = length(var);  % number of variables

P=[];
for i=1:num_var  % we take all possible monomials of length d
    P=cartprod(P,[0:d_max]',2);

    % premaknil noter, da sproti pocisti - 7.7.2016
    ind_del=[];
    for i=1:size(P,1)
        if sum(P(i,:))>d_max
            ind_del=[ind_del;i];
        end
    end
    P(ind_del,:)=[];

end

% premaknil gor - 7.7.2016
% ind_del=[];
% for i=1:size(P,1)
%     if sum(P(i,:))>d_max
%         ind_del=[ind_del;i];
%     end
% end
% P(ind_del,:)=[];
% 
count = 0;
V_new=cell(1,1);

V_deg=[];
for i=1:size(P,1)
    p_deg=sum(P(i,:));
    V_p=[];
    p=[];
    for j=1:size(P,2)
        p=[j*ones(1,P(i,j)) p];
    end
    if length(p)==1
        count = count +1;
        V_new{count,1}=var{p};
        V_deg(count,1)=p_deg;
        continue;
    end
    V_p=unique(perms(p),'rows'); 
    for j=1:size(V_p,1)
        v='';
        for k=1:size(V_p,2)-1
            v = [v,var{V_p(j,k)},'*'];
        end
        v = [v,var{V_p(j,k+1)}]; % append the last var   
        count = count +1;
        V_new{count,1}=v;
        V_deg(count,1)=p_deg;
    end
end


[V_deg,ind_s]=sort(V_deg);

V=V_new(ind_s);

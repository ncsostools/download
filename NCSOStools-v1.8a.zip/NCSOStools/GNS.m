function [X,err]=GNS(V,M,vars,tol,rank_bound,sym)

% GNS
%
% description: [X,err]=GNS(V,M,vars,tol,rank_bound) prepares a matrix X for
% the AWbd function by performing the Gelfand-Naimark-Segal construction.
%
% arguments:
% V - cell of all monomials of degree up to d
% M - a flat square matrix
% vars - cell of variables
% tol - tolerance for computing the rank of a matrix
% rank_bound - optional upper bound for the rank of a matrix
% sym - optional (whether look for - and do - the symetrization of matrices
% in outpux X)
%
% output:
% X - a matrix where each of its rows represents a square matrix
% err - if it equals 0 means that program ended with success otherwise the
%    procedure failed 
%
% possible usage: GNS(V,M,vars), GNS(V,M,vars,tol),
% GNS(V,M,vars,tol,rank_bound), GNS(V,M,vars,tol,rank_bound,sym)
%
% see also: NCFlatExt, AWbd, NCcycOpt
%
%% Call: [X,err]=GNS(V,M,vars,tol,rank_bound,sym)

% last change: 18. 4. 2010 KC (rref vs. rank)
% last change: 16. 5. 2010 KC (chol vs. cholpsd)
% last: 5. 6. 2010 KC
% last: 20. 2. 2015 KC (sym - for nsvar)
% last modified: 14.3.2018 KC, nargchk -> narginchk

%error(nargchk(4,6,nargin));
narginchk(4,6);

X=[];
err=0;

if nargin==4
    rank_bound=length(M);
    sym=true;
elseif nargin==5
    sym=true;
end

% length of V
m=length(V);
if (m~=size(M,1) || m~=size(M,2))
    error('ERROR: Dimensions do not match.\n');
end

fprintf('\n***** NCSOStools: module GNS started *****\n\n');

% rank M
% r=rank(M,tol);
[r,linear_indep]=rank_c(M(:,1:rank_bound),tol);

if r==0
    err=3;
    fprintf('ERROR! Error in rank of M.\n');
    fprintf('Module GNS is quiting.\n');
    return;
end    

% should we do checking on psd of M?

% number of variables
n=length(vars);

    % % solution with command rref
    % [dum,r_rr]=rref(M,tol);
    % if length(r_rr)<r
    %     tmp=0.5;
    %     tol_temp=tol*tmp;
    % elseif length(r_rr)>r
    %     tmp=2;
    %     tol_temp=tol*tmp;
    % end
    % while length(r_rr)~=r
    %     [dum,r_rr]=rref(M,tol_temp);
    %     tol_temp=tol_temp*tmp;
    %     if (tmp<1 && length(r_rr)>r) || (tmp>1 && length(r_rr)<r)
    %         err=1;
    %         fprintf('\nERROR: Finding of r linearly independent vectors failed.\n\n');
    %         return;
    %     end
    % end
    % linear_indep=r_rr;

fprintf('found %d linearly independent vectors ...\n',r);
% da vidis, katere, odkomentiraj
% disp(linear_indep);


% take r lin. indep. columns of M
c=M(:,linear_indep);
fprintf('using corresponding columns of a matrix ...\n');


% gs - orthonormal (euclidian scalar product)
d=c;
d(:,1)=d(:,1)/sqrt((d(:,1)'*d(:,1)));
for i=2:r
    for j=1:i-1
        d(:,i) = d(:,i) - ((d(:,i)'*d(:,j))/(d(:,j)'*d(:,j))) * d(:,j);
    end
    d(:,i)=d(:,i)/sqrt((d(:,i)'*d(:,i)));
end

% solve system of lin. eq.: write columns M*d as lin. comb. of d
Mhat = d\(M*d);   % Mhat =d^T*M*d  Mhat is M in base b, i.e. d*Mhat e_1 = Md1
% Cholesky decomposition
L = cholPSD(Mhat);

% solve system of lin. eq.: write columns c as lin. comb. of d
P = d\c;  % P prehodna matrika med bazama: c=d*P

% corresponding words in V to the lin. indep. columns of M
w=V(linear_indep);
fprintf('using corresponding words in a cell of monomials ...\n');
% da vidis, kateri so ti monomi, odkomentiraj
% disp(w');

fprintf('constructing final matrices ... ');
for i=1:n
    for j=1:r
        if isempty(w{j})
            tmp_v=vars{i};
        else
            tmp_v=[vars{i},'*',w{j}];
        end
        tmp_ind=find(strcmp(tmp_v,V));
        
        % just for sure - actually not needed if M is really flat
        if isempty(tmp_ind)
            err=2;
            fprintf('\nERROR! Missing monomial.\n');
            fprintf('Module GNS is quiting.\n');
            return;
        end
        
        tmp_c = M(:,tmp_ind);
        
        % solve system of lin. eq.: write column tmp_c as lin. comb. of c
        alfa(:,j,i)=c\tmp_c;
    end
end

% generate a matrix for Kojima part
left=inv(L')*P;
right=inv(P)*L';
bln_warn=zeros(1,n);
for i=1:n
    dum=left*alfa(:,:,i)*right;
    if sym
        norm_nesim=norm(dum-dum')/norm(dum);
        % da vidis, koliko je nesimetricna, odkomentiraj
        % fprintf('\n%d. relativna norma nesimetricnosti: %f\n',i,norm_nesim);
        if norm_nesim<0.01
            bln_warn(i)=1;
        elseif norm_nesim<0.1
            bln_warn(i)=2;
        elseif norm_nesim<1
            bln_warn(i)=3;
        else
            err=4;
            fprintf('\nERROR! Matrices are highly nonsymmetric.\n');
            fprintf('Module GNS is quiting.\n');
            X=[];
            return;
        end
    end
    X=[X;dum(:)'];
end

fprintf('done.\n');

if any(bln_warn==3)
    fprintf('WARNING: Some matrices are quite nonsymmetric. The result might not be accurate!\n');
elseif any(bln_warn==2 | bln_warn==1)
    symmet=find(bln_warn==2 | bln_warn==1);
    n=length(symmet);
    m=sqrt(size(X,2));
    for i=1:n
        dum=reshape(X(i,:),m,m);
        dum=(dum+dum')/2;
        X(i,:)=dum(:)';
    end
    if any(bln_warn==2)
        fprintf('WARNING: Some matrices was slightly nonsymmetric.\n');
        fprintf('Symmetrization was done. The result is an approximation of the accurate value.\n');
    end
end

fprintf('\n***** NCSOStools: module GNS completed *****\n\n');


function [V1,V2,V3]=BMVsets(m,k)

% BMVsets
%
% description: [V1,V2,V3]=BMVsets(m,k) constructs the reduced monomial
% basis needed for the Gram matrix of (m,k) BMV polynomial with x^2 and y^2
% as arguments. See KLEP, Igor, SCHWEIGHOFER, Markus: Sums of hermitian
% squares and the BMV conjecture, J. Stat. Phys., 2008, vol. 133, pp.
% 739-760 for details.
%
% arguments:
% m and k are non-negative integers
%
% output:
% V1, V2, V3 are lists of corresponding monomials
%
% possible usage: BMVsets(m,k)
%
% see also: BMVq, NCcycSos
%
%% Call: [V1,V2,V3]=BMVsets(m,k)

modd=mod(m,2);
kodd=mod(k,2);

if modd && ~kodd
    P=[(m-k-1)/2 k/2];
    V1=constructBMV_V(P,2,'x');
    V2={};
    V3={};
elseif modd && kodd
    P=[(m-k)/2 (k-1)/2];
    V1=constructBMV_V(P,2,'y');
    V2={};
    V3={};
elseif ~modd && kodd
    P=[(m-k-1)/2 (k-1)/2];
    V1=constructBMV_V(P,2,'x','y');
    V2={};
    V3={};
%both even
else
    P=[(m-k)/2 k/2];
    V1=constructBMV_V(P,2);
    Px=[(m-k-2)/2 k/2];
    V2=constructBMV_V(Px,2,'x','x');
    Py=[(m-k)/2 (k-2)/2];
    V3=constructBMV_V(Py,2,'y','y');
end



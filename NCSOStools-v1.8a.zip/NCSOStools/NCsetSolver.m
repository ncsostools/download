function solver=NCsetSolver(solvername)

% NCsetSolver
%
% description: NCsetSolver(solvername) sets the solver to be used for SDP in
% NCsos, NCmin, NCdiff, NCisConvex0, NCcycSos, NCcycMin, NCisCycConvex, ...
% and overrides the value set in the global option file NCparam.m.
% NCsetSolver, when called with no arguments returns the current solver.
% 
% arguments: no arguments or a string for SDP solver (currently SeDuMi,
% SDPA-M and SDPT3 are supported)
% 
% output: new or current solver
% 
% possible usage: NCsetSolver, NCsetSolver(solvername)
%
% examples:
% >> NCsetSolver('sedumi')
% >> NCsetSolver('sdpa')
% >> NCsetSolver('sdpt3')
% >> NCsetSolver('sdpt3-v3')
%
% see also: NCresetSolver, NCSos, NCmin, NCdiff, NCcycSos, NCcycMin,
% NCisConvex0, NCisCycConvex

% last modified: 7. 4. 2010 KC
% last : 14.3.2018 KC, nargchk -> narginchk

%error(nargchk(0,1,nargin));
narginchk(0,1);


global NC_active_solver

if nargin==0
	NCparam;
	solver=NC_active_solver;
else
	if isa(solvername,'char')
        switch lower(solvername)
            case 'sedumi'
                solver='SeDuMi';
                NC_active_solver=solver;
            case {'sdpa', 'sdpa-m'}
                solver='SDPA';
                NC_active_solver=solver;
                fprintf('\nRemark: A version with sedumiwrap in path is needed.\n');
            case 'sdpt3'
                solver='SDPT3';
                NC_active_solver=solver;
                fprintf('\nRemark: Version 4 of SDPT3 was selected.\n');
                fprintf('If you experience any problems, please read sdpt3_warning.txt in the NCSOStools directory.\n');
                % fprintf('Remark2: If you want to use version 3, type NCsetSolver(''SDPT3-v3'').');
            case 'sdpt3-v3'
                solver='SDPT3-v3';
                NC_active_solver=solver;
            otherwise
                fprintf('\n''%s'' is not implemented yet. Currently the options are SeDuMi, SDPA or SDPT3 (version 3 and 4).',solvername);
                solver=NC_active_solver;
        end
	else
		error('ERROR: Solvername must be a string representing name of the solver.');
	end
end

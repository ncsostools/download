function [iscConvex,g,sohs,h] = NCisCycConvex(f,precision)

% NCisCycConvex
%
% description: [iscConvex,g,sohs,h] = NCisCycConvex(f,precision) checks if
% the second directional derivative of a polynomial is cyclically
% equivalent to a sum of hermitian squares.
% 
% arguments:
% f is an NCpoly representing a polynomial.
% With precision we can set the smallest value that is considered to be
% nonzero in numerical calculations; if the command is called without it,
% we assume the precision set with the command NCsetPrecision or the value
% set in NCparam.m.
%
% output:
% iscConvex equals 1 if the second directional derivative of a polynomial f
%    is cyclically equivalent to a sum of hermitian squares and 0 otherwise
% g is an NCpoly representing the second derivative of the polynomial f
% sohs is the SOHS decomposition of the polynomial cyclically equivalent to
%    the second derivative of the polynomial f
% h is the NCpoly representing sum_i m_i^*m_i cyclically equivalent to the
%    second derivative of the polynomial f
% 
% possible usage: NCisCycConvex(f), NCisCycConvex(f,precision)
%
% see also: NCcycSos, NCcycMin, NCisCycEq, NCcycEqRep, NC2d, NCisConvex,
% NCisConvex0

% last modified: 20. 2. 2009 KC
% last : 14.3.2018 KC, nargchk -> narginchk

%error(nargchk(1,2,nargin));
narginchk(1,2);


poly=NCpoly(f);

if nargin == 1  %default call
    NCparam;
    precision = NC_numeric_precision;
end

g = NC2d(poly);

params.precision=precision;
params.messages=0;

[iscConvex,X,base,sohs,h] = NCcycSos(g,params);


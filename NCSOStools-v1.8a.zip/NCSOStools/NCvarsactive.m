function c=NCvarsactive(varargin)

w = evalin('base','whos');
k = strmatch('NCvariable',char({w.class,''}));
c={w(k).name};

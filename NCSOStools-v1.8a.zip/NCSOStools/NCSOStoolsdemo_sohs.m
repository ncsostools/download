clc
echo on

%**************************************************************************
% Sum of hermitian squares (SOHS) related                                 *
%**************************************************************************
%
% -------------------------------------------------------------------------
% First we construct some symbolic noncommuting variables and some
% polynomials
% -------------------------------------------------------------------------
NCvars x y z
f = y*x^2*y - y*x*z + 4*y*z^2*y - z*x*y + z^2;
g = 2*x + 2*x^2 + x*y + 2*y + y*x + y^2;
h = x^2 + x*y + y*x + 2*y^2 + z^2 - 1;
pause % Strike any key to continue. 

% -------------------------------------------------------------------------
% We can check whether the polynomial is a sum of hermitian squares and
% compute the desired decomposition.
% -------------------------------------------------------------------------
pause % Strike any key to continue. 

[IsSohs,X,base,sohs,fsos] = NCsos(f)
pause % Strike any key to continue. 

% -------------------------------------------------------------------------
% NCsos has many optional parameters. For example we can set the smallest
% value that is considered to be nonzero in numerical calculations.
% -------------------------------------------------------------------------
pause % Strike any key to continue. 

params.precision = 1e-4;
[IsSohs,X,base,sohs,fsos] = NCsos(f,params)
pause % Strike any key to continue. 

clc
% -------------------------------------------------------------------------
% We can also computes the maximal epsilon such that the polynomial
% g-epsilon is a sum of hermitian squares.
% -------------------------------------------------------------------------
pause % Strike any key to continue. 

g
[epsilon,X,base,sohs,gmin] = NCmin(g)
pause % Strike any key to continue. 

% -------------------------------------------------------------------------
% NCmin has many optional parameters. For example we can set the smallest
% value that is considered to be nonzero in numerical calculations.
% -------------------------------------------------------------------------
pause % Strike any key to continue. 

params.precision = 1e-4;
[epsilon,X,base,sohs,gmin] = NCmin(g,params)
pause % Strike any key to continue. 

clc
% -------------------------------------------------------------------------
% For given polynomials f and g we can compute the maximal epsilon such
% that the polynomial f-epsilon*g is a sum of hermitian squares.
% -------------------------------------------------------------------------
pause % Strike any key to continue. 

[epsilon,X,base,sohs,poly] = NCdiff(x^2-x^2*y-y*x^2+y*x^2*y+4*y^2,x*y+y*x-2*y*x*y)
pause % Strike any key to continue. 

clc
% -------------------------------------------------------------------------
% We can check if the polynomial is convex, i.e., if its second directional
% derivative is a sum of hermitian squares.
% -------------------------------------------------------------------------
pause % Strike any key to continue. 

g
[isConvex,g,sohs] = NCisConvex0(g)
pause % Strike any key to continue. 

% -------------------------------------------------------------------------
% We can also check if the polynomial is convex without SDP solvers
% -------------------------------------------------------------------------
isConvex = NCisConvex(g)

pause % Strike any key to end this demonstration. 
echo off
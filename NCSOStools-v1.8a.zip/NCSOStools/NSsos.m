function [IsSohs,Gr,base,sohs,g,SDP_data,L] = NSsos(f,params)

% NSsos
%
% description: [IsSohs,Gr,base,sohs,g,SDP_data,L] = NSsos(f,params) checks
% whether the polynomial f is a sum of hermitian squares.
%
% arguments:
% f is an NSpoly representing a polynomial.
% With params.precision we can set the smallest value that is considered to
%    be nonzero in numerical calculations; if the command is called without
%    it, we assume the precision set with the command NCsetPrecision or the
%    value set in NCparam.m.
% params.messages is used to optionally turn on (1) and off (0) verbose
%    output; default value is 1 (on).
% params.solver sets the solver to be used for SDP and overrides the value
%    set in the global option file NCparam.m. (currently SeDuMi, SDPA-M or
%    SDPT3 are supported)  
% params.eps sets the desired accuracy iy you are using SeDuMi as SDP
%    solver. Setting params.eps = 0 lets SeDuMi run as long as it can make
%    progress.
% params.V is a column of monomials to be used as a basis in the SOHS
%    decomposition. It is optional; if the command is called without it, it
%    is constructed automatically.
% params.obj set the objective function C for SDP solver. If it equals 0 C
%    is square matrix of zeros (finding analytical center) and if it equals
%    to 1 C is the identity matrix (minimizing rank). Default is 1.
% params.justSDP_data==1 means that the program ends when the SDP_data is
%    prepared and nothing else is computed. It is optional; the default
%    value is 0.
% params.decomposition==0 means that no SOHS decomposition will actually
%    be computed. It is optional; the default value is 1.
% 
% output:
% IsSohs equals 1 if the polynomial f is a sum of hermitian squares and
%    0 otherwise.
% Gr is the Gram matrix solution of the corresponding SDP returned by the
%    solver.
% base is a list of monomials which appear in the SOHS decomposition.
% sohs is the SOHS decomposition of the polynomial f
% g is the NSpoly representing sum_i m_i^*m_i
% SDP_data is a structure holding all the data used in SDP solver
% L is the operator representing the dual optimization problem (L ... the
%    dual feasible SDP matrix)
%
% possible usage: NSsos(f), NSsos(f,params)
%
% see also: 
%
%% Call: [IsSohs,Gr,base,sohs,g,SDP_data,L] = NSsos(f,params)

% last modified: 11. 12. 2014 KC
% last: 15. 12. 2014 KC: X -> Gr
% last: 14.3.2018, KC, complex
% last: 14.3.2018 KC, nargchk -> narginchk

%error(nargchk(1,2,nargin));
narginchk(1,2);

poly = NSpoly(f);

IsSohs = 1;
sohs = [];
base = [];
Gr = [];
g = '';
SDP_data = [];
L = [];

pars_sdp = '';
CforSDP = 1;
justSDP_data = 0;
decomposition = 1;

error_warn = 0;

if nargin==1  % default call
    NCparam;
    precision = NC_numeric_precision;
    messages = true;
elseif nargin==2  % default call

    if isfield(params,'messages') && ~isempty(params.messages)
        if params.messages~=true && params.messages~=false
            error('ERROR: .messages must be logical true/false.');
        end
        messages = params.messages;
    else
        messages = true;
    end

    if isfield(params,'precision') && ~isempty(params.precision)
        if ~isnumeric(params.precision)
            error('ERROR: .precision must be a numerical value.');
        end
        precision = params.precision;
    else
        NCparam;
        precision = NC_numeric_precision;
    end
    
    if isfield(params,'solver') && ~isempty(params.solver)
        pars_sdp.solver = params.solver;
    end
    
    if isfield(params,'eps') && ~isempty(params.eps)
        if ~isnumeric(params.eps)
            error('ERROR: .eps must be a numerical value.');
        end
        pars_sdp.eps = params.eps;
    end

    if isfield(params,'obj') && ~isempty(params.obj)
        if (params.obj==0 || params.obj==1)
            CforSDP = params.obj;
        else
            error('ERROR: .obj must be 0 or 1.');
        end
    end

    if isfield(params,'V') && ~isempty(params.V)
        if ~iscell(params.V)
            error('ERROR: .V must be a cell.');
        end
        base = params.V;
    end
    
    if isfield(params,'justSDP_data') && ~isempty(params.justSDP_data)
        if (params.justSDP_data==1 || params.justSDP_data==true)
            justSDP_data = 1;
        end
    end

    if isfield(params,'decomposition') && ~isempty(params.decomposition)
        if (params.decomposition==0 || params.decomposition==false)
            decomposition = 0;
        end
    end

end

if messages
    fprintf('\n***** NCsostools: module NSsos started *****\n\n');
end

var = NSvarsactive();


[A,b,C,base,deg,info] = NSprepare_data(poly,var,0,messages,base);  % prepares SDP data for the problem
if info<1
    IsSohs = 0;
    return;
end
if info==2
    IsSohs = 1;
    base = {''};
    sohs = poly;
    structpoly = struct(poly);
    koef = structpoly.koef;
    Gr = koef;
    g = poly;
    L = [];
    return;
end

if CforSDP==1
    C = eye(size(C));
elseif CforSDP==0
    C = zeros(size(C));
else
    error('ERROR: Unsupported objective function for SDP solver.');
end

len_base = length(base);
if size(C,1)==1 && length(b)==1
	IsSohs = b(1)>0;
    if IsSohs
        Gr = b(1);
        NCparam;
        simple = NC_using_exponents;
        sohs = factor2NSpoly(sqrt(b(1)),base,simple,abs(log10(precision)));
        g = sohs'*sohs;
    end
	return;
end

if messages
    pars_sdp.messages = 1;
else
    pars_sdp.messages = 0;
end

% for complex:
IS_complex = ~isreal(b);
if (IS_complex)
    K.scomplex = 1;
    K.ycomplex = [1:length(b)];
end

K.s = size(C,1);
K.f = 0;

C = C(:);
SDP_data.A = A;
SDP_data.b = b;
SDP_data.C = C;
SDP_data.K = K;
SDP_data.pars = pars_sdp;

if justSDP_data
    if messages
        fprintf('\n***** Program is quiting because of the .justSDP_data==1 switch! *****\n');
        fprintf('***** Just the data for the SDP was returned.                      *****\n');
    end
    return;
end

[XX,Y,INFO] = solveSDP(A,b,C,K,pars_sdp);
SDP_data.INFO = INFO;

if messages
    disp([' ']);
    disp(['Residual norm: ' num2str(norm(A*XX-b))]);
    disp([' ']);
    disp(INFO);
end

if INFO.pinf==1 || INFO.dinf==1
    if messages
        fprintf('\n***** Polynomial has NO SOHS decomposition: primal SDP is INFEASIBLE. *****\n');
    end
    IsSohs = 0;
    return;
end

if INFO.numerr<0
    fprintf('***** ALERT: SDPT3 ran into numerical problems.        *****\n');
%     fprintf('***** Press any key to continue with the last data ... *****\n');
%     if messages
        fprintf('***** Polynomial MIGHT have NO SOHS decomposition.     *****\n');
%     end
    error_warn = 1;
%     pause;
elseif INFO.numerr==1
    if abs(INFO.feasratio-1)>1e-1
        fprintf('***** ALERT: SeDuMi ran into minor numerical problems.                    *****\n');
%         fprintf('***** Press any key to continue with the last data ...                    *****\n');
%         if messages
            if INFO.feasratio<0.2
                fprintf('***** According to feasratio polynomial MIGHT have NO SOHS decomposition. *****\n');
            elseif INFO.feasratio>0.8
                fprintf('***** Nevertheless, according to feasratio given solution MIGHT be ok.    *****\n');
            else
                fprintf('***** Given solution might be wrong.                                      *****\n');
            end
%         end
        error_warn = 1;
%         pause;
    end
elseif INFO.numerr==2
    fprintf('***** ALERT: SeDuMi ran into SERIOUS numerical problems. *****\n');
    fprintf('***** Press any key to continue with the last data ...   *****\n');
%     if messages
        fprintf('***** Given solution is therefore presumably wrong.      *****\n');
%     end
    pause;
end

if nargout>1
    Gr = reshape(XX,len_base,len_base);
    if nargout>3
        if decomposition
            if messages
                fprintf('Computing SOHS decomposition ... ');
            end
            G = cholPSD(Gr);
            GG = round(G/precision)*precision;
            sohs = NSpoly(0);
            count = 1;
            for i = 1:size(G,1)
                if max(abs(GG(i,:)))>0

                    NCparam;
                    simple = NC_using_exponents;
                    fact = factor2NSpoly(GG(i,:),base,simple,abs(log10(precision)));

                    sohs(count,1) = fact;
                    count = count+1;
                end
            end
            
            if nargout>4
            	g = sohs'*sohs;
            end
            
            if messages
                fprintf('done.\n');
                fprintf('Found SOHS decomposition with %d factors.\n',length(sohs));
            end
        elseif messages
            fprintf('\n***** No SOHS decomposition was computed because of the .decomposition==0 switch! *****\n');
        end

        if nargout>6
            % we extract from the dual solution the dual operator L, optimal solution of
            % inf L(f) s.t. L maps R<Gr>_2d to R, L(1) = 1, L(\Theta^2)\ge 0
            L = reshape(C-A'*Y,len_base,len_base);
            % if L(1,1)>1e-5
                L = L/L(1,1);
            % end
        end
    end
end

if error_warn
    fprintf('\nWARNING! SDP solver returned some numerical problems. Check messages!\n');
end

if IsSohs && messages
    fprintf('\n*************** Polynomial is SOHS ***************\n');
end

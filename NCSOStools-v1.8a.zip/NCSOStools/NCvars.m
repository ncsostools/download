function NCvars(varargin)

% NCvars
%
% description: NCvars(varargin) constructs symbolic noncommuting variables.
% NCvars, when called with no arguments lists the symbolic NCvariable
% objects in the workspace.
%
% arguments: no arguments or strings which are valid variable names (a valid
% variable name is a character string of letters, digits and underscores,
% with length <= namelengthmax, where the first character is a letter, and
% the name is not a keyword)
%
% output: symbolic noncommuting variables
%
% possible usage: NCvars(varargin), NCvars
%
% example: >> NCvars x y z

% last modified: 11. 12. 2008 KC

if nargin < 1
   w = evalin('caller','whos');
   k = strmatch('NCvariable',char({w.class,''}));
   disp(' ')
   disp({w(k).name})
   disp(' ')
   return
end

n = numel(varargin);
for k = 1:n
   if ~isvarname(varargin{k})
      error('Not a valid variable name ''%s''.', varargin{k})
   end
end
for k = 1:n
   x = varargin{k};
   assignin('caller',x,NCvariable(x));
   %assignin('base',x,NCvariable(x));
end

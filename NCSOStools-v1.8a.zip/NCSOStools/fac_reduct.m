function [X,SDP_orig]=fac_reduct(f,params)

% fac_reduct
%
% description: [X,SDP_orig]=fac_reduct(f,params) is an interactive routine
% for finding a rational Gram matrix (feasible point) in case of a singular
% feasible point by doing a facial reduction with an integer vector (or set
% of orthogonal integer vectors) from the kernel of the given feasible
% point.
%
% arguments:
% f is an NCpoly representing a polynomial.
% params.V is a column of monomials to be used as a basis in the SOHS
%    decomposition. It is optional; if the command is called without it, it
%    is constructed automatically.
% params.Vmethod sets the method to get the vector of possible monomials.
%    If it equals -1, the program uses the flawed Newton Cyclic Chip Method 
%    to get the vector of possible monomials and if it equals 0, the
%    program constructs all posible monomials from the Newton polytope
%    using alpha degrees. Default value is chosen in NCcycSos.
% params.obj set the objective function C for the SDP solver. If it equals
%    0, C is a square matrix of zeros (finding the analytic center) and if
%    it equals 1, C is the identity matrix (minimizing rank). Default is 0.
% 
% output:
% X is a Gram matrix. If rationalizing was done in the routine X is a
%    rational feasible point represented by a cell of two matrices;
%    numerators and denominators. If rationalizing was not done X is
%    floating point feasible point as a matrix.
% SDP_orig is a structure holding all the data used in the original SDP
%
% possible usage: fac_reduct(f), fac_reduct(f, params)
%
% see also: RProjRldlt, NCcycSos
%
%% Call: [X,SDP_orig]=fac_reduct(f,params)

% last modified 2009-12-22 by J.P.
% last modified 18. 4. 2010 by K.C. (option for not to rationalize)
% last modified 27. 9. 2010 by K.C. (params)
% last modified 19. 9. 2011 by K.C. (v -> z, G0)
% last modified: 14.3.2018 KC, nargchk -> narginchk

%error(nargchk(1,2,nargin));
narginchk(1,2);

fprintf('\n***** NCSOStools: module fac_reduct started *****\n\n');

if nargin == 1  % default call
    % analytical center
    params2.obj=0;
elseif nargin == 2  % default call
    if isfield(params,'V') && ~isempty(params.V)
        params2.V=params.V;
    end
    if isfield(params,'Vmethod') && ~isempty(params.Vmethod)
        params2.Vmethod=params.Vmethod;
    end
    if isfield(params,'obj') && ~isempty(params.obj)
        params2.obj=params.obj;
    else
        params2.obj=0;
    end
end

X=[];
SDP_orig=[];

[IsCycEq,X,base,sohs,g,do_not_touch_SDP_data] = NCcycSos(f,params2);

if isempty(X)
    fprintf('\n***** NCSOStools: module fac_reduct ended *****\n\n');
    return;
end

do_not_touch_SDP_data.A=do_not_touch_SDP_data.A;
do_not_touch_SDP_data.b=do_not_touch_SDP_data.b;

SDP_orig = do_not_touch_SDP_data;
stop=0;
do_not_touch_V={};
do_not_touch_X=X;

rationalize=1;
while stop==0
    G0=do_not_touch_X;
    fprintf('\nDefine z as a set of orthogonal integer vectors from the kernel of G0.\n');
    fprintf('If you can not find any null vector or you want to stop, type stop=1.\n');
    fprintf('If you do not want to rationalize, type rationalize=0.\n');
    fprintf('The interactive mode is terminated by executing the command RETURN.\n');
    z=[];
    keyboard;

    if size(z,1)~=size(do_not_touch_X,1) && size(z,2)==size(do_not_touch_X,1)
        z=z';
    end
    
    if isempty(z)
        if stop~=1
            fprintf('\nYou did not set z. Please try again.\n');
        end
    elseif size(z,1)~=size(do_not_touch_X,1)
        fprintf('\nNumber of rows in G0 and z do not match. Please try again.\n');
    else
        [do_not_touch_SDP_data, X, do_not_touch_V]=NCpostSolve(do_not_touch_SDP_data,do_not_touch_X,z,do_not_touch_V);
        do_not_touch_X=X;
    end
end


if rationalize~=0
    [SDP_data.A,SDP_data.b]=gs(do_not_touch_SDP_data.A,do_not_touch_SDP_data.b);

    Xrat=RprojRldlt(X,SDP_data,false);

    V=do_not_touch_V;

    % samo nerac test - brisi
    % X=Xrat{1}./Xrat{2};
    % n_x=size(X,1);

    X=Xrat;
    n_x=size(X{1},1);

    for i=1:length(V)
        n_v=size(V{i},1);

        % samo nerac test - brisi
        % X = [zeros(n_v-n_x,n_v);zeros(n_x,n_v-n_x) X];
        % X = V{i}*X*V{i}';
        X = {[zeros(n_v-n_x,n_v);zeros(n_x,n_v-n_x) X{1}],[ones(n_v-n_x,n_v);ones(n_x,n_v-n_x) X{2}]};
        try
            X = Rtimes(Rtimes({V{i},ones(size(V{i}))},X),{V{i}',ones(size(V{i}))});
        catch
            fprintf('\n***** ERROR: *****\n');
            fprintf('Rational multiplication failed because of too large numbers.\n');
        end

        n_x=n_v;
    end
end

fprintf('\n***** NCSOStools: module fac_reduct ended *****\n\n');

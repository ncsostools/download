% NCSOStools v1.8a (release date 14 Mar 2018)
%
% Variables
%   NCvars           - constructs symbolic noncommuting (symmetric) variables
%   NSvars           - constructs symbolic noncommuting (nonsymmetric) variables
%
% Toolbox for symbolic computation with polynomials in noncommuting variables 
%   plus             - f+g, symbolic addition
%   minus            - f-g, symbolic subtraction
%   uminus           - -f, symbolic negation
%   times            - f.*g, symbolic element-by-element multiplication
%   power            - f.^n, element-by-element powers
%   prod             - product of the elements
%   sum              - sum of the elements
%   mtimes           - f*g, symbolic matrix multiplication
%   mpower           - f^n, symbolic matrix power
%   transpose        - f.', symbolic matrix transpose
%   ctranspose       - f', involution
%   hs               - f'*f, hermitian square
%   NCcom            - f*g-g*f, comutator
%   diag             - diagonal matrices and diagonals of a matrix
%   tril             - lower triangular part
%   triu             - upper triangular part
%   trace            - trace (the sum of the diagonal elements)
%   horzcat          - [ , ], horizontal concatenation of matrices
%   vertcat          - [ ; ], vertical concatenation of matrices
%   eq               - f==g, element by element symbolic equality test
%   ne               - f~=g, element by element symbolic inequality test
%   isequal          - symbolic equality test
%   NCsimplify       - writing monomials in NCpoly shortly using exponents
%   NSsimplify       - writing monomials in NSpoly shortly using exponents
%   NCexpand         - writing monomials in NCpoly in expanded form without
%                      using exponents
%   NSexpand         - writing monomials in NSpoly in expanded form without
%                      using exponents
%   NCeval           - symbolic evaluation and substitution of NCpoly
%   NSeval           - symbolic evaluation and substitution of NSpoly
%   NCclean          - eliminating small coefficients in NCpoly
%   NSclean          - eliminating small coefficients in NSpoly
%   char             - converting to its string representation
%   xlswrite         - stores matrix of NC polys in Excel workbook
%
% Sum of hermitian squares (SOHS) related
%   NCsos            - checks whether NC polynomial is a SOHS
%   NSsos            - checks whether NS polynomial is a SOHS
%   NCmin            - computes the maximal epsilon such that the
%                      NC polynomial f-epsilon is a SOHS
%   NCdiff           - computes the maximal epsilon such that the
%                      NC polynomial f-epsilon*g is a SOHS
%   NC2d             - computes the second derivative of NC polynomial
%   NCisConvex0      - checks if NC polynomial is convex, i.e., if its
%                      second directional derivative is a SOHS
%   NCisConvex       - checks if NC polynomial is convex (algorithm without
%                      SDP solvers)
%   NCopt            - computes minimizers and the minimum of NC polynomial
%   GNS              - prepares a matrix X for the AWbd function by doing
%                      Gelfand-Naimark-Segal construction 
%   AWbd             - numerical algorithm for the Artin-Wedderburn
%                      block-diagonal decomposition of matrix *-algebras
%   NCminBall        - computes the minimum opt of NC polynomial on an nc
%                      ball 
%   NCoptBall        - computes minimizers and the minimum of NC polynomial
%                      on an nc ball
%   NCminCube        - computes the minimum opt of NC polynomial on an nc
%                      polydisc
%   NCoptCube        - computes minimizers and the minimum of NC polynomial
%                      on an nc polydisc
%   NCeigMin         - computes the lower bound for the minimum eigenvalue
%                      of NC polynomial subject to constraints S 
%   NCeigOpt         - computes minimizers and the minimum eigenvalue
%                      of NC polynomial subject to constraints S 
%   NCeigOptRand     - computes minimizers and the minimum eigenvalue
%                      of NC polynomial subject to constraints S using
%                      randomization
%
% Cyclic equivalence and SOHS
%   NCisCycEq        - checks whether two NC polynomials are cyclically
%                      equivalent (i.e., whether their difference is a sum
%                      of commutators)
%   NCcycEqRep       - constructs a canonical cyclically equivalent
%                      representative of NC polynomial 
%   NCcycSos         - checks whether NC polynomial is cyclically equivalent
%                      to a SOHS
%   NCcycMin         - computes the maximal epsilon such that NC polynomial
%                      f-epsilon is cyclically equivalent to a SOHS
%   NCisCycConvex    - checks if the second directional derivative of NC
%                      polynomial is cyclically equivalent to a SOHS
%   NCcycOpt         - computes trace minimizers and trace minimum of NC
%                      polynomial whenever the corresponding tracial moment
%                      matrix is flat
%   NCFlatExt        - checks whether the extension of dual moment matrices
%                      of NC polynomial is flat 
%   GNS              - prepares a matrix X for the AWbd function by doing
%                      Gelfand-Naimark-Segal construction 
%   AWbd             - numerical algorithm for the Artin-Wedderburn
%                      block-diagonal decomposition of matrix *-algebras
%   NCtraceMin       - computes the lower bound for the minimum of the
%                      trace of NC polynomial subject to constraints S
%   NCtraceOptRand   - computes minimizers and the minimum of the trace
%                      of NC polynomial subject to constraints S using
%                      randomization
%
% Rationalization
%   RprojRldlt       - tries to find an exact rational positive
%                      semidefinite solution of the SDP: X PsD, A*X=b from
%                      a floating point solution
%   fac_reduct       - an interactive routine for finding a rational Gram
%                      matrix (feasible point) in case of singular feasible
%                      point with the aid of facial reduction 
%
% BMV conjecture
%   BMV              - constructs the (m,k) BMV polynomial with x and y as
%                      arguments
%   BMVq             - constructs the (m,k) BMV polynomial with x^2 and y^2
%                      as arguments (for modelling psd matrices)
%   BMVsets          - constructs the reduced monomial basis needed for the
%                      Gram matrix of (m,k) BMV polynomial with x^2 and y^2
%                      as arguments
%
% Settings
%   NCsetPrecision   - sets the precision to be used in some numerical
%                      calculations
%   NCresetPrecision - resets the precision to the value set in NCparam.m
%   NCsetSolver      - sets the solver to be used for SDP (SeDuMi, SDPA-M,
%                      SDPT3) 
%   NCresetSolver    - resets the choice of SDP solver to the value set in
%                      NCparam.m
%
% See also
%   NCSOStoolsdemo   - Demonstration (brief tutorial and examples)
%
% 
% Latest release and bug reports: http://ncsostools.fis.unm.si
%

function c=NSvarsactive(varargin)

w = evalin('base','whos');
k = strmatch('NSvariable',char({w.class,''}));
c={w(k).name};

function [opt,X,base,sohs,g,SDP_data,L] = NCcycMin(f,params)

% NCcycMin
%
% description: [opt,X,base,sohs,g,SDP_data,L] = NCcycMin(f,params) computes
% the maximal epsilon such that f-epsilon is cyclically equivalent to a sum
% of hermitian squares.
% 
% arguments:
% f is an NCpoly representing a polynomial. 
% With params.precision we can set the smallest value that is considered to
%    be nonzero in numerical calculations; if the command is called without
%    it, we assume the precision set with the command NCsetPrecision or the
%    value set in NCparam.m.
% params.messages is used to optionally turn on (1) and off (0) verbose
%    output; default value is 1 (on).
% params.solver sets the solver to be used for SDP and overrides the value
%    set in the global option file NCparam.m. (currently SeDuMi, SDPA-M or
%    SDPT3 are supported)  
% params.eps sets the desired accuracy iy you are using SeDuMi as SDP
%    solver. Setting params.eps=0 lets SeDuMi run as long as it makes
%    progress.
% params.V is a column of monomials to be used as a basis in the SOHS
%    decomposition. It is optional; if the command is called without it, it
%    is constructed automatically.
% params.Vmethod sets the method to get the vector of possible monomials.
%    If it equals -1 then we create V by the flawed Newton Cyclic Chip
%    Method: we take all cyclic permutations of monomials of even dergee
%    and for each of those equivalents which are herm. squares we take all
%    right chips. This is valid only if support of f is the same as support
%    of SOHS, which is cyc. eq. to f.
%    If it equals 0 we create V using alpha degree idea and the Newton
%    polytope (this is the default value).
%    If it equals 1 we create V checking whether the dual moment matrix
%    allows flat extensions: we generate all possible monomials with
%    degree <= d.
% params.justSDP_data == 1 means that the program ends when the SDP_data is
%    prepared and nothing else is computed. It is optional; the default
%    value is 0.
% params.decomposition == 0 means that no SOHS decomposition will actually
%    be computed. It is optional; the default value is 1.
% 
% output:
% opt is the maximal epsilon making f-epsilon cyclically equivalent to a
%    sum of hermitian squares, 
% X is the Gram matrix solution of the corresponding SDP returned by the
%    solver.
% base is a vector of monomials appearing in the SOHS decomposition of the
%    polynomial cyclically equivalent to the f-epsilon 
% sohs is the SOHS decomposition of the polynomial cyclically equivalent to
%    the f-epsilon
% g is the NCpoly representing SOHS decomposition of the polynomial
%    cyclically equivalent to the f-epsilon
% SDP_data is a structure holding all the data used in SDP solver
% L is the operator representing the dual optimization problem (L ... the
%    dual feasible SDP matrix)
%
% possible usage: NCcycMin(f), NCcycMin(f,params)
%
% see also: NCcycSos, NCSos, NCmin, NCsetPrecision, NCsetSolver, NCisCycEq,
% NCcycEqRep, NCisCycConvex, NCisConvex, NCisConvex0, RProjRldlt, NCcycOpt
%
%% Call: [opt,X,base,sohs,g,SDP_data,L] = NCcycMin(f,params)

% created: 4. 2. 2009 by J. Povh
% modified: 16. 3. 2010 JP (added extraction of dual operator L)
% last modified: 19. 3. 2010 by JP: V is generated as in NCcycSos (run on
% f+1)
% change: 9. 5. 2010 KC: sum(sum(deg)~=0) changed to sum(sum(deg,1)~=0) ... bug if only one monomial
% change: 10.5.2010 KC: counting of monomials in 0 or 1 variable 
% last: 6. 6. 2010 KC
% last modified: 14.3.2018 KC, nargchk -> narginchk

%error(nargchk(1,2,nargin));
narginchk(1,2);

f=NCpoly(f);
f_orig=f;
justSDP_data=0;
decomposition=1;

opt=[];
X=[];
sohs=[];
g='';
SDP_data=[];
L=[];
lastenV=false;

error_warn=0;

f_monom=struct(f).monom;
f_coef = struct(f).koef;
f_const=0;
for i=1:size(f_monom,1)
    if isempty(f_monom{i})
        f_const=f_coef(i);
        break;
    end
end
Delta = 0;
if ~f_const % the const. part of f is 0, hence we add 1
    Delta = 1;
    f = f + Delta;
end  

post_do=0;

if nargin == 1  % default call
    NCparam;
    precision = NC_numeric_precision;
    messages=true;
    chip_method = 0;
    post_do=1;
elseif nargin == 2  % default call

    if isfield(params,'messages') && ~isempty(params.messages)
        if params.messages~=true && params.messages~=false
            error('ERROR: .messages must be logical true/false.');
        end
        messages=params.messages;
    else
        messages=true;
    end

    if isfield(params,'precision') && ~isempty(params.precision)
        if ~isnumeric(params.precision)
            error('ERROR: .precision must be a numerical value.');
        end
        precision = params.precision;
    else
        NCparam;
        precision = NC_numeric_precision;
    end
    
    if isfield(params,'solver') && ~isempty(params.solver)
        pars_sdp.solver = params.solver;
    end
    
    if isfield(params,'eps') && ~isempty(params.eps)
        if ~isnumeric(params.eps)
            error('ERROR: .eps must be a numerical value.');
        end
        pars_sdp.eps = params.eps;
    end

    if isfield(params,'V') && ~isempty(params.V)
        if ~iscell(params.V)
            error('ERROR: .V must be a cell.');
        end
        V=params.V;
        lastenV=true;
        base=V;
        % razmisli, ce potrebujes tudi novi f ali lahko klices zgolj prerep
        % za ekv_mon_f
        % Op: rabis pri izpisu, kaj delas - da poves, koliko je manjsi V
        post_do=2;
        errorV=false;
    else
        chip_method=0;
        if isfield(params,'Vmethod') && ~isempty(params.Vmethod)
            if (params.Vmethod==-1 || params.Vmethod==0 || params.Vmethod==1) 
                chip_method = params.Vmethod;
            else
                error('ERROR: .Vmethod must be -1, 0 or 1.');
            end
        end

        if chip_method == 1
            post_do=3;
        else
            post_do=4;
        end
    end
    
    if isfield(params,'justSDP_data') && ~isempty(params.justSDP_data)
        if (params.justSDP_data==1 || params.justSDP_data==true)
            justSDP_data=1;
        end
    end

    if isfield(params,'decomposition') && ~isempty(params.decomposition)
        if (params.decomposition==0 || params.decomposition==false)
            decomposition=0;
        end
    end

end 

if messages
    fprintf('\n***** NCSOStools: module NCcycMin started *****\n\n');

    deg = compute_deg(f_orig);
    structpoly=struct(f_orig);
    monom=structpoly.monom;
    len_m=length(monom);

    len_mon=sum(deg,2);  % contains lengths of monomials
    deg_max=max(len_mon);   % max degree of polynomial
    deg_min=min(len_mon);  % min degree of polynomial

    fprintf('Input polynomial has (max) degree %d and min degree %d.\n',deg_max,deg_min);
    tmp_num_var=sum(sum(deg,1)~=0);

    fprintf('Detected %d monomial',len_m);
    if len_m>1
        fprintf('s');
    end
    fprintf(' in %d variable',tmp_num_var);
    if tmp_num_var>1 || tmp_num_var==0
        fprintf('s');
    end
    fprintf('.\n');

    if tmp_num_var == 0
    	tmp_num_all_mon = 1;
    	tmp_num_minmax_mon = 1;
    elseif tmp_num_var == 1
    	tmp_num_all_mon = deg_max+1;
    	tmp_num_minmax_mon = deg_max-deg_min+1;
    else
		tmp_num_all_mon=(tmp_num_var^(deg_max+1)-1)/(tmp_num_var-1);
		tmp_num_minmax_mon=(tmp_num_var^(deg_max+1)-tmp_num_var^deg_min)/(tmp_num_var-1);
	end	

    fprintf('There are %d monomial',tmp_num_all_mon);
    if tmp_num_all_mon>1
        fprintf('s');
    end
    fprintf(' in %d variable',tmp_num_var);
    if tmp_num_var>1 || tmp_num_var==0
        fprintf('s');
    end
    fprintf(' of degree at most %d.\n',deg_max);

    if deg_min>0
        fprintf('There are %d monomial',tmp_num_minmax_mon);
        if tmp_num_minmax_mon>1
            fprintf('s');
        end
        fprintf(' in %d variable',tmp_num_var);
        if tmp_num_var>1 || tmp_num_var==0
            fprintf('s');
        end
        if deg_max~=deg_min
            fprintf(' of degree at most %d and at least %d.\n',deg_max,deg_min);
        else
            fprintf(' of degree exactly %d.\n',deg_max);
        end
    end

    fprintf('\nPreprocessing the input polynomial ...\n');
end

if post_do>0
    switch post_do
        case 1
            [V,ekv_mon_f,errorV,f]=NCM_cyc(f,messages,chip_method);
            base=V;
        case 2
            [f,ekv_mon_f]=NCcycEqRep(f);
        case 3
            [V,ekv_mon_f,errorV,f]=construct_V_min(f,messages);
            base=V;
        case 4
            [V,ekv_mon_f,errorV,f]=NCM_cyc(f,messages,chip_method);
            base=V;
    end
end


if errorV
    fprintf('\n***** Polynomial has no such lower bound: SDP is infeasible. *****\n');
    return;
end


structpoly=struct(f);
monoms_f=structpoly.monom;
koefs_f=structpoly.koef;
if length(monoms_f) == 1 && isempty(monoms_f{1})
    opt=f;
    X=1;
    base={''};
    sohs=0;
    g=0;
    L=1;
    return;
end


if messages
    deg = compute_deg(f);
    structpoly=struct(f);
    monom=structpoly.monom;

    len_m2=length(monom);
    if len_m~=len_m2
        len_m=len_m2;

        len_mon=sum(deg,2);  % contains lengths of monomials
        deg_max=max(len_mon);   % max degree of polynomial
        deg_min=min(len_mon);  % min degree of polynomial

        fprintf('\nReturned cyclically equivalent polynomial with (max) degree %d and min degree %d.\n',deg_max,deg_min);
        tmp_num_var=sum(sum(deg,1)~=0);

		fprintf('Detected %d monomial',len_m);
		if len_m>1
			fprintf('s');
		end
		fprintf(' in %d variable',tmp_num_var);
		if tmp_num_var>1 || tmp_num_var==0
			fprintf('s');
		end
		fprintf('.\n');

		if tmp_num_var == 0
			tmp_num_all_mon = 1;
			tmp_num_minmax_mon = 1;
		elseif tmp_num_var == 1
			tmp_num_all_mon = deg_max+1;
			tmp_num_minmax_mon = deg_max-deg_min+1;
		else
			tmp_num_all_mon=(tmp_num_var^(deg_max+1)-1)/(tmp_num_var-1);
			tmp_num_minmax_mon=(tmp_num_var^(deg_max+1)-tmp_num_var^deg_min)/(tmp_num_var-1);
		end	

		fprintf('There are %d monomial',tmp_num_all_mon);
		if tmp_num_all_mon>1
			fprintf('s');
		end
		fprintf(' in %d variable',tmp_num_var);
		if tmp_num_var>1 || tmp_num_var==0
			fprintf('s');
		end
		fprintf(' of degree at most %d.\n',deg_max);

		if deg_min>0
			fprintf('There are %d monomial',tmp_num_minmax_mon);
			if tmp_num_minmax_mon>1
				fprintf('s');
			end
			fprintf(' in %d variable',tmp_num_var);
			if tmp_num_var>1 || tmp_num_var==0
				fprintf('s');
			end
			if deg_max~=deg_min
				fprintf(' of degree at most %d and at least %d.\n',deg_max,deg_min);
			else
				fprintf(' of degree exactly %d.\n',deg_max);
			end
		end
    end
    
    if lastenV
        fprintf('\nUsing user''s monomial vector with %d monomials.\n',length(V));
    else
        fprintf('Constructing monomial vector with %d monomials.\n',length(V));
    end
end


if messages
    fprintf('\nComputing cyclically equivalent products ... ');
end
ekv_mon_v = cycEqProd(V);
if messages
    fprintf('done.\n');
    fprintf('\nPreparing linear constraints ...\n');
end


n=size(V,1);  % the size of matrix var. in sdp
m=size(ekv_mon_v,1);

A=[];
b=[];

ekv_mon_f_temp=ekv_mon_f;
count = 0;
for i=1:m
    sz=size(ekv_mon_f_temp,1);
    if ~sz
        ind = vertcat(ekv_mon_v{i,1}{:,2});
        M=sparse(ind(:,1),ind(:,2),ones(size(ind,1),1),n,n);  
        M=(M+M')/2;
        count = count + 1;
        A=[A M(:)];
        b=[b;0];
    else      
        for j=1:sz;
            % se ne uporabi
            % M=sparse(n,n);
            if isCycEqMonom(ekv_mon_v{i,1}{1,1},ekv_mon_f_temp{j,1}{1,1}) % there is j-th monomial in f, cycl. eq. to ekv_mon_v{i,1}
                ind = vertcat(ekv_mon_v{i,1}{:,2});
                M=sparse(ind(:,1),ind(:,2),ones(size(ind,1),1),n,n);  
                M=(M+M')/2;
                count = count + 1;
                if isempty(ekv_mon_v{i,1}{1,1})
                    f0=ekv_mon_f_temp{j,2};
                else
                    A=[A M(:)];
                    b=[b;ekv_mon_f_temp{j,2}];
                end
                ekv_mon_f_temp(j,:)=[];
                break;
            end
            if j == sz   % there is no monomial in f, cycl. eq. to ekv_mon_v{i,1}
                ind = vertcat(ekv_mon_v{i,1}{:,2});
                M=sparse(ind(:,1),ind(:,2),ones(size(ind,1),1),n,n);  
                M=(M+M')/2;
                count = count + 1;
                if isempty(ekv_mon_v{i,1}{1,1})
                    f0=0;
                else
                    A=[A M(:)];
                    b=[b;0];
                end
            end 
        end
    end
end
if ~isempty(ekv_mon_f_temp)
    fprintf('\n***** Infeasible problem: there is no epsilon such that *****\n');
    fprintf('***** f-epsilon is cyclically equivalent to a SOHS.     *****\n');
    fprintf('***** Comment: the base vector is not large enough.     *****\n');
    return;
end
K.s=n;

C=zeros(n);
C(1,1)=1;
C=C(:);

if messages
    pars_sdp.messages=1;
else
    pars_sdp.messages=0;
end

A=A';

SDP_data.A=A;
SDP_data.b=b;
SDP_data.C=C;
SDP_data.K=K;
SDP_data.pars=pars_sdp;

if justSDP_data
    if messages
        fprintf('\n***** Program is quiting because of the .justSDP_data == 1 switch! *****\n');
        fprintf('***** Just the data for the SDP was returned.                      *****\n');
    end
    return;
end

[XX,Y,INFO]=solveSDP(A,b,C,K,pars_sdp);

if messages
    disp([' ']);
    disp(['Residual norm: ' num2str(norm(A*XX-b))]);
    disp([' ']);
    disp(INFO);
end

if INFO.pinf==1 
    if messages
        fprintf('\n***** Infeasible problem: there is no epsilon such that *****\n');
        fprintf('***** f-epsilon is cyclically equivalent to a SOHS.     *****\n');
    end
    opt=[];
    return;
end


if INFO.dinf == 1
    if messages
        fprintf('\n***** Problem is unbounded - check again. *****\n');
    end
    opt=[];
    return;
end


if INFO.numerr<0
    fprintf('***** ALERT: SDPT3 ran into numerical problems.        *****\n');
%     fprintf('***** Press any key to continue with the last data ... *****\n');
%     if messages
        fprintf('***** Polynomial COULD be unbounded from below.        *****\n');
%     end
    error_warn=1;
%     pause;
elseif INFO.numerr==1
    if abs(INFO.feasratio-1)>1e-1
        fprintf('***** ALERT: SeDuMi ran into minor numerical problems.                 *****\n');
%         fprintf('***** Press any key to continue with the last data ...                 *****\n');
%         if messages
            if INFO.feasratio < 0.2
                fprintf('***** According to feasratio polynomial COULD be unbounded from below. *****\n');
            elseif INFO.feasratio > 0.8
                fprintf('***** Nevertheless, according to feasratio given solution might be ok. *****\n');
            else
                fprintf('***** Given solution might be wrong.                                   *****\n');
            end
%         end
        error_warn=1;
%         pause;
    end
elseif INFO.numerr==2
    fprintf('***** ALERT: SeDuMi ran into serious numerical problems. *****\n');
    fprintf('***** Press any key to continue with the last data ...   *****\n');
%     if messages
        fprintf('***** Given solution is therefore presumably wrong.      *****\n');
%     end
    pause;
end

X=reshape(XX,n,n);

% opt = f0-C(:)'*X(:)-Delta;
opt = f0-C'*XX-Delta;

if nargout>3
	if decomposition
        if messages
            fprintf('Computing SOHS decomposition ... ');
        end
		G=cholPSD(X);
		GG=round(G/precision)*precision;
		sohs=NCpoly(0);
		count=1;
		for i=1:size(G,1)
			if max(abs(GG(i,:))) > 0

				NCparam;
				simple = NC_using_exponents;
				fact = factor2NCpoly(GG(i,:),base,simple,abs(log10(precision)));

				sohs(count,1)=fact;
				count=count+1;
			end
        end
        
        if nargout>4
			g=sohs'*sohs;
        end
        
        if messages
            fprintf('done.\n');
            fprintf('Found SOHS decomposition with %d factors.\n',length(sohs));
        end
	elseif messages
		fprintf('\n***** No SOHS decomposition was computed because of the .decomposition == 0 switch! *****\n');
	end

    if nargout>6  
        % we extract from the dual solution the dual operator L, optimal solution of
        % inf L(f) s.t. L maps R<X>_2d to R, L(1)=1, L(\Theta^2)\ge 0
        L=reshape(C-A'*Y,n,n);
        L(1,1)=1;
    end
    
end

if error_warn
    fprintf('\nWARNING! SDP solver returned some numerical problems. Check messages!\n');
end





function [V,ekv_mon_f,error,f]=construct_V_min(f,messages)
% construst base V for cycl. equiv. check

V=[];
var=NCvarsactive();
% num_var = length(var);  % number of variables

[f,ekv_mon_f]=NCcycEqRep(f);
% ekv_mon_f = cycEqPreRep(f);

error=false;

% len_m=size(ekv_mon_f,1);
% deg=zeros(len_m,num_var);

deg = compute_deg(f);

if all(deg==0)
    V={''};
    return;
end

max_tot_len = 0;
for i = 1:size(ekv_mon_f)
    max_tot_len = max(max_tot_len,length(ekv_mon_f{i,1}));
end


len_mon=sum(deg,2);  %contains lengths of monomials
deg_max=max(len_mon);   %max degree of polynomial
% deg_min=min(len_mon);  %min degree of polynomial
% deg_var_min = min(deg,[],1);  % for every variable we compute its minimal degree in poly
deg_var_max = max(deg,[],1);  % for every variable we compute its maximal degree in poly
if ~all(mod(deg_var_max,2)==0) || ~all(mod(deg_max,2)==0) 
    if messages
        fprintf('\n***** Polynomial is NOT CYCLICALLY EQUIVALENT to SOHS - max degree is odd. *****\n');
    end
    error=true;
    return;
end

zero = find(deg_var_max==0);
% deg_var_min(zero)=[];
deg_var_max(zero)=[];
num_var=length(deg_var_max);
var(zero)=[];
P=[];
for i=1:num_var  % we take all possible monomials of length at most deg_var_max/2
    P=cartprod(P,[0:deg_var_max(i)/2]');
end
count = 0;
V=cell(1,1);
for i=1:size(P,1) % constructing base
    len =sum(P(i,:));
    if ~len
        count = count+1;  
        V{count,1}='';
        continue;
    end
    if len > deg_max/2  % all monimioals in base V must be of length at most deg_max/2
        continue;
    end
    tot=[1:len];
    position = [];
    curr_len = len;  
    for j=1:size(P,2)
        if ~P(i,j)
            where = [];
        else
            where=nchoosek(tot,P(i,j));
        end
        position =cartprod(position,where);
        curr_len = curr_len - P(i,j);
        tot = [1:curr_len];
    end  % for
    for k=1:size(position,1) % we construct monomials from position
        tot=[1:len];
        which=zeros(1,len);
        start = 1;
        for j = 1:size(P,2)   % first P(i,1) numbers in position tell where to put 1. variable, next P(i,2) numbers tell where in the rest put 2nd variable etc.
            finish  = start + P(i,j)-1;
            which(tot(position(k,start:finish)))=j;
            tot(position(k,start:finish))=[];
            start = finish+1;
        end
        monom = var{which(1)};
        for t=2:length(which)
            monom = [monom,'*',var{which(t)}];
        end
        count = count + 1;
        V{count,1}=monom;
    end
end
